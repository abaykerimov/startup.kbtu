<?php

function checkValues($value){
	include("bd.php");
	 // Use this function on all those values where you want to check for both sql injection and cross site scripting
	 //Trim the value
	$value = trim($value);
	// Stripslashes
	$value = stripslashes($value);
	 // Convert all &lt;, &gt; etc. to normal html and then strip these
	$value = strtr($value,array_flip(get_html_translation_table(HTML_ENTITIES)));
	 // Strip HTML Tags
	$value = strip_tags($value);
	// Quote the value
	$value = $conn->real_escape_string($value);
	return $value;
}


include("bd.php");
if (!isset($_GET['channel'])){
	$channel = $_GET['channel'];
}
$channel = $_GET['channel'];
echo $channel;
$rec = checkValues($_REQUEST['val']);
//$rec = $_GET['val'];
//$channel = checkValues($_REQUEST['channel']);
//get table contents

if($rec) {
	$sql = "SELECT * FROM Chat c
    JOIN Userslan u ON u.id = c.user_id
    WHERE c.message LIKE '%$rec%'";
	//$sql = "SELECT * FROM Chat WHERE message like '%$rec%'";
}
else {
	$sql = "SELECT c.message, u.id AS userid, u.fullname, u.avatar, c.id AS chatid, c.date FROM Chat c
    JOIN Userslan u ON u.id = c.user_id";
}
$result = $conn->query("set names utf8");
$result = $conn->query($sql);
$total =  $result->num_rows;
?>

<?php
echo "<h5>Результат</h5>";
while ($row = $result->fetch_assoc()) {
	?>
	<div class="list-group-item">
		<img src="<?php echo $row['avatar'];?>" alt="Имя Фамилия">
		<h5 class="list-group-item-heading"><a href="profile.php?id=<?php echo $row['userid'];?>"><?php echo $row['fullname'];?></a> <span><?php echo $row['date'];?></span>
			<button class="btn btn-primary clickbtm" onclick="clickbtm('<?php echo $row['chatid'];?>')" style="font-size: 9px; float: right; color: #6E6D6D; border-color: #6E6D6D; background: #E4E2E2">Сохранить в важное</button></h5>
		<p class="list-group-item-text"><?php echo $row['message'];?></p>

	</div>
<?php

}
if($total == 0){
	echo '<div class="no-rec">Ничего не найдено!</div>';
}
?>