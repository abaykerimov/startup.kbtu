<?php
header('Content-type: text/html; charset=utf8');
session_start();

$id = $_SESSION["user_id"];
if (!isset($id)){
    header("Location: login.php");
}
$user_id = $_GET['id'];

include("bd.php");

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <?php
    $result = $conn->query("set names utf8");
    $sql = "SELECT * FROM Userslan WHERE id = '$user_id'";
    $result = $conn->query($sql);
    while($row = $result->fetch_assoc()) {
        ?>
        <title><?php echo $row['fullname'] ?></title>
        <?php
    }
    ?>
    <link rel="canonical" href=""/>
    <meta name="robots" content="index, follow" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="css/main.less">
    <script type="text/javascript" src="js/less.min.js"></script>
    <link rel="apple-touch-icon" sizes="57x57" href="/favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/favicons/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="/favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="/favicons/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
    <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
    <style>

        .alert-box {
            padding: 15px;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        .success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
            display: none;
        }
        .profile {
            overflow: hidden;
            text-align: left;
        }
        .profile .desk_profile {
            display: inline-block;
            vertical-align: top;

            text-align: center;
        }
        .profile .desk_profile h4 {
            text-align: left;
        }
        .profile table td {
            text-align: left;
        }
        .profile div img {
            display: inline-block;
            vertical-align: top;
            width: 100%;
        }
        .text_item {
            padding: 3px;
            position: relative;
        }
        .text_item span.date {
            font-size: 9px !important;
            float: right !important;
            color: #a1a1ad !important;
            width: auto;
            margin-top: 3px;
        }
        .text_item {
            border-bottom: 1px solid #dddddd;
        }

        #logoutbtn {
            background-color: transparent;
            font-size: 13px;
            color: white;
            padding: 12px 15px;
            margin-bottom: 10px;
            border-color: transparent;
        }
        #logoutbtn:hover {
            background: black;
        }

        .col-lg-9 {
            margin-bottom: 15px;
        }
        .bgColor label{
            font-weight: bold;
            color: #A0A0A0;
        }
        #targetLayer{
            float:left;
            width:100px;
            height:100px;
            text-align:center;
            line-height:100px;
            font-weight: bold;
            color: #C0C0C0;
            background-color: #F0E8E0;
            overflow:auto;
        }
        #uploadFormLayer{
            float:right;
        }
        .btnSubmit {
            background-color: #3FA849;
            padding:4px;
            border: #3FA849 1px solid;
            color: #FFFFFF;
        }
        .inputFile {
            padding: 3px;
            background-color: #FFFFFF;
        }

        .btn.btn-default.btn-file {
            position: relative;
            overflow: hidden;
            padding: 4px 8px;
        }
        .btn-file input[type=file] {
            position: absolute;
            top: 0;
            right: 0;
            min-width: 100%;
            min-height: 100%;
            font-size: 100px;
            text-align: right;
            filter: alpha(opacity=0);
            opacity: 0;
            outline: none;
            background: white;
            cursor: inherit;
            display: block;
        }
    </style>
</head>
<body>

<!-- Верхний навбар, всегда одинаковый, брать с файла home.php -->
<nav class="navbar navbar-default" style="z-index: 10">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">iKBTU Incubator</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <!-- Активный элемент меню это у ли класс актив и  <span class="sr-only">(current)</span> -->
                <li class="active"><a href="timeline.php">Лента <span class="sr-only">(current)</span></a></li>
                <li><a href="allprojects.php">Проекты</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <!-- Это кнопка с уведомлениями -->
                <?php
                $result = $conn->query("set names utf8");
                $sql = "SELECT COUNT(user_id) as cnt FROM Notifications WHERE user_id = '$id'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                    ?>
                    <li><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="glyphicon glyphicon-info-sign"></span><span class="nav badge"><?php echo $row['cnt'] ?></span></a>
                        <ul class="dropdown-menu notificate" role="menu">
                        </ul>
                    </li>
                <?php } } ?>
                <?php
                $result = $conn->query("set names utf8");
                $id = $_SESSION['user_id'];
                $sql = "SELECT id, fullname FROM Userslan WHERE id=$id";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {

                while ($row = $result->fetch_assoc()) {
                ?>
                <!-- Это кнопка действиями над профилем -->
                <li><a class="dropdown-toggle" data-toggle="dropdown" role="button"
                       aria-expanded="false"><?php echo $row['fullname'] ?><span class="caret"></span></a>
                    <?php
                    }
                    }
                    ?>
                    <ul class="dropdown-menu" role="menu">

                        <li><a href="#user_profile" role="button" data-toggle="modal">Настройки</a></li>
                        <li class="divider"></li>
                        <form class="ajax" method="post" action="./logout.php">
                            <button id="logoutbtn" type="submit">Выход</button>
                        </form>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>


<!-- contant - основной блок где хранится три колонки - 2-8-2. В новостях проекта и просто новостях становится 2-10. Правый сталбец не отображается -->
<div id="contant">

    <!-- левая колонка со статичной информацией о проекте -->
    <div class="col-lg-2 text-center blocks">

        <!-- разворачивающаяся панель, чтобы была сразу открыта, у panel-body должен быть класс dnone -->
        <div class="panel panel-default">
            <div class="panel-heading">Участник проектов <span class="glyphicon glyphicon-chevron-up"></span></div>
            <div class="panel-body padding-none">
                <div class="text_item">
                    <div class="list-group">
                    <?php
                    $result = $conn->query("set names utf8");
                    $sql = "SELECT up.id, up.projectname, up.description FROM Usersproject usp
                    JOIN UploadProject up ON usp.project_id = up.id
                    WHERE usp.user_id = '$user_id'";
                    $result = $conn->query($sql);
                    while($row = $result->fetch_assoc()) {
                        ?>
                        <a href="project.php?id=<?php echo $row['id'] ?>" class="list-group-item">
                            <p class="list-group-item-text"><span class="w100"><?php echo $row['projectname'] ?></span><br><?php echo $row['description'] ?></p>
                        </a>
                        <?php
                    } if ($result->num_rows == 0) {
                        echo '<a href="#" class="list-group-item">
                            <p class="list-group-item-text">В проектах не состоит</p>
                        </a>';
                    }
                    ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">Подписан на проекты <span class="glyphicon glyphicon-chevron-up"></span></div>
            <div class="panel-body padding-none">
                <div class="text_item">
                    <div class="list-group">
                        <?php
                        $result = $conn->query("set names utf8");
                        $sql = "SELECT up.id, up.projectname, up.description FROM SubscribeProject sp
                        JOIN UploadProject up ON sp.project_id = up.id
                        WHERE sp.user_id = '$user_id' AND sp.own = 0";
                        $result = $conn->query($sql);
                        while($row = $result->fetch_assoc()) {
                            ?>
                            <a href="project.php?id=<?php echo $row['id'] ?>" class="list-group-item">
                                <p class="list-group-item-text"><span class="w100"><?php echo $row['projectname'] ?></span><br><?php echo $row['description'] ?></p>
                            </a>
                            <?php
                        } if ($result->num_rows == 0) {
                            echo '<a href="#" class="list-group-item">
                            <p class="list-group-item-text">Подписки отсутствуют</p>
                        </a>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Редактировать личный кабинет модалка -->
    <?php
    $result = $conn->query("set names utf8");
    $sql = "SELECT * FROM Userslan WHERE id = '$user_id'";
    $result = $conn->query($sql);
    while($row = $result->fetch_assoc()) {
        ?>
        <!-- центральная колонка -->
        <div class="col-lg-8 text-center blocks">
            <div class="profile">
                <div class="col-lg-4 padding-none">
                    <img src="<?php echo $row['avatar'] ?>" alt="Имя Фамилия">
                </div>
                <div class="desk_profile col-lg-8 padding-none">
                    <h2><?php echo $row['fullname'] ?></h2>
                    <p class="list-group-item-text"><?php echo $row['userposition'] ?></p><br>

                    <table class="table table-striped table-hover ">
                        <tbody>
                        <tr>
                            <td><span class="glyphicon glyphicon-user"></span> Логин</td>
                            <td><?php echo $row['username'] ?></td>
                        </tr>
                        <tr>
                            <td><span class="glyphicon glyphicon-lock"></span> Должность</td>
                            <td><?php echo $row['status'] ?></td>
                        </tr>
                        <tr>
                            <td><span class="glyphicon glyphicon-phone"></span> Номер телефона</td>
                            <td><?php echo $row['phone'] ?></td>
                        </tr>
                        <tr>
                            <td><span class="glyphicon glyphicon-envelope"></span> E-mail адрес</td>
                            <td><?php echo $row['email'] ?></td>
                        </tr>
						<tr>
                            <td><a href="#add_chat" class="btn btn-primary btn-xs" role="button" data-toggle="modal">Отправить личное сообщение</a></td>
							<td></td>
                        </tr>
                        </tbody>
                    </table>
					
                </div>
            </div>
        </div>
        <?php
    }
    ?>

    <!-- правая колонка -->
    <div class="col-lg-2 text-center blocks">

        <div class="panel panel-default">
            <div class="panel-heading">Последние комментарии <span class="glyphicon glyphicon-chevron-up"></span></div>
            <div class="panel-body padding-none">
                <div class="text_item">
                    <div class="list-group">
                    <?php
                    $result = $conn->query("set names utf8");
                    $sql = "SELECT upd.heading, c.comment, upd.date FROM Comment c
                    JOIN Updates upd ON c.updates_id = upd.id
                    WHERE c.user_id = '$user_id'";
                    $result = $conn->query($sql);
                    while($row = $result->fetch_assoc()) {
                        ?>
                        <a href="#" class="list-group-item">
                            <p class="list-group-item-text text-left"><span class="text-left w100">Новость: 
							<?php echo $row['heading'] ?><span class="date"><?php echo $row['date'] ?></span></span><br>
							<?php echo $row['comment'] ?></p>
                        </a>
                        <?php
                    } if($result->num_rows == 0) {
                        echo '<a href="#" class="list-group-item">
                            <p class="list-group-item-text">Отсутствуют</p>
                        </a>';
                    }
                    ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading">Автор новостей <span class="glyphicon glyphicon-chevron-up"></span></div>
            <div class="panel-body padding-none">
                <div class="list-group">
                <?php
                $result = $conn->query("set names utf8");
                $sql = "SELECT up.id, up.projectname, upd.heading, upd.text, upd.date FROM Updates upd
                JOIN UploadProject up ON upd.project_id = up.id
                WHERE upd.user_id = '$user_id'";
                $result = $conn->query($sql);
                while($row = $result->fetch_assoc()) {
                    ?>
                    <div class="text_item">
                        <p class="list-group-item-text text-left"><a href="project.php?id=<?php echo $row['id'] ?>"><?php echo $row['projectname'] ?><span class="date"><?php echo $row['date'] ?></span></a>
                            <br><a href="#"><b><?php echo $row['heading'] ?></b></a><br><?php echo $row['text'] ?></p>
                    </div>
                    <?php
                } if($result->num_rows == 0) {
                    echo '<div class="text_item">
                        <p class="list-group-item-text">Нет новостей</p>
                    </div>';
                }
                ?>

                </div>
            </div>
        </div>

    </div>

    <!-- Редактировать личный кабинет модалка -->
    <?php
    $id = $_SESSION["user_id"];
    $result = $conn->query("set names utf8");
    $sql = "SELECT * FROM Userslan WHERE id = '$id'";
    $result = $conn->query($sql);
    while($row = $result->fetch_assoc()) {
        ?>
        <!-- Редактировать личный кабинет модалка -->
        <div class="modal fade" id="user_profile">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove"></span></button>
                        <h4 class="modal-title">Редактировать личный кабинет</h4>
                    </div>
                    <div class="modal-body">

                        <fieldset>
                            <input name="uid" type="hidden" class="uid" value="<?php echo $row['id']; ?>">

                            <div class="form-group">
                                <label for="inputFoto" class="col-lg-3 control-label">Сменить аватар</label>
                                <div class="col-lg-9">
                                    <form id="uploadForm" action="upload.php" method="post">
                                        <div id="targetLayer">
                                            <img id="avatar" src="<?php echo $row['avatar']; ?>" width="100px" height="100px" />
                                        </div>
                                        <div id="uploadFormLayer">

                                    <span class="btn btn-default btn-file">
                                        Выбрать <input name="userImage" type="file" class="inputFile" />
                                    </span>

                                            <button type="submit" class="btn btn-success btnSubmit">Загрузить</button>
                                        </div>
                                    </form>
                                </div>
                                <!--<form action="upload.php"><div class="col-lg-9">
                                    <input class="form-control" id="selectphoto" placeholder="" type="file">
                                </div></form>-->
                            </div>
                            <div class="form-group">
                                <label for="username" class="col-lg-3 control-label">Никнейм</label>
                                <div class="col-lg-9">
                                    <input name="username" id="username" class="form-control" value="<?php echo $row['username']; ?>" placeholder="Ваше ФИО" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail" class="col-lg-3 control-label">Email</label>
                                <div class="col-lg-9">
                                    <input name="email" disabled="" class="form-control email" placeholder="Ваш email" type="text" value="<?php echo $row['email']; ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="name_com" class="col-lg-3 control-label">ФИО</label>
                                <div class="col-lg-9">
                                    <input name="fullname" id="userfullname" class="form-control" value="<?php echo $row['fullname']; ?>" placeholder="Ваше ФИО" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="con_tel" class="col-lg-3 control-label">Контактный телефон</label>
                                <div class="col-lg-9">
                                    <input name="phone" class="form-control" id="userphone" placeholder="Контактный телефон" pattern="+7 ([0-9]{3}) [0-9]{3}-[0-9]{2}-[0-9]{2}" type="tel" value="<?php echo $row['phone']; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="bin" class="col-lg-3 control-label">Должность</label>
                                <div class="col-lg-9">
                                    <select id="userposition" name="position" class="form-control">
                                        <option
                                            value="UI дизайнер"<?php if ($row['userposition'] == 'UI дизайнер') echo ' selected="selected"'; ?>>
                                            UI дизайнер
                                        </option>
                                        <option
                                            value="PHP разработчик"<?php if ($row['userposition'] == 'PHP разработчик') echo ' selected="selected"'; ?>>
                                            PHP разработчик
                                        </option>
                                        <option
                                            value="Web-маркетолог"<?php if ($row['userposition'] == 'Web-маркетолог') echo ' selected="selected"'; ?>>
                                            Web-маркетолог
                                        </option>
                                        <option
                                            value="Мобильный разработчик"<?php if ($row['userposition'] == 'Мобильный разработчик') echo ' selected="selected"'; ?>>
                                            Мобильный разработчик
                                        </option>

                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <div id="editnot" class="col-lg-9 col-lg-offset-3">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                    <button type="submit" class="btn btn-primary update_info" onclick="editUser('<?php echo $row['id'] ?>')">Сохранить</button>
                                </div>
                            </div>
                        </fieldset>
                        <!--<form class="form-horizontal">
                            <div class="alert alert-dismissible alert-success dnone">
                                Пароль успешно обновлен!
                            </div>
                            <fieldset>
                                <legend>Сменить пароль</legend>
                                <div class="form-group">
                                    <label for="inputPassword1" class="col-lg-3 control-label">Старый пароль</label>
                                    <div class="col-lg-9">
                                        <input class="form-control oldpass" name="oldpass" id="inputPassword1" placeholder="Старый пароль" type="password">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputPassword2" class="col-lg-3 control-label">Новый пароль</label>
                                    <div class="col-lg-9">
                                        <input class="form-control pass" id="inputPassword2" name="pass" placeholder="Новый пароль" type="password">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputPassword3" class="col-lg-3 control-label">Еще раз</label>
                                    <div class="col-lg-9">
                                        <input class="form-control pass1" id="inputPassword3" placeholder="Повторите пароль" type="password">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <div class="col-lg-9 col-lg-offset-3">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                        <button type="submit" class="btn btn-primary update_pass">Сохранить</button>
                                    </div>
                                </div>
                            </fieldset>
                        </form>-->
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    ?>

	<!-- Добавить новый диалог модалка -->
	<div class="modal fade" id="add_chat">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span
							class="glyphicon glyphicon-remove"></span></button>
				</div>
				<div class="modal-body">
					<fieldset>
						<div class="form-group">
							<input id="get_userid" type="hidden" name="get_userid" value="<?php echo $user_id; ?>">
							<?php
							$result = $conn->query("set names utf8");
							$sql = "SELECT * FROM Userslan WHERE id = '$id'";
							$result = $conn->query($sql);
							$row = $result->fetch_assoc();
							?>

							<div class="col-lg-12">
								<p><?php echo $row['fullname'] ?></p>
								<input id="get_channel" type="hidden" name="get_channel" value="<?php echo $row['fullname']; ?>">
							</div>
						</div>
						<div class="form-group">

							<div class="col-lg-12">
								
							   <textarea class="form-control name" id="msgname" placeholder="Сообщение"
									   type="text" name="msgname"></textarea>
							</div>
						</div>
						
						<div class="form-group">
							<div id="addnot" class="col-lg-9" style="margin-top: 15px;">
								<button class="reset dnone" type="reset"></button>
								<button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
								<button type="submit" class="btn btn-primary" id="zvonok" onclick="callCrudAction('sendmessage', '')">Отправить</button>
							</div>
							<div></div>
						</div>
					</fieldset>
				</div>
			</div>
		</div>
	</div>
	
    <!-- ниже конец contenta -->
</div>

</body>

<!-- скрипты везде одинаковые всего три-->
<script src= "http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script src="https://bootswatch.com/bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="js/jquery.maskedinput.js" type="text/javascript"></script>

<script type="text/javascript">
    jQuery(function ($) {
        $("#userphone").mask("+7 (999) 999-9999");
    });
</script>
<script>
    function editUser(userid) {
        var ava = $("img#avatar").attr('src');
        //alert(ava);
        var ab = $(".modal-body").find("#username").val();
        var bc = $(".modal-body").find("#userfullname").val();
        var cd = $(".modal-body").find("#userphone").val();
        var de = $(".modal-body").find("#userposition").val();
        //alert(ab, bc, cd, de);
        //console.log(ab, bc, cd, de);
        $.ajax({
            url: "edituser.php?avatar="+ava+"&username="+ab+"&fullname="+bc+"&phone="+cd+"&position="+de,
            type: "POST",
            data:  {uid:userid},
            success: function(){
                //console.log(userid, bc, cd, de);
                $("#editnot").append("<div id='importmsg' class='alert-box success'>Ваш профиль успешно изменен</div>");
                $( "div#importmsg" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                setTimeout(function () {
                    location.reload();
                }, 2000);
            }
        });
    }
</script>
<script type="text/javascript">
    $(document).ready(function (e) {
        $("#uploadForm").on('submit',(function(e) {
            e.preventDefault();
            $.ajax({
                url: "upload.php",
                type: "POST",
                data:  new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success: function(data)
                {
                    $("#targetLayer").html(data);
                },
                error: function()
                {
                }
            });
        }));
    });
</script>
<script>
    $(document).ready(function() {
        $(".dropdown-menu.notificate").load("displaynotification.php");
    })

    function callAction(action, id) {
        var queryString;
        switch (action) {
            case "remove":
                queryString = 'action=' + action + '&user_id=' + id;
                break;
        }
        jQuery.ajax({
            url: "crud_action.php",
            data: queryString,
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "remove":
                        $('.usernotification').fadeOut();
                        break;
                }
                $(".nav.badge").text('0');
            },
            error: function () {

            }
        });
    }
</script>

<script>
        function callCrudAction(action, id) {
            $("#loaderIcon").show();
            var queryString;
            switch (action) {
                case "sendmessage":
                    queryString = 'action=' + action + '&get_channel=' +$("#get_channel").val() + '&msgname=' +$("#msgname").val() + '&get_userid=' + $("#get_userid").val();
                    break;
            }
            jQuery.ajax({
                url: "crud_action.php",
                data: queryString,
                type: "POST",
                success: function (data) {
                    switch (action) {
                        case "sendmessage":
							$("#addnot").append("<div id='channelnot' class='alert-box success'>Сообщение отправлено!</div>");
							$( "div#channelnot" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                             /*setTimeout(function () {
								location.reload();
							 }, 2 * 1000);*/
                            break;
                    }

                    $("#loaderIcon").hide();
					$("#msgname").val('');
                },
                error: function () {
                    alert("error");
                }
            });
            $("#channelnot").remove();
        }

    </script>
</html>