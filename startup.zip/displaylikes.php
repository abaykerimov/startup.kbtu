<?php

include("bd.php");

$update_id = $_GET['update'];
$result = $conn->query("set names utf8");
$sql = "SELECT upl.update_id, u.id, u.fullname FROM UpdateLikes upl
JOIN Userslan u ON u.id = upl.user_id
WHERE upl.update_id = '$update_id'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    if($row_count > 0) {
        echo ", ";
    }$row_count++;
    $fullname = $row['fullname'];
    ?>
    <a href="profile.php?id=<?php echo $row['id'] ?>"><?php echo $fullname ?></a>
    <?php
}
?>
<?php
$sql8 = "SELECT * FROM UpdateLikes WHERE update_id = '$update_id'";
$result8 = $conn->query($sql8);
if (mysqli_num_rows($result8) > 0) {
    ?>
    это нравится
    <?php
} else {
    ?>

    <?php
}
?>

