<?php
session_start();
include("bd.php");
if (!isset($_GET['channel'])){
    $channel = $_GET['channel'];
}
$channel = $_GET['channel'];
$id = $_SESSION["user_id"];
$result = $conn->query("set names utf8");
$sql = "SELECT im.id, c.message, u.fullname, u.avatar FROM Importantmessages im
		JOIN Chat c ON c.id = im.chat_id
		JOIN Userslan u ON u.id = c.user_id
		WHERE im.user_id = '$id' AND c.channel_id = '$channel'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    ?>
	<div id="important_<?php echo $row['id'] ?>"><span class="glyphicon glyphicon-remove" title="Удалить закладку" style="float: right; cursor: pointer; margin-top: 8px" onclick="callCrudAction('deleteimportant', '<?php echo $row['id'] ?>')"></span>
    <a href="#" class="list-group-item" style="border: 0px;">
        <img src="<?php echo $row['avatar'] ?>" alt="Имя Фамилия">

        <p class="list-group-item-text text-left"><span class="text-left w100"><?php echo $row['fullname'] ?>
		</span><br><?php echo $row['message'] ?></p>
    </a>
	</div>
    <?php
}
?>