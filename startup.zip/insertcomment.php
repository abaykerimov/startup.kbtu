<?php
session_start();
$user_id = $_SESSION['user_id'];
//echo $user_id;
$hour = date("H:i:s", time());
$year = date("d-m-Y ");
$date = $hour . " " .$year;
include "bd.php";
$comment = $_POST['commenttext'];
$comment = stripslashes($comment);
$comment = htmlspecialchars($comment);
$comment = trim($comment);

$update_id = $_GET['update'];
$update_id = stripslashes($update_id);
$update_id = htmlspecialchars($update_id);
$update_id = trim($update_id);
if($comment != ""){
    $query = $conn->query("set names utf8");
    $query = $conn->prepare('INSERT INTO Comment (comment ,user_id, updates_id, date) VALUES (?,?,?,?)');
    $query->bind_param('siis', $comment, $user_id, $update_id, $date);
    $query->execute();

    if ($conn->errno) {
        die('Select Error (' . $conn->errno . ') ' . $conn->error);
    }
    $insert_id = $conn->insert_id;

    if($query){
        $result = $conn->query("set names utf8");
        $sql = "SELECT us.id, us.fullname, u.heading FROM Comment c
        JOIN Updates u ON u.id =c.updates_id
        JOIN Userslan us ON us.id = c.user_id
        WHERE c.id = '$insert_id'";
        $result = $conn->query($sql);

        $row = $result->fetch_assoc();
        $fullname = $row['fullname'];
        $news = $row['heading'];
        $userid = $row['id'];
    }
    if ($result){
        $sql1 = "SELECT u.user_id, up.short, u.id FROM Comment c
        JOIN Updates u ON u.id = c.updates_id
        JOIN UploadProject up ON u.project_id = up.id";
        $result1 = $conn->query($sql1);
        while($row1 = $result1->fetch_assoc()){
            $users = $row1['user_id'];
            $short = $row1['short'];
			$wall = $row1['id'];
        }
        if($result1){
            $text = "<div style='color:#fff;margin-left: 15px;'><a href='profile.php?id=$userid'>$fullname</a> оставил комментарий к <a href='$short/$wall'>$news</a></div>";
            $result2 = $conn->prepare('INSERT INTO Notifications(text, date, user_id) VALUES (?,?,?)');
            $result2->bind_param('ssi', $text, $date, $users);
            $result2->execute();
        }
    }
}
?>