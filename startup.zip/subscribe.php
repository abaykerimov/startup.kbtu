<?php
header('Content-type: text/html; charset=utf8');

include("bd.php");

$email = $_POST["subemail"];
$con = new PDO("mysql:host=$servername;dbname=$dbname",$username,$password);
if (mysqli_connect_errno()) {
    echo "Связь с базой данными потеряна: " . mysqli_connect_error();
}
$var = $con->query("set names utf8");
$query = "INSERT INTO Subscribe (email) VALUES (:email)";
$var = $con->prepare($query);

//письмо
require 'phpmailer/PHPMailerAutoload.php';
$date=date("Y-m-d H:i:s");
$mail = new PHPMailer;
//$mail->SMTPDebug = 3;                               // Enable verbose debug output
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.mail.ru';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'startup.kbtu.kz@inbox.ru';                 // SMTP username
$mail->Password = 'Incubator2016';                           // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to
$mail->From = 'startup.kbtu.kz@inbox.ru';
$mail->FromName = 'startup@kbtu.kz';
$mail->addAddress($email);
$mail->isHTML(true);                                  // Set email format to HTML
$mail->CharSet = "UTF-8";
$mail->Subject = 'Будьте в курсе всех событий о стартап-инкубаторе!';
$mail->Body = 'Здравствуйте.<br><br>
                    Вы только что подписались на новости. <br>
                    Теперь вы можете первыми узнать свежие новости о Стартап Инкубаторе КБТУ! <br>
                    Если есть какие-то вопросы, пишите в <a href="mailto:startup@kbtu.kz" target="_blank">startup@kbtu.kz</a>. <br>
                    А также на нашем сайте есть вся доступная информация и контакты.';
$mail->AltBody = 'Здравствуйте. /n/n Вы только что подписались на новости. /n Теперь вы можете первыми узнать свежие новости о Стартап Инкубаторе КБТУ! /n Если есть какие-то вопросы, пишите в startup@kbtu.kz. /n А также на нашем сайте есть вся доступная информация и контакты.';

if (!$mail->send()) {
    echo 'Ошибка отправки письма.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
}

if ($var->execute(
    array(
        ":email" => $email,
    )
)){
    echo '<script>alert("Вы подписались на новости!");
    window.location = "index.php"</script>';
}
?>