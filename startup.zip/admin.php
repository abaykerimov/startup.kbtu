<?php
header('Content-type: text/html; charset=utf8');
if (!empty($_COOKIE['sid'])) {
    // check session id in cookies
    session_id($_COOKIE['sid']);
}

session_start();
require_once 'classes/Auth.class.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./asset/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/admin.css">
</head>

<body>

<div class="container">

    <?php if (Auth\User::isAuthorized()): ?>
    <div class="col-md-4 col-md-offset-8">

        <form class="ajax" method="post" action="./ajax.php">
            <input type="hidden" name="act" value="logout">
            <div class="form-actions">
                <h3>Добро пожаловать!</h3><button class="btn btn-large btn-primary" type="submit" style='float: right; margin-top: -40px;'>Выйти</button>
            </div>
        </form>
    </div>

        <?php
        include("bd.php");

		$result = $conn->query("set names utf8");
        $sql = "SELECT id, fullname, email, phone, projectname, projectdesc, team, upload_date, selection FROM Userproject";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo "<table class='table' style='margin-top: 100px;'><tr><th>№</th><th>ФИО</th><th>Почта</th><th>Телефон</th><th>Название проекта</th><th>Описание проекта</th><th>О себе и состав команды</th><th>Дата загрузки</th><th>Заявка</th></tr>";
            // output data of each row
            while($row = $result->fetch_assoc()) {
                ?>
                <tr>
                    <td><?php echo $row['id'] ?></td>
					<td><?php echo $row['fullname'] ?></td>
                    <td><?php echo $row['email'] ?></td>
                    <td><?php echo $row['phone'] ?></td>
                    <td><?php echo $row['projectname'] ?></td>
					<td><?php echo $row['projectdesc'] ?></td>
					<td><?php echo $row['team'] ?></td>
					<td><?php echo $row['upload_date'] ?></td>
                </tr>
            <?php
            }
            echo "</table>";
        }

        $conn->close();
        ?>

    <?php else: ?>

        <form class="form-signin ajax" method="post" action="./ajax.php" style="margin-top: 200px">
            <div class="main-error alert alert-error hide"></div>

            <h4 class="form-signin-heading text-center">Пожалуйста, войдите</h4>
            <input name="username" type="text" class="input-block-level" placeholder="Никнейм" autofocus>
            <input name="password" type="password" class="input-block-level" placeholder="Пароль">
            <label class="checkbox">
                <input name="remember-me" type="checkbox" value="remember-me" checked> Запомнить
            </label>
            <input type="hidden" name="act" value="login">
            <button class="btn btn-large btn-primary" type="submit">Войти</button>
        </form>

    <?php endif; ?>

</div> <!-- /container -->

<script src="./js/jquery-2.0.3.min.js"></script>
<script src="./asset/js/bootstrap.min.js"></script>
<script src="./js/ajax-form.js"></script>

</body>
</html>
