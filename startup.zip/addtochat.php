<?php
session_start();
include("bd.php");
$channel_id = $_POST['channelid'];
$channel_id = stripslashes($channel_id);
$channel_id = htmlspecialchars($channel_id);
$channel_id = trim($channel_id);

$mytext = $_POST['val'];
$mytext = stripslashes($mytext);
$mytext = htmlspecialchars($mytext);
$mytext = trim($mytext);

$res = $conn->query("set names utf8");
$res = $conn->query("SELECT id FROM Userslan WHERE fullname = '$mytext'");
$rows = $res->fetch_assoc();
$user_id = $rows['id'];
if (isset($mytext)) {
    $mytext = mysqli_real_escape_string($conn, $mytext);
    $insert_row = $conn->query("set names utf8");
    $insert_row = $conn->prepare('INSERT INTO Channeluser ( channel_id, user_id ) VALUES (?,?)');
    $insert_row->bind_param('ii', $channel_id, $user_id);
    $insert_row->execute();
    //$insert_row = $conn->query("INSERT INTO Channeluser ( channel_id, user_id ) VALUES('$channel_id', '$user_id')");

    $insert_id = $conn->insert_id;
    if ($insert_row) {
        $result = $conn->query("set names utf8");
        $sql = "SELECT chu.user_id, ch.stage_id, ch.channelname, chu.channel_id, ch.project_id FROM Channeluser chu
        JOIN Channel ch ON ch.id = chu.channel_id
        WHERE chu.id = '$insert_id'";
        $result = $conn->query($sql);

        $row = $result->fetch_assoc();
        $chat = $row['channelname'];
        $userid = $row['user_id'];
        $projectid = $row['project_id'];
        $stageid = $row['stage_id'];
        $channelid = $row['channel_id'];
        $hour = date("H:i:s", time());
        $year = date("d-m-Y ");
        $date = $hour . " " . $year;

        if ($result) {
            $text = "<div style='color:#fff;margin-left: 15px;'><a style='color:#fff;text-underline:none'>Вас добавили в чат</a> <a href='project.php?id=$projectid&stage=$stageid&channel=$channelid'>$chat</a></div>";
            $result2 = $conn->prepare('INSERT INTO Notifications(text, date, user_id) VALUES (?,?,?)');
            $result2->bind_param('ssi', $text, $date, $userid);
            $result2->execute();
        }
    }
}
?>