<?php
header('Content-type: text/html; charset=utf8');
session_start();

$id = $_SESSION["user_id"];
$short = $_GET['short'];
$wall = $_GET['wall'];
include("bd.php");

?>
<!DOCTYPE html>
<html>
<head>
<?php 

if(isset($wall)){
    $result = $conn->query("set names utf8");    
	$sql = "SELECT up.id AS update_id, up.heading, up.text, upl.projectname FROM Updates up
	JOIN UploadProject upl ON up.project_id = upl.id
	WHERE up.id = '$wall'";
	

	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	$update_id = $row["update_id"];

?>
	<title><?php echo $row["heading"]; ?></title>
	<meta name="description" content="<?php echo $row["text"]; ?>" />
	<meta property="fb:app_id" content="203412083328998" />
	<meta property="og:url"                content="http://startup.kbtu.kz/test/<?php echo $short ?>/<?php echo $update_id ?>" />
	<meta property="og:type"               content="article" />
	<meta property="og:title"              content="<?php echo $row["heading"]; ?>" />
	<meta property="og:description"        content="<?php echo $row["text"]; ?>" />
	<meta property="og:image"  content="http://startup.kbtu.kz/test/images/logobig.png"/>
<?php } else { ?>
	<title>Новости проекта</title>
	<meta name="description" content="Лента проекта" />
<?php } ?>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<base href="/test/">
   
    <link rel="canonical" href=""/>
    <meta name="robots" content="index, follow" />
    <meta name="keywords" content="" />

    <link rel="apple-touch-icon" sizes="57x57" href="/favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/favicons/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="/favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="/favicons/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
    <link rel="stylesheet" type="text/css" href="./css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="./css/main.less">
    <script type="text/javascript" src="./js/less.min.js"></script>
    <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
    <script>

        $( "#success-btn" ).click(function() {
            $( "div.success" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
        });
    </script>
    <style>
        #user-list{float:left;list-style:none;margin:0;padding:0;width:190px;}
        #user-list li{padding: 10px; background:#FAFAFA;border-bottom:#F0F0F0 1px solid;}
        #user-list li:hover{background:#F0F0F0;}

        .alert-box {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        .success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
            display: none;
        }

        #logoutbtn {
            background-color: transparent;
            font-size: 13px;
            color: white;
            padding: 12px 15px;
            margin-bottom: 10px;
            border-color: transparent;
        }
        #logoutbtn:hover {
            background: black;
        }

        .col-lg-9 {
            margin-bottom: 15px;
        }
    </style>
    <script>
        function showEditBox(editobj, id) {
            //tinyMCE.triggerSave();
            $('#frmAdd').hide();

            $(editobj).prop('disabled', 'true');
            var currentMessage = $("#message_" + id + " .message-content").html();
            var editMarkUp = '<textarea rows="5" style="width: 100%" id="txtmessage_' + id + '">' + currentMessage + '</textarea><br><button class="btn btn-warning" name="ok" onClick="callCrudAction(\'edit\',' + id + ')">Сохранить</button>';
            $("#message_" + id + " .message-content").html(editMarkUp);
        }

        function callCrudAction(action, id) {
            $("#loaderIcon").show();
            var queryString;
            switch (action) {
                case "add":
                    queryString = 'action=' + action + '&heading=' +$("#heading").val() + '&txtmessage=' + $("#txtmessage").val() + '&get_name=' + $("#get_name").val();
                    break;
                case "edit":
                    queryString = 'action=' + action + '&message_id=' + id + '&txtmessage=' + $("#txtmessage_" + id).val();
                    break;
                case "delete":
                    queryString = 'action=' + action + '&message_id=' + id;
                    break;
            }
			console.log(action);
					console.log($("#heading").val());
					console.log($("#txtmessage").val());
					console.log($("#get_id").val());
            jQuery.ajax({
                url: "crud_action.php",
                data: queryString,
                type: "POST",
                success: function (data) {
					console.log(action);
					console.log($("#heading").val());
					console.log($("#txtmessage").val());
					console.log($("#get_id").val());
                    switch (action) {
                        case "add":
                            $("#comment-list-box").append(data);

                            $("#frmAdd").append("<div class='alert-box success'>Новость добавлена!</div>");
                            $( "div.success" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                            setTimeout(function () {
                                location.reload();
                            }, 2 * 1000);
                            break;
                        case "edit":
                            $("#message_" + id + " .message-content").html(data);
                            $('#frmAdd').show();
                            $("#message_" + id + " .btnEditAction").prop('disabled', '');
                            break;
                        case "delete":
                            $('#message_' + id).fadeOut();
                            break;
                    }
                    $("#heading").val('');
                    $("#txtmessage").val('');

                    $("#loaderIcon").hide();
                },
                error: function () {

                }
            });
        }
    </script>
	</head>
<body>


<!-- Верхний навбар, всегда одинаковый, брать с файла home.php -->
<nav class="navbar navbar-default" style="z-index: 10">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">iKBTU Incubator</a>
        </div>
        <?php
        if(isset($id)){
        ?>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <!-- Активный элемент меню это у ли класс актив и  <span class="sr-only">(current)</span> -->
                <li class="active"><a href="timeline.php">Лента <span class="sr-only">(current)</span></a></li>
                <li><a href="allprojects.php">Проекты</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <!-- Это кнопка с уведомлениями -->
                <?php
                $result = $conn->query("set names utf8");
                $sql = "SELECT COUNT(user_id) as cnt FROM Notifications WHERE user_id = '$id'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                    ?>
                    <li><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="glyphicon glyphicon-info-sign"></span><span class="nav badge"><?php echo $row['cnt'] ?></span></a>
                        <ul class="dropdown-menu notificate" role="menu">
                        </ul>
                    </li>
                <?php } } ?>
                <?php
                $result = $conn->query("set names utf8");
                $id = $_SESSION['user_id'];
                $sql = "SELECT id, fullname FROM Userslan WHERE id=$id";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {

                while($row = $result->fetch_assoc()) {
                ?>
                <!-- Это кнопка действиями над профилем -->
                <li><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><?php echo $row['fullname'] ?><span class="caret"></span></a>
                    <?php
                    }
                    }
                    ?>

                    <ul class="dropdown-menu" role="menu">

                        <li><a href="#user_profile" role="button" data-toggle="modal">Настройки</a></li>
                        <li class="divider"></li>
                        <form class="ajax" method="post" action="./logout.php">
                            <button id="logoutbtn" type="submit">Выход</button>
                        </form>

                    </ul>
                </li>
            </ul>
        </div>
        <?php } ?>
    </div>
</nav>

<!-- Это синий навбар, он имеет отношение только к проекту -->
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- Название -->
            <?php
            $result2 = $conn->query("set names utf8");
            $sql2 = "SELECT * FROM UploadProject WHERE short = '$short'";
            $result2 = $conn->query($sql2);
            if ($result2->num_rows > 0) {
            while($row2 = $result2->fetch_assoc()) {
            ?>
            <a class="navbar-brand" href="project.php?id=<?php echo $row2['id'] ?>&stage=1"><?php echo $row2['projectname'] ?></a>

        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
            <?php
            $sql = "SELECT * FROM Usersproject usp
            JOIN UploadProject up ON up.id = usp.project_id
            WHERE usp.user_id = '$id' AND up.short = '$short'";
            $result = $conn->query($sql);
            if (mysqli_num_rows($result) > 0) {
                ?>
                <ul class="nav navbar-nav">
                    <!-- Новости проекта -->
                    <li><a href="#add_news" role="button" data-toggle="modal">Добавить новость</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <!-- Профайл проекта, модальное окно внизу -->
                    <li><a href="#profile" role="button" data-toggle="modal">Редактировать профайл</a></li>
                </ul>
            <?php
            }
            else{
                ?>
                <ul class="nav navbar-nav">
                    <?php
                    if(isset($id)){
                    $sql = "SELECT * FROM SubscribeProject sp
                    JOIN UploadProject up ON up.id = sp.project_id
                    WHERE sp.user_id = '$id' AND up.short = '$short'";
                    $result = $conn->query($sql);
                    if (mysqli_num_rows($result) == 1) {
                        ?>
                        <li><a href="actions.php?action=unfollow&name=<?php echo $short ?>" role="button">Отписаться от проекта</a></li>
                    <?php
                    } else {
                        ?>
                        <li><a href="actions.php?action=follow&name=<?php echo $short ?>" role="button">Подписаться на проект</a></li>
                    <?php
                    }
                    }
                    ?>

                </ul>

            <?php
            }
            ?>

        </div>
    </div>
    <div class="container-fluid">
        <!-- Описание проекта -->
        <p><?php echo $row2['description'] ?></p>
        <?php
        }
        }
        ?>
    </div>
</nav>

<!-- contant - основной блок где хранится три колонки - 2-8-2. В новостях проекта и просто новостях становится 2-10. Правый сталбец не отображается -->
<div id="contant">

    <!-- левая колонка со статичной информацией о проекте -->
    <div class="col-lg-2 text-center blocks">

        <!-- разворачивающаяся панель, чтобы была сразу открыта, у panel-body должен быть класс dnone -->
        <div class="panel panel-default">
            <div class="panel-heading">Команда проекта <span class="glyphicon glyphicon-chevron-up"></span></div>
            <div class="panel-body">
                <div class="list-group">
                    <?php
                    $result5 = $conn->query("set names utf8");
                    $sql5 = "SELECT DISTINCT c.user_id, c.project_id, u.avatar, u.fullname
                    FROM Usersproject c
                    JOIN Userslan u ON c.user_id = u.id
                    JOIN UploadProject up ON up.id = c.project_id
                    WHERE up.short = '$short'";
                    $result5 = $conn->query($sql5);
                    while($row5 = $result5->fetch_assoc()){
                        ?>
                        <a href="profile.php?id=<?php echo $row5['user_id'] ?>" class="list-group-item">
                            <img src="<?php echo $row5['avatar'] ?>" alt="Имя Фамилия">
                            <p class="list-group-item-text"><span><?php echo $row5['fullname']; ?></span><br><?php echo $row5['userposition']; ?></p>
                        </a>
                        <?php
                    }if($result5->num_rows == 0) {
                        echo '
                        <a href="#" class="list-group-item">
                            <p class="list-group-item-text">Нет команды</p>
                        </a>
                        ';
                    }
                    ?>
                    <!-- один блок о пользователе (везде одинаковый) -->

                </div>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading">Менторы проекта <span class="glyphicon glyphicon-chevron-up"></span></div>
            <div class="panel-body">
                <div class="list-group">
                <?php
                $result = $conn->query("set names utf8");
                $sql = "SELECT u.id, u.fullname, u.avatar, u.userposition FROM Mentors m
                JOIN Userslan u ON u.id = m.user_id
                JOIN UploadProject up ON up.id = m.project_id
                WHERE up.short = '$short'";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                ?>

                <a href="profile.php?id=<?php echo $row['id'] ?>" class="list-group-item">
                    <img src="<?php echo $row['avatar'] ?>" alt="Имя Фамилия">

                    <p class="list-group-item-text"><span><?php echo $row['fullname']; ?></span><br><?php echo $row['userposition']; ?></p>
                </a>
                <?php
                } if($result->num_rows == 0) {
                    echo '
                <a href="#" class="list-group-item">
                    <p class="list-group-item-text">Нет менторов</p>
                </a>
                ';
                }
                ?>
                </div>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading">Дополнительная информация <span class="glyphicon glyphicon-chevron-down"></span></div>
            <div class="panel-body dnone">
                <div class="text_item">

                </div>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading">Подписчики проекта <span class="glyphicon glyphicon-chevron-up"></span></div>
            <div class="panel-body">
                <div class="list-group">
                    <?php

                    $result = $conn->query("set names utf8");
                    $sql = "SELECT DISTINCT c.user_id, c.project_id, u.avatar, u.fullname, u.id FROM SubscribeProject c
                    JOIN Userslan u ON c.user_id = u.id
                    JOIN UploadProject up ON up.id = c.project_id
                    WHERE up.short = '$short' AND c.own = 0";
                    $result = $conn->query($sql);
                    while($row = $result->fetch_assoc()){
                        ?>
                        <a href="profile.php?id=<?php echo $row['id'] ?>" class="list-group-item">
                            <img src="<?php echo $row['avatar'] ?>" alt="Имя Фамилия">
                            <p class="list-group-item-text"><span><?php echo $row['fullname']; ?></span><br><?php echo $row['userposition']; ?></p>
                        </a>
                        <?php
                    }if($result->num_rows == 0) {
                        echo '
                        <a href="#" class="list-group-item">
                            <p class="list-group-item-text">Нет подписчиков</p>
                        </a>
                        ';
                    }
                    ?>

                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-10 text-center blocks" id="comment-list-box" >
        <!-- заголовок-->
        <h3>Новости проекта</h3>
        <?php
        $id = $_SESSION["user_id"];
        //echo $user_id;
        $result = $conn->query("set names utf8");
        if(!isset($wall)){
        $sql = "SELECT up.id AS update_id, u.id AS user_id, up.heading, up.text, up.user_id, up.project_id, u.avatar, u.fullname, upl.projectname, up.date FROM Updates up
                JOIN Userslan u ON up.user_id = u.id
                JOIN UploadProject upl ON up.project_id = upl.id
                WHERE upl.short='$short' AND up.isNotification = 0 ORDER BY update_id DESC";
        } else {
        $sql = "SELECT up.id AS update_id, u.id AS user_id, up.heading, up.text, up.user_id, up.project_id, u.avatar, u.fullname, upl.projectname, up.date FROM Updates up
                JOIN Userslan u ON up.user_id = u.id
                JOIN UploadProject upl ON up.project_id = upl.id
                WHERE up.id = '$wall'";
        }

        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $update_id = $row["update_id"];
                ?>
                <!-- новость, везде одинаковый шаблон-->
                <div class="list-group text-left news message-box" id="message_<?php echo $row["update_id"];?>">
                    <div data-id="<?php echo $update_id ?>" class="list-group-item updid">
                        <!-- шапка новости-->
                    <h6 class="list-group-item-heading">
                        <img src="<?php echo $row['avatar'] ?>" alt="Имя Фамилия">
                        <a href="profile.php?id=<?php echo $row['user_id'] ?>"><?php echo $row['fullname'] ?></a> >
                        <a href="<?php echo $short ?>"><?php echo $row['projectname'] ?></a>
                        <span class="info"><?php echo $row['date'] ?></span>
                        <?php
                        if ($row['user_id'] == $id){
                            ?>
                            <div>
                                <span onClick="callCrudAction('delete',<?php echo $row["update_id"]; ?>)" title="Удалить" class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                                <span onClick="showEditBox(this,<?php echo $row["update_id"]; ?>)" title="Изменить" class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
                            </div>
                            <?php
                        }
                        ?>
                    </h6>
                        <hr>
                    <!-- заголовок новости-->
                    <h5 class="list-group-item-heading message-heading"><a href="<?php echo $short ?>/<?php echo $row["update_id"] ?>"><?php echo $row["heading"]; ?></a></h5>
                    <!-- текст новости-->
                    <p class="list-group-item-text message-content">
                        <?php echo $row["text"]; ?>
                    </p>
                        <hr>
                    <?php
                    if(isset($id)){
                    $sql8 = "SELECT * FROM UpdateLikes WHERE user_id = '$id' AND update_id = '$update_id'";
                    $result8 = $conn->query($sql8);
                    if (mysqli_num_rows($result8) == 1) {
                        ?>

                        <a id="likebtn_<?php echo $update_id ?>" role="button" onclick="unlike('<?php echo $update_id ?>')"><span class="glyphicon glyphicon-heart-empty"></span> Unlike</a>
                        <?php
                    } else {
                        ?>

                        <a id="likebtn_<?php echo $update_id ?>" role="button" onclick="like('<?php echo $update_id ?>')"><span class="glyphicon glyphicon-heart"></span> Like</a>
                        <?php
                    }}
                    ?>
                        <?php if(isset($wall)){ ?>
                            <div style="display: inline-block" class="share42init"></div>
                        <?php } else { ?>
                            <div style="display: inline-block"><a href="<?php echo $short ?>/<?php echo $row["update_id"] ?>"><span class="glyphicon glyphicon-send"></span> Share</a></div>

                            <a role="button" onclick="$(this).parent().find('.commenttext').focus();"><span class="glyphicon glyphicon-comment"></span> Comment</a>
                        <?php } ?>
                    <div id="likeload_<?php echo $update_id ?>"></div>
			
					<script>(function(d, s, id) {
					  var js, fjs = d.getElementsByTagName(s)[0];
					  if (d.getElementById(id)) return;
					  js = d.createElement(s); js.id = id;
					  js.src = "//connect.facebook.net/ru_RU/sdk.js#xfbml=1&version=v2.6&appId=977005299044042";
					  fjs.parentNode.insertBefore(js, fjs);
					}(document, 'script', 'facebook-jssdk'));
                    </script>
                        <div class="bg_gray">
                            <div id="listcomment_<?php echo $update_id ?>" class="list-group comment">
                                <!-- комментарий-->
                            </div>
                            <!-- новый комментарий-->
                            <?php if(isset($id)){ ?>

                                    <textarea name="commenttext" class="form-control commenttext" rows="2">Добавить комментарий...</textarea>
                                    <button data-id="<?php echo $update_id ?>" type="submit" class="btn btn-primary btn-xs dnone JScommentbtn"> Отправить</button>
                        </div>


                    <?php } ?>
                    </div>
                </div>
                <?php
                        }
        }
        ?>
    <!-- ниже конец contenta -->
</div>

<?php
/*$id = $_SESSION["user_id"];
$sql = "SELECT * FROM Usersproject";
$result = $conn->query($sql);

//echo $row['status'];
$row = $result->fetch_assoc(); */?>
<?php
$result4 = $conn->query("set names utf8");
$sql4 = "SELECT up.id AS projectid, up.projectname, up.description, up.team, c.name FROM UploadProject up
JOIN Category c ON c.id = up.category_id
WHERE up.short = '$short'";
$result4 = $conn->query($sql4);
while($row4 = $result4->fetch_assoc()) {
    ?>
    <div class="modal fade" id="profile">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span
                            class="glyphicon glyphicon-remove"></span></button>
                    <h4 class="modal-title">Редактировать профайл</h4>
                </div>
                <div class="modal-body">
                    <fieldset>
                        <input type="hidden" name="id" class="hiddenid" id="hiddenid" value="<?php echo $row4["projectid"]; ?>">

                        <div class="form-group">
                            <label for="inputName1" class="col-lg-3 control-label">Название проекта</label>

                            <div class="col-lg-9">
                                <input class="form-control projectname" id="projectname"
                                       value="<?php echo $row4['projectname'] ?>" type="text" name="projectname">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="textArea" class="col-lg-3 control-label">Описание проекта</label>

                            <div class="col-lg-9">
                                <textarea class="form-control description" rows="3" id="description"
                                          name="description"><?php echo $row4["description"]; ?></textarea>
                                <span class="help-block">Краткое описание проекта.</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="select" class="col-lg-3 control-label">Категория проекта</label>

                            <div class="col-lg-9">
                                <select class="form-control category" id="category" name="category">
                                    <option
                                        value="E-Commerce"<?php if ($row4['name'] == 'E-Commerce') echo ' selected="selected"'; ?>>
                                        E-Commerce
                                    </option>
                                    <option
                                        value="Education"<?php if ($row4['name'] == 'Education') echo ' selected="selected"'; ?>>
                                        Education
                                    </option>
                                    <option
                                        value="Enterprise and SMB"<?php if ($row4['name'] == 'Enterprise and SMB') echo ' selected="selected"'; ?>>
                                        Enterprise and SMB
                                    </option>
                                    <option
                                        value="Smart City"<?php if ($row4['name'] == 'Smart City') echo ' selected="selected"'; ?>>
                                        Smart City
                                    </option>
                                    <option
                                        value="Social"<?php if ($row4['name'] == 'Social') echo ' selected="selected"'; ?>>
                                        Social
                                    </option>
                                    <option
                                        value="Ecology"<?php if ($row4['name'] == 'Ecology') echo ' selected="selected"'; ?>>
                                        Ecology
                                    </option>
                                    <option
                                        value="Energy"<?php if ($row4['name'] == 'Energy') echo ' selected="selected"'; ?>>
                                        Energy
                                    </option>
                                    <option
                                        value="Health Care"<?php if ($row4['name'] == 'Health Care') echo ' selected="selected"'; ?>>
                                        Health Care
                                    </option>
                                    <option
                                        value="Games"<?php if ($row4['name'] == 'Games') echo ' selected="selected"'; ?>>
                                        Games
                                    </option>
                                    <option
                                        value="Hardware/IoT"<?php if ($row4['name'] == 'Hardware/IoT') echo ' selected="selected"'; ?>>
                                        Hardware/IoT
                                    </option>
                                    <option
                                        value="Other"<?php if ($row4['name'] == 'Other') echo ' selected="selected"'; ?>>
                                        Other
                                    </option>
                                </select>
                            </div>
                        </div>
                        <!--<div class="form-group">
                            <label for="inputTel1" class="col-lg-3 control-label">Веб-сайт</label>
                            <div class="col-lg-9">
                                <input class="form-control tel" id="inputTel1" placeholder="Веб-сайт" type="text" name="sait">
                            </div>
                        </div>-->
                        <div class="form-group">
                            <label for="textArea" class="col-lg-3 control-label">О команде</label>

                            <div class="col-lg-9">
                                <textarea class="form-control team" rows="3" id="team"
                                          name="team"><?php echo $row4["team"]; ?></textarea>
                                <span class="help-block">О команде и дополнительное описание.</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-9 col-lg-offset-3">
                                <p class="text-muted">*Поля отмеченные звездочкой, обязательны для заполнения!</p>
                            </div>
                        </div>
                        <div class="form-group">
                            <div id="projnot" class="col-lg-9 col-lg-offset-3">
                                <button class="reset dnone" type="reset"></button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                <button type="submit" class="btn btn-primary" onclick="editProject('<?php echo $row4["projectid"]; ?>')">Сохранить</button>
                            </div>
                        </div>
                    </fieldset>
                    <!--<table class="table table-striped table-hover col-lg-12">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Оц.№1</th>
                            <th>Оц.№2</th>
                            <th>Оц.№3</th>
                            <th>Оц.№4</th>
                            <th>Оц.№5</th>
                            <th>Оц.ср.</th>
                            <th>Комментарий</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>Column content</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>Column content</td>
                        </tr>
                        <tr class="info">
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>Column content</td>
                        </tr>
                        <tr class="success">
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>Column content</td>
                        </tr>
                        <tr class="danger">
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>Column content</td>
                        </tr>
                        <tr class="warning">
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>Column content</td>
                        </tr>
                        <tr class="active">
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>1</td>
                            <td>Column content</td>
                        </tr>
                        </tbody>
                    </table>-->

                </div>
            </div>
        </div>
    </div>
    <?php
}
?>
<!-- Добавить новый диалог модалка -->
<?php
$id = $_SESSION["user_id"];
$result = $conn->query("set names utf8");
$sql = "SELECT * FROM Userslan WHERE id = '$id'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    ?>
    <!-- Редактировать личный кабинет модалка -->
    <div class="modal fade" id="user_profile">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove"></span></button>
                    <h4 class="modal-title">Редактировать личный кабинет</h4>
                </div>
                <div class="modal-body">

                    <fieldset>
                        <input name="uid" type="hidden" class="uid" value="<?php echo $row['id']; ?>">

                        <div class="form-group">
                            <label for="inputFoto" class="col-lg-3 control-label">Сменить аватар</label>
                            <div class="col-lg-9">
                                <form id="uploadForm" action="upload.php" method="post">
                                    <div id="targetLayer">
                                        <img id="avatar" src="<?php echo $row['avatar']; ?>" width="100px" height="100px" />
                                    </div>
                                    <div id="uploadFormLayer">

                                <span class="btn btn-default btn-file">
                                    Выбрать <input name="userImage" type="file" class="inputFile" />
                                </span>

                                        <button type="submit" class="btn btn-success btnSubmit">Загрузить</button>
                                    </div>
                                </form>
                            </div>
                            <!--<form action="upload.php"><div class="col-lg-9">
                                <input class="form-control" id="selectphoto" placeholder="" type="file">
                            </div></form>-->
                        </div>
                        <div class="form-group">
                            <label for="username" class="col-lg-3 control-label">Никнейм</label>
                            <div class="col-lg-9">
                                <input name="username" id="username" class="form-control" value="<?php echo $row['username']; ?>" placeholder="Ваше ФИО" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmail" class="col-lg-3 control-label">Email</label>
                            <div class="col-lg-9">
                                <input name="email" disabled="" class="form-control email" placeholder="Ваш email" type="text" value="<?php echo $row['email']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="name_com" class="col-lg-3 control-label">ФИО</label>
                            <div class="col-lg-9">
                                <input name="fullname" id="userfullname" class="form-control" value="<?php echo $row['fullname']; ?>" placeholder="Ваше ФИО" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="con_tel" class="col-lg-3 control-label">Контактный телефон</label>
                            <div class="col-lg-9">
                                <input name="phone" class="form-control" id="userphone" placeholder="Контактный телефон" pattern="+7 ([0-9]{3}) [0-9]{3}-[0-9]{2}-[0-9]{2}" type="tel" value="<?php echo $row['phone']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="bin" class="col-lg-3 control-label">Должность</label>
                            <div class="col-lg-9">
                                <select id="userposition" name="position" class="form-control">
                                    <option
                                        value="UI дизайнер"<?php if ($row['userposition'] == 'UI дизайнер') echo ' selected="selected"'; ?>>
                                        UI дизайнер
                                    </option>
                                    <option
                                        value="PHP разработчик"<?php if ($row['userposition'] == 'PHP разработчик') echo ' selected="selected"'; ?>>
                                        PHP разработчик
                                    </option>
                                    <option
                                        value="Web-маркетолог"<?php if ($row['userposition'] == 'Web-маркетолог') echo ' selected="selected"'; ?>>
                                        Web-маркетолог
                                    </option>
                                    <option
                                        value="Мобильный разработчик"<?php if ($row['userposition'] == 'Мобильный разработчик') echo ' selected="selected"'; ?>>
                                        Мобильный разработчик
                                    </option>

                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <div id="editnot" class="col-lg-9 col-lg-offset-3">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                <button type="submit" class="btn btn-primary update_info" onclick="editUser('<?php echo $row['id'] ?>')">Сохранить</button>
                            </div>
                        </div>
                    </fieldset>
                    <!--<form class="form-horizontal">
                        <div class="alert alert-dismissible alert-success dnone">
                            Пароль успешно обновлен!
                        </div>
                        <fieldset>
                            <legend>Сменить пароль</legend>
                            <div class="form-group">
                                <label for="inputPassword1" class="col-lg-3 control-label">Старый пароль</label>
                                <div class="col-lg-9">
                                    <input class="form-control oldpass" name="oldpass" id="inputPassword1" placeholder="Старый пароль" type="password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputPassword2" class="col-lg-3 control-label">Новый пароль</label>
                                <div class="col-lg-9">
                                    <input class="form-control pass" id="inputPassword2" name="pass" placeholder="Новый пароль" type="password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputPassword3" class="col-lg-3 control-label">Еще раз</label>
                                <div class="col-lg-9">
                                    <input class="form-control pass1" id="inputPassword3" placeholder="Повторите пароль" type="password">
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="col-lg-9 col-lg-offset-3">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                    <button type="submit" class="btn btn-primary update_pass">Сохранить</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>-->
                </div>
            </div>
        </div>
    </div>
    <?php
}
?>

<!-- Добавить новость модалка -->
<div class="modal fade" id="add_news">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove"></span></button>
                <h4 class="modal-title">Добавить новость</h4>
            </div>
            <div id="frmAdd" class="modal-body">
                <fieldset>
                    <input id="get_name" type="hidden" value="<?php echo $short ?>" name="get_name">
                    <div class="form-group">
                        <label for="name_com" class="col-lg-3 control-label">Название</label>
                        <div class="col-lg-9">
                            <input class="form-control name" id="heading" value="" name="heading" placeholder="Название" type="text">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="textArea" class="col-lg-3 control-label">Текст новости</label>
                        <div class="col-lg-9">
                            <textarea style="width: 100%" class="form-control" rows="3" id="txtmessage" name="txtmessage"></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-lg-9 col-lg-offset-3">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                            <button class="btn btn-primary update_info" id="btnAddAction" name="submit" onClick="callCrudAction('add','')">Добавить новость</button>
                        </div>
                    </div>
                    <img src="LoaderIcon.gif" id="loaderIcon" style="display:none" />
                </fieldset>
            </div>
        </div>
    </div>
</div>

</body>

<script type="text/javascript" src="share42.js"></script>
<script src="https://bootswatch.com/bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="js/jquery.maskedinput.js" type="text/javascript"></script>
<script>
    $(".JScommentbtn").bind("mousedown", function(e){
        var updateid = $(this).attr("data-id");
        var commenttext = $(this).prev(".commenttext");
        //var queryString = 'commenttext=' + commenttext + '&update=' + updateid;
        $.ajax({
            type:'POST',
            url:'insertcomment.php?update='+updateid,
            data:{commenttext:commenttext.val()},
            success:function(){
                commenttext.val("");
                $("#listcomment_" + updateid).load("displaycomments.php?dataid=" + updateid).fadeIn();
                commenttext.trigger('blur');
            }
        });
    });

    $(document).ready(function(){

        $(".commenttext").focus(function(){
            if($.trim($(this).val()) == "Добавить комментарий..."){
                $(this).val("");
                $(this).next().show();
            }
        });
        $(".commenttext").blur(function(){
            if($.trim($(this).val()) == ""){
                $(this).val("Добавить комментарий...");
                $(this).next().hide();
            }

        });

        $(".list-group-item.updid").each(function(){
            var updateid = $(this).attr("data-id");
            $.ajax({
                type:'POST',
                url:'displaycomments.php?dataid=' + updateid,
                //data:{"dataid":updateid.attr("data-id")},
                success:function(){
                    setTimeout(function(){
                        $("#listcomment_" + updateid).load("displaycomments.php?dataid=" + updateid);
                    },500);
                }
            });
            /*setInterval(function(){
             $("#listcomment_" + updateid).load("displaycomments.php?dataid=" + updateid);
             },5500);*/
        });
    });
</script>
<script type="text/javascript">
    jQuery(function($){
        $("#userphone").mask("+7 (999) 999-9999");
    });

</script>
<script>
    function editProject(projectid) {
        var b = $(".modal-body").find("#projectname").val();
        var c = $(".modal-body").find("#description").val();
        var d = $(".modal-body").find("#category").val();
        var e = $(".modal-body").find("#team").val();
        //alert(a, b, c, d, e);
        $.ajax({
            url: "updateproject.php?projectname="+b+"&description="+c+"&category="+d+"&team="+e,
            type: "POST",
            data:  {id:projectid},
            success: function(){
                $("#projnot").append("<div id='projmsg' class='alert-box success'>Профиль проекта успешно изменен</div>");
                $( "div#projmsg" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                setTimeout(function () {
                    location.reload();
                }, 2000);
            }
        });
    }
</script>

<script>
    function editUser(userid) {
        var ava = $("img#avatar").attr('src');
        //alert(ava);
        var ab = $(".modal-body").find("#username").val();
        var bc = $(".modal-body").find("#userfullname").val();
        var cd = $(".modal-body").find("#userphone").val();
        var de = $(".modal-body").find("#userposition").val();
        //alert(ab, bc, cd, de);
        //console.log(ab, bc, cd, de);
        $.ajax({
            url: "edituser.php?avatar="+ava+"&username="+ab+"&fullname="+bc+"&phone="+cd+"&position="+de,
            type: "POST",
            data:  {uid:userid},
            success: function(){
                //console.log(userid, bc, cd, de);
                $("#editnot").append("<div id='importmsg' class='alert-box success'>Ваш профиль успешно изменен</div>");
                $( "div#importmsg" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                setTimeout(function () {
                    location.reload();
                }, 2000);
            }
        });
    }
</script>
<style>
    .list-group-item-text {
        margin-bottom: 10px;
    }

    .glyphicon.glyphicon-pencil {
        margin-right: 10px;
    }

    .glyphicon.glyphicon-pencil, .glyphicon.glyphicon-remove {
        cursor:pointer;
        float: right;
        font-size: 10px;
    }

    .glyphicon.glyphicon-pencil:hover, .glyphicon.glyphicon-remove:hover {
        color: #008cba;
    }

    .bgColor label{
        font-weight: bold;
        color: #A0A0A0;
    }
    #targetLayer{
        float:left;
        width:100px;
        height:100px;
        text-align:center;
        line-height:100px;
        font-weight: bold;
        color: #C0C0C0;
        background-color: #F0E8E0;
        overflow:auto;
    }
    #uploadFormLayer{
        float:right;
    }
    .btnSubmit {
        background-color: #3FA849;
        padding:4px;
        border: #3FA849 1px solid;
        color: #FFFFFF;
    }
    .inputFile {
        padding: 3px;
        background-color: #FFFFFF;
    }

    .btn.btn-default.btn-file {
        position: relative;
        overflow: hidden;
        padding: 4px 8px;
    }
    .btn-file input[type=file] {
        position: absolute;
        top: 0;
        right: 0;
        min-width: 100%;
        min-height: 100%;
        font-size: 100px;
        text-align: right;
        filter: alpha(opacity=0);
        opacity: 0;
        outline: none;
        background: white;
        cursor: inherit;
        display: block;
    }
</style>
<script type="text/javascript">
    $(document).ready(function (e) {
        $("#uploadForm").on('submit',(function(e) {
            e.preventDefault();
            $.ajax({
                url: "upload.php",
                type: "POST",
                data:  new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success: function(data)
                {
                    $("#targetLayer").html(data);
                },
                error: function()
                {
                }
            });
        }));
    });
</script>
<script>
    function like(updateid) {
        $.ajax({
            type:'POST',
            url:'actions.php',
            data:{update:updateid},
            success:function(){
                $("#likebtn_"+updateid).remove();
                $("#likeload_" + updateid).load("displaylikes.php?update=" + updateid);
            }
        });
    }

    $(document).ready(function(){
        $(".list-group-item.updid").each(function(){
            var updateid = $(this).attr("data-id");
            $.ajax({
                type:'POST',
                url:'displaylikes.php?update=' + updateid,
                //data:{"update":updateid.attr("data-id")},
                success:function(){
                    setTimeout(function(){
                        $("#likeload_" + updateid).load("displaylikes.php?update=" + updateid);
                    },500);
                }
            });
        });
    });
</script>
<script>
    $(document).ready(function() {
        $(".dropdown-menu.notificate").load("displaynotification.php");
    })

    function callAction(action, id) {
        var queryString;
        switch (action) {
            case "remove":
                queryString = 'action=' + action + '&user_id=' + id;
                break;
        }
        jQuery.ajax({
            url: "crud_action.php",
            data: queryString,
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "remove":
                        $('.usernotification').fadeOut();
                        break;
                }
                $(".nav.badge").text('0');
            },
            error: function () {

            }
        });
    }
</script>
</html>