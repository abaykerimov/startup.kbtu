<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("bd.php");
$id = $_SESSION['user_id'];
$result = $conn->query("set names utf8");
$sql = "SELECT * FROM Notifications WHERE user_id = '$id' ORDER by id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
        $user_id = $row['user_id'];
        ?>
        <li class="usernotification"><a><?php echo $row['text'] ?></a></li>
    <?php } ?>
<li class="divider"></li>
<li><a style="cursor: pointer" onclick="callAction('remove',<?php echo $user_id ?>)">Очистить</a></li>
<?php } ?>