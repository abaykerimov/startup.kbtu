<?php
session_start();
$id = $_SESSION['user_id'];

include("bd.php");
//echo $id;
$sql5 = "SELECT * FROM Usersproject WHERE user_id = '$id'";
$result5 = $conn->query($sql5);
while($row5 = $result5->fetch_assoc()) {
    $project_id = $row5['project_id'];
}
    if (mysqli_num_rows($result5) > 0) {
        echo '<script>window.location = "project.php?id='.$project_id.'&stage=1"</script>';
    } else {
        echo '<script>window.location = "allprojects.php"</script>';
    }

/*
$result4 = $conn->query("set names utf8");
$sql4 = "SELECT * FROM Userslan WHERE id='$id'";
$result4 = $conn->query($sql4);
if ($result4->num_rows > 0) {
    // output data of each row
    while($row4 = $result4->fetch_assoc()) {
        if($row4['invite'] != '1'){
            //header('Location: view_evaluation.php');
        }
        else {
            header("Location: evaluation.php");
        }
    }
}

*/
if (!isset($_SESSION['user_id'])) {
    echo '<script>window.location="login.php";</script>';
}
?>

<html>
<head>
    <meta charset="utf-8">
    <title>Инвайт</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/asset/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="apple-touch-icon" sizes="57x57" href="/favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/favicons/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="/favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="/favicons/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="/favicons/manifest.json">
    <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#5bbad5">

</head>

<body>

<div class="container" style="margin-top: 100px">

    <div class="form-group">

        <div class="col-md-3 col-md-offset-4">
            <img src="images/u0.png"/>
        </div>
    </div>
    <?php
    $id = $_SESSION['user_id'];
    $result = $conn->query("set names utf8");

    $sql = "SELECT * FROM Userslan WHERE id=$id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    if($row['status'] == 'Стартапер' && $row['invite'] == 0){ ?>
        <form id="list" class="form-horizontal" method="post" action="invite.php" style="margin-top: 125px">
            <fieldset>
                <!-- Text input-->
                <div class="form-group">

                    <div class="col-md-3 col-md-offset-4">
                        <input name="code" type="text" placeholder="Введите код проекта" class="form-control input-md" required="">

                    </div>
                </div>

                <div class="form-group">
                    <label class="col-md-4 control-label" for="savebtn"></label>
                    <div class="col-md-8">
                        <button type="submit" name="checkbtn" class="btn btn-large btn-success">Далее</button>
                    </div>
                </div>
                <div class="col-md-3 col-md-offset-4 alert alert-info">
                    Обратитесь к вашему ментору, чтобы узнать код вашего проекта. Или пишите сюда <a href="mailto:startup@kbtu.kz">startup@kbtu.kz.</a>
                </div>
            </fieldset>

        </form>
        <?php
        $user_id = $_SESSION['user_id'];
        $db_handle = new DBController();
        mysql_set_charset('utf8');
        mysql_query("SET NAMES utf8");
        $code = $_POST['code'];
        $result = $conn->query("set names utf8");

        $sql2 = "SELECT id FROM UploadProject WHERE code='".$code."'";
        $result2 = $conn->query($sql2);
        $row2 = $result2->fetch_assoc();
        $id = $row2['id'];
        if(isset($code)){
            $sid = mysql_query("INSERT into Usersproject(user_id, project_id) VALUES('" .$user_id."', '" .$id."')");
        }

        $result5 = $conn->query("set names utf8");
        $sql5 = "SELECT c.user_id, up.code, up.id FROM Usersproject c JOIN UploadProject up ON c.project_id = up.id";
        $result5 = $conn->query($sql5);
        while($row5 = $result5->fetch_assoc()){
            if($row5['user_id'] == $user_id && $row5['code'] == $code){
                //header("Location: rating.php");

                echo '<script>window.location = "view_project.php?id='.$id.'"</script>';
            }
            else {
                //header("Location: evaluation.php");
            }}
        ?>
        <?php

        $user_id = $_SESSION['user_id'];

        $result = $conn->query("set names utf8");
        $sql = "SELECT * FROM UploadProject";
        $result = $conn->query($sql);
        while($row = $result->fetch_assoc()) {
            $val = $_POST['code'];
            $id = $row['id'];

            if (isset($val)){
                if ($val == $row['code']) {

                    //header("Location: view_project.php?id=$id");
                    echo '<script>window.location = "view_project.php?id=$id"</script>';

                } else {
                    //echo "<script>alert('Вы ввели неверный код')</script>";
                }}}
        ?>
    <?php }; ?>
    <?php if($row['status'] == 'Эксперт' && $row['invite'] == 0){ ?>

        <div class="col-md-4 col-md-offset-4" style="margin-top: 50px;">
            <button type="submit" name="checkbtn" class="btn btn-large btn-success" data-toggle="modal" data-target="#myModal">Хочу получить инвайт</button>
        </div>

        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Подтверждение</h4>
                    </div>
                    <div class="modal-body">
                        <p>Для получения инвайта эксперта введите повторно вашу почту, которую вы указали при регистрации. А также телефон по которому можно с вами связаться для валидации вашей роли.</p>

                        <form id="list" class="form-horizontal" method="post" action="invite.php" style="margin-top: 25px">
                            <fieldset>
                                <!-- Text input-->
                                <div class="form-group">

                                    <div class="col-md-4 col-md-offset-3">
                                        <input name="email" type="text" placeholder="Введите почту" class="form-control input-md" required="">

                                    </div>

                                </div>
                                <div class="form-group">
                                    <div class="col-md-4 col-md-offset-3">
                                        <input name="phone" id="phone" pattern="+7 ([0-9]{3}) [0-9]{3}-[0-9]{2}-[0-9]{2}" type="tel" type="text" placeholder="Введите телефон" class="form-control input-md" required="">

                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-4 control-label" for="savebtn"></label>
                                    <div class="col-md-8">
                                        <button type="submit" name="submitbtn" class="btn btn-large btn-success">Далее</button>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                    </div>
                </div>
            </div>
        </div>
        <?php

        $id = $_SESSION['user_id'];
        $db_handle = new DBController();
        mysql_set_charset('utf8',$conn);
        mysql_query("SET NAMES utf8");
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $result = $conn->query("set names utf8");

        $sql = "SELECT * FROM Userslan WHERE id=$id";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $fullname = $row['fullname'];
        $status = $row['status'];
        if(isset($_POST['submitbtn'])){
            $sql1 = mysql_query("INSERT into Invites(fullname, email, phone, status, user_id) VALUES('" .$fullname."', '" .$email."', '".$phone."', '" .$status."', '" .$id."')");
        }

        if ($phone != ""){
            require 'phpmailer/PHPMailerAutoload.php';
            $date=date("Y-m-d H:i:s");
            $mail = new PHPMailer;
            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.mail.ru';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'startup.kbtu.kz@inbox.ru';                 // SMTP username
            $mail->Password = 'Incubator2016';                           // SMTP password
            $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 465;                                    // TCP port to connect to
            $mail->From = 'startup.kbtu.kz@inbox.ru';
            $mail->FromName = 'startup@kbtu.kz';
            $mail->addAddress('abaykerimov@gmail.com');
            $mail->addAddress('startup@kbtu.kz');
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->CharSet = "UTF-8";
            $mail->Subject = 'Запрошен инвайт эксперта';
            $mail->Body = 'Необходимо связаться с экспертом и провести валидацию личности и намерений.
                        <br><br>Данные:
						<br>ФИО: ' . $fullname . '
						<br>E-mail: ' . $email . '
						<br>Телефон: ' . $phone . '
						<br>Статус: ' . $status . '';
            $mail->AltBody = 'Необходимо связаться с экспертом и провести валидацию личности и намерений';

            if (!$mail->send()) {
                echo 'Ошибка отправки письма.';
                echo 'Mailer Error: ' . $mail->ErrorInfo;
            } else {
                echo '<script>alert("Запрос на инвайт отправлен, в течение дня администрация инкубатора свяжется с вами. Спасибо.")</script>';
            }
        }
        ?>
    <?php }; ?>
</div> <!-- /container -->

<script src="/js/jquery-2.0.3.min.js"></script>
<script src="/asset/js/bootstrap.min.js"></script>
<script src="/js/ajax-form.js"></script>
<script src="js/jquery.maskedinput.js" type="text/javascript"></script>
<script type="text/javascript">
    jQuery(function($){
        $("#phone").mask("+7 (999) 999-9999");
    });

</script>
</body>
</html>
