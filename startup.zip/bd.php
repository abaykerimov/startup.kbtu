<?php
$servername = "srv-db-plesk03.ps.kz:3306";
$username = "ikbtu_denis";
$password = "lSy558?q";
$dbname = "ikbtukz_iKBTU";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>