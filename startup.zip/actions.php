<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
<?php

session_start();
include("bd.php");
require 'phpmailer/PHPMailerAutoload.php';   
$action = $_GET['action'];
$action = stripslashes($action);
$action = htmlspecialchars($action);
$action = trim($action);

$id = $_SESSION["user_id"];

$project_name = $_GET['name'];
$project_name = stripslashes($project_name);
$project_name = htmlspecialchars($project_name);
$project_name = trim($project_name);

$hour = date("H:i:s", time());
$year = date("d-m-Y ");
$date = $hour . " " .$year;
$sql = "SELECT * FROM UploadProject WHERE short = '$project_name'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$project_id = $row['id'];

if(isset($project_id)) {

    if ($action == 'follow') {
        //$text = "подписался на проект";

        $query = $conn->prepare('INSERT INTO SubscribeProject (user_id, project_id, date) VALUES (?,?,?)');
        $query->bind_param('iis', $id, $project_id, $date);
        $query->execute();
        if ($conn->errno) {
            die('Select Error (' . $conn->errno . ') ' . $conn->error);
        }

        $insert_id = $conn->insert_id;
        if($query){
            $result = $conn->query("set names utf8");
            $sql = "SELECT us.id, us.fullname FROM SubscribeProject sp
            JOIN Userslan us ON us.id = sp.user_id
            WHERE sp.id = '$insert_id'";
            $result = $conn->query($sql);

            $row = $result->fetch_assoc();
            $fullname = $row['fullname'];
            $userid = $row['id'];
        }
        if ($result){
            $sql1 = "SELECT usp.user_id, up.short, u.email FROM Usersproject usp
            JOIN UploadProject up ON usp.project_id = up.id
			JOIN Userslan u ON usp.user_id = u.id
            WHERE up.short = '$project_name'";
            $result1 = $conn->query($sql1);
            while($row1 = $result1->fetch_assoc()){
                $users = $row1['user_id'];
                $short = $row1['short'];
				$emails = $row1['email'];
				if($result1){
					$text = "<div style='color:#fff;margin-left: 15px;'><a href='profile.php?id=$userid'>$fullname</a> подписался(-ась) на ваш проект</div>";
					$result2 = $conn->prepare('INSERT INTO Notifications(text, date, user_id) VALUES (?,?,?)');
					$result2->bind_param('ssi', $text, $date, $users);
					$result2->execute();
					
					$mail = new PHPMailer;
					
					$message  = "<html><body>";
					$message .= "<table width='100%' bgcolor='#e0e0e0' cellpadding='0' cellspacing='0' border='0'>";		   
					$message .= "<tr><td>";		   
					$message .= "<table align='center' width='100%' border='0' cellpadding='0' cellspacing='0' style='max-width:650px; background-color:#fff; font-family:Verdana, Geneva, sans-serif;'>";	$message .= "<thead>
					  <tr height='80'>
					   <th colspan='4' style='background-color:#f5f5f5; border-bottom:solid 1px #bdbdbd; font-family:Verdana, Geneva, sans-serif; color:#333; font-size:34px;' >Coding Cage</th>
					  </tr>
					  </thead>";
					$message .= "<tbody>
					  <tr align='center' height='50' style='font-family:Verdana, Geneva, sans-serif;'>
					   <td style='background-color:#00a2d1; text-align:center;'><a href='http://www.codingcage.com/search/label/PDO' style='color:#fff; text-decoration:none;'>PDO</a></td>
					   <td style='background-color:#00a2d1; text-align:center;'><a href='http://www.codingcage.com/search/label/jQuery' style='color:#fff; text-decoration:none;'>jQuery</a></td>
					   
					  </tr>
					  
					  <tr>
					   <td colspan='4' style='padding:15px;'>
						
						<p style='font-size:25px;'>Sending HTML eMail using PHPMailer</p>
						<img src='https://4.bp.blogspot.com/-rt_1MYMOzTs/VrXIUlYgaqI/AAAAAAAAAaI/c0zaPtl060I/s1600/Image-Upload-Insert-Update-Delete-PHP-MySQL.png' alt='Sending HTML eMail using PHPMailer in PHP' title='Sending HTML eMail using PHPMailer in PHP' style='height:auto; width:100%; max-width:100%;' />
					   </td>
					  </tr>
					  
					  </tbody>";
					
					$message .= "</table>";   
					$message .= "</td></tr>";
					$message .= "</table>";   
					$message .= "</body></html>";

					$mail->isSMTP();                                      
					$mail->Host = 'smtp.mail.ru';  
					$mail->SMTPAuth = true;                               
					$mail->Username = 'startup.kbtu.kz@inbox.ru';                
					$mail->Password = 'Incubator2016';                           
					$mail->SMTPSecure = 'ssl';                            
					$mail->Port = 465;                                    
					$mail->From = 'startup.kbtu.kz@inbox.ru';
					$mail->FromName = 'startup@kbtu.kz';
					$mail->addAddress($emails);
					$mail->CharSet = "UTF-8";
					$mail->Subject = 'реги';
					$mail->Subject = 'Новая подписка на ваш проект';
					$mail->Body = $message;
					$mail->ClearCustomHeaders();
					$mail->isHTML(true);                                  
					$mail->send();
					
                }
            }
			if($result2){
                $text = "<a href='profile.php?id=$userid'>$fullname</a> подписался(-ась) на проект $project";
                $result2 = $conn->prepare('INSERT INTO Updates(text, date, user_id, project_id, isNotification) VALUES (?,?,?,?,1)');
                $result2->bind_param('ssii', $text, $date, $id, $project_id);
                $result2->execute();
            }
        }

        header('location: '.$project_name);
    }

    if ($action == 'unfollow') {
        $query = $conn->prepare('DELETE FROM SubscribeProject WHERE user_id = ? AND project_id = ?');
        $query->bind_param('ii', $id, $project_id);
        $query->execute();
        if ($conn->errno) {
            die('Select Error (' . $conn->errno . ') ' . $conn->error);
        }
        $query->close();
        header('location: '.$project_name);
    }
}

$update_id = $_POST['update'];
$query = $conn->prepare('INSERT INTO UpdateLikes (update_id, user_id) VALUES (?,?)');
$query->bind_param('ii', $update_id, $id);
$query->execute();

if ($conn->errno) {
    die('Select Error (' . $conn->errno . ') ' . $conn->error);
}

$insert_id = $conn->insert_id;
if($query){
    $result = $conn->query("set names utf8");
    $sql = "SELECT us.id, us.fullname, up.heading FROM UpdateLikes upl
            JOIN Updates up ON up.id = upl.update_id
            JOIN Userslan us ON us.id = upl.user_id
            WHERE upl.id = '$insert_id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $fullname = $row['fullname'];
    $userid = $row['id'];
    $news = $row['heading'];
}
if ($result){
    $sql1 = "SELECT u.user_id, up.short, u.id, us.email FROM UpdateLikes upl
             JOIN Updates u ON u.id = upl.update_id
             JOIN UploadProject up ON u.project_id = up.id
			 JOIN Userslan us ON u.user_id = us.id
             ";
    $result1 = $conn->query($sql1);
    while($row1 = $result1->fetch_assoc()){
        $users = $row1['user_id'];
        $short = $row1['short'];
		$wall = $row1['id'];
		$emails = $row1['email'];
    }
    if($result1){
        $text = "<div style='color:#fff;margin-left: 15px;'><a href='profile.php?id=$userid'>$fullname</a> понравилась новость <a href='$short/$wall'>$news</a></div>";
        $result2 = $conn->prepare('INSERT INTO Notifications(text, date, user_id) VALUES (?,?,?)');
        $result2->bind_param('ssi', $text, $date, $users);
        $result2->execute();
		
		$mail = new PHPMailer;
					
		$message  = "<html><body>";
		$message .= "<table width='100%' bgcolor='#e0e0e0' cellpadding='0' cellspacing='0' border='0'>";		   
		$message .= "<tr><td>";		   
		$message .= "<table align='center' width='100%' border='0' cellpadding='0' cellspacing='0' style='max-width:650px; background-color:#fff; font-family:Verdana, Geneva, sans-serif;'>";	
		$message .= "<thead>
		  <tr height='80'>
		   <th colspan='4' style='background-color:#f5f5f5; border-bottom:solid 1px #bdbdbd; font-family:Verdana, Geneva, sans-serif; color:#333; font-size:34px;' >Coding Cage</th>
		  </tr>
		  </thead>";
		$message .= "<tbody>
		  <tr align='center' height='50' style='font-family:Verdana, Geneva, sans-serif;'>
		   <td style='background-color:#00a2d1; text-align:center;'><a href='http://www.codingcage.com/search/label/PDO' style='color:#fff; text-decoration:none;'>PDO</a></td>
		   <td style='background-color:#00a2d1; text-align:center;'><a href='http://www.codingcage.com/search/label/jQuery' style='color:#fff; text-decoration:none;'>jQuery</a></td>
		   
		  </tr>
		  
		  <tr>
		   <td colspan='4' style='padding:15px;'>
			
			<p style='font-size:25px;'>Sending HTML eMail using PHPMailer</p>
			<img src='https://4.bp.blogspot.com/-rt_1MYMOzTs/VrXIUlYgaqI/AAAAAAAAAaI/c0zaPtl060I/s1600/Image-Upload-Insert-Update-Delete-PHP-MySQL.png' alt='Sending HTML eMail using PHPMailer in PHP' title='Sending HTML eMail using PHPMailer in PHP' style='height:auto; width:100%; max-width:100%;' />
		   </td>
		  </tr>
		  
		  </tbody>";
		
		$message .= "</table>";   
		$message .= "</td></tr>";
		$message .= "</table>";   
		$message .= "</body></html>";

		$mail->isSMTP();                                      
		$mail->Host = 'smtp.mail.ru';  
		$mail->SMTPAuth = true;                               
		$mail->Username = 'startup.kbtu.kz@inbox.ru';                
		$mail->Password = 'Incubator2016';                           
		$mail->SMTPSecure = 'ssl';                            
		$mail->Port = 465;                                    
		$mail->From = 'startup.kbtu.kz@inbox.ru';
		$mail->FromName = 'startup@kbtu.kz';
		$mail->addAddress($emails);
		$mail->CharSet = "UTF-8";
		$mail->Subject = 'реги';
		$mail->Subject = 'Новость понравилось';
		$mail->Body = $message;
		$mail->ClearCustomHeaders();
		$mail->isHTML(true);                                  
		$mail->send();
    }
}
$query->close();
?>