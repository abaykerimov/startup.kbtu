<?php
session_start();
include("bd.php");

$project_id = $_GET['id'];
$project_id = stripslashes($project_id);
$project_id = htmlspecialchars($project_id);
$project_id = trim($project_id);

$channel = $_GET['channel'];
$channel = stripslashes($channel);
$channel = htmlspecialchars($channel);
$channel = trim($channel);

$user_id =  $_SESSION['user_id'];

$type = $_GET['type'];
$type = stripslashes($type);
$type = htmlspecialchars($type);
$type = trim($type);

$result = $conn->query("set names utf8");
if ($type == "news") {

    //вызываем последующие разы, чтобы получить новые сообщения

    $sql = "SELECT * FROM (SELECT c.id AS chatid, c.message, c.date, c.filename, u.fullname, u.id AS userid, u.avatar FROM Chat c
    JOIN Userslan u ON u.id = c.user_id
    WHERE c.project_id = '$project_id' AND c.channel_id = '$channel' AND c.id >= (SELECT min(chat_id) FROM UnreadMessages WHERE user_id = '$user_id' AND channel_id = '$channel')
    ORDER BY chatid DESC LIMIT 10)
    chats ORDER BY chatid ASC";

}

if ($type == "first") {
    //вызываем первый раз, чтобы загрузить старые сообщения

    $result1 = $conn->prepare('SELECT chat_id FROM UnreadMessages WHERE user_id = ? AND channel_id = ? ORDER by chat_id LIMIT 1');
    $result1->bind_param('ii', $user_id,$channel);
    $result1->execute();
    $result1->store_result();
    if ($result1->num_rows > 0) {
        $result1->bind_result($chat);

        while ($result1->fetch()) {

            $sql = "SELECT * FROM (SELECT c.id AS chatid, c.message, c.date, c.filename, u.fullname, u.id AS userid, u.avatar FROM Chat c
    JOIN Userslan u ON u.id = c.user_id
    WHERE c.project_id = '$project_id' AND c.channel_id = '$channel' AND c.id < '$chat'
    ORDER BY chatid DESC LIMIT 10)
    chats ORDER BY chatid ASC";


        }
        $result1->close();


    } else {
        $sql = "SELECT * FROM (SELECT c.id AS chatid, c.message, c.date, c.filename, u.fullname, u.id AS userid, u.avatar FROM Chat c
    JOIN Userslan u ON u.id = c.user_id
    WHERE c.project_id = '$project_id' AND c.channel_id = '$channel'
    ORDER BY chatid DESC LIMIT 10)
    chats ORDER BY chatid ASC";


    }
    $result1->close();
}

$result = $conn->query($sql);

if ($result->num_rows > 0) {

    if ($type == "news") { echo "<div class='text-center' id='unread'><p><span class='glyphicon glyphicon-chevron-down'></span> Непрочитанные сообщения <span class='glyphicon glyphicon-chevron-down'></span></p></div>";}

    while ($row = $result->fetch_assoc()) {
        ?>
        <div id="singlemsg_<?php echo $row['chatid']; ?>" class="list-group-item <?php if ($type == "news") { echo "unread";} ?>">
            <input type="hidden" class="hidchid" value="<?php echo $row['chatid']; ?>">
            <img src="<?php echo $row['avatar'] ?>" alt="Имя Фамилия">
            <h5 class="list-group-item-heading"><a
                    href="profile.php?id=<?php echo $row['userid']; ?>"><?php echo $row['fullname']; ?></a>
                <span><?php echo $row['date']; ?></span>
                <button class="btn btn-primary clickbtm" onclick="clickbtm('<?php echo $row['chatid']; ?>')"
                        style="font-size: 9px; float: right; color: #6E6D6D; border-color: #6E6D6D; background: #E4E2E2">
                    Сохранить в важное
                </button>
            </h5>
            <?php
            $newstring = substr($row['message'], -4);
            if (preg_match('/uploads/', $row['message'])) {
                if ($newstring == "docx" || $newstring == "pptx" || $newstring == ".pdf" || $newstring == ".doc" || $newstring == ".txt") {
                    ?>
                    <p class="list-group-item-text"><a
                            href="<?php echo $row['message']; ?>" target="_blank"><?php echo $row['filename']; ?></a></p>
                    <?php
                } else if ($newstring == ".jpg" || $newstring == ".png" || $newstring == ".PNG" || $newstring == ".JPG") { ?>
                    <p class="list-group-item-text"><img class="chatimg" src="<?php echo $row['message']; ?>"></p>
                    <?php
                }
            } else { ?>
                <p class="list-group-item-text"><?php echo $row['message']; ?></p>
                <?php
            }
            ?>

        </div>

        <?php
    }


    //теперь тут
    if ($type == "news") {
        //так как сообщения уже загружены, то есть человек открыл страницу и у него сработал ajax на новые сообщения и их больше чем 0
        //удаляем их из базы

        $query = $conn->prepare('DELETE FROM UnreadMessages WHERE user_id = ? and channel_id = ?');
        $query->bind_param('ii', $user_id,$channel);
        $query->execute();
        if ($mysqli->errno) {
            die('Select Error (' . $mysqli->errno . ') ' . $mysqli->error);
        }
        $query->close();

    }

}
//echo '<div style="height: 65px"></div>';

?>
