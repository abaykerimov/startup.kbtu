<?php
session_start();
include("bd.php");

$project_id = $_GET['id'];
$project_id = stripslashes($project_id);
$project_id = htmlspecialchars($project_id);
$project_id = trim($project_id);

$channel = $_GET['channel'];
$channel = stripslashes($channel);
$channel = htmlspecialchars($channel);
$channel = trim($channel);

$user_id =  $_SESSION['user_id'];

$type = $_GET['type'];
$type = stripslashes($type);
$type = htmlspecialchars($type);
$type = trim($type);

$query = $conn->query("set names utf8");


if ($type == "news") {

    //вызываем последующие разы, чтобы получить новые сообщения

    $query = $conn->prepare('SELECT COUNT(*) as `count` FROM (SELECT c.id AS chatid, c.message, c.date, c.filename, u.fullname, u.id AS userid, u.avatar FROM Chat c
    JOIN Userslan u ON u.id = c.user_id
    WHERE c.project_id = ? AND c.channel_id = ? AND c.id >= (SELECT min(chat_id) FROM UnreadMessages WHERE user_id = ? AND channel_id = ?)
    ORDER BY chatid DESC LIMIT 10)
    chats ORDER BY chatid ASC');
    $query->bind_param('iiii', $project_id,$channel,$user_id,$channel);
    $query->execute();
    $query->store_result();
    if ($query->num_rows > 0) {
        $query->bind_result($count);

        while ($query->fetch()) {

            echo $count;

        }
    }
    $query->close();
    $conn->close();

}

if ($type == "messages") {


    $query = $conn->prepare('SELECT c.message, c.date, u.avatar, u.fullname FROM Chat c Join Userslan u ON u.id = c.user_id
WHERE c.project_id = ? AND c.channel_id = ? ORDER by c.ID DESC LIMIT 1');
    $query->bind_param('ii', $project_id,$channel);
    $query->execute();
    $query->store_result();
    if ($query->num_rows > 0) {
        $data = array();
        $query->bind_result($message, $date,$avatar,$fullname);
        while ($query->fetch()) {
            $data[] = array(
                'date' => $date,
                'avatar' => $avatar,
                'fullname' => $fullname,
                'message' => $message
            );

        }
    } else {
        $data[] = array(
            'status' => 'NOT-FOUND'
        );
    }
    $query->close();
    $conn->close();

    echo json_encode($data);

}

?>
