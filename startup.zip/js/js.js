$(".panel-heading").click(function () {
    $(this).next().slideToggle();
    $(this).find("span").toggleClass('glyphicon-chevron-down');
    $(this).find("span").toggleClass('glyphicon-chevron-up');
});

$(".new_comment").click(function () {
    $(this).next().slideToggle();
    $(this).slideToggle();
});


$(function () {
    $("[rel='tooltip']").tooltip();
});


//window.onload = function() {
//    $(".panel-heading").next().slideToggle();
//    $(".panel-heading").find("span").toggleClass('glyphicon-chevron-down');
//    $(".panel-heading").find("span").toggleClass('glyphicon-chevron-up');
//};

//var slideout = new Slideout({
//    'panel': document.getElementById('panel'),
//    'menu': document.getElementById('menu'),
//    'padding': 300,
//    'tolerance': 70
//});
