
$(function() {

$(".follow").click(function()
{

var project_id = $(this).attr("id");
var datastring = 'project_id='+ project_id ;

 $.ajax({
   type: "POST",
   url: "add_follow_user.php",
   data: datastring,
   success: function(html){}
 });

    $("#follow"+project_id).hide();
    $("#remove"+project_id).show();
    return false;

});

});


$(function() 
{

$(".remove").click(function()
{

var project_id = $(this).attr("id");
var datastring = 'user_id='+ project_id ;

 $.ajax({
   type: "POST",
   url: "remove_follow_user.php",
   data: datastring,
   success: function(html){}
 });
   $("#remove"+project_id).hide();
   $("#follow"+project_id).show();
    return false;

});

});

