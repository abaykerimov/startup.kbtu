<?php

include("bd.php");

$update_id = $_GET['dataid'];
$stageid = stripslashes($update_id);
$stageid = htmlspecialchars($update_id);
$stageid = trim($update_id);
$result = $conn->query("set names utf8");
$sql = "SELECT cm.comment, cm.date, u.id, u.avatar, u.fullname FROM Comment cm
JOIN Userslan u ON u.id = cm.user_id
WHERE updates_id = '$update_id'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    ?>
    <div class="list-group-item">
        <h6 class="list-group-item-heading"><img src="<?php echo $row['avatar'] ?>" alt="Имя Фамилия"> <a href="profile.php?id=<?php echo $row['id'] ?>"><?php echo $row['fullname'] ?></a><span class="info"><?php echo $row['date'] ?></span></h6>
        <p class="list-group-item-text"><?php echo $row['comment'] ?></p>
    </div>
    <?php
}
?>