<!doctype html>
<!--[if IE 8 ]>
<html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]>
slider
<html lang="en" class="no-js"> <![endif]-->
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <!-- Basic -->
    <title>Главная</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="asset/css/bootstrap.min.css" type="text/css" media="screen">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" media="screen">
    <link rel="stylesheet" type="text/css" href="css/style1.css" media="screen">
    <link rel="stylesheet" type="text/css" href="css/responsive.css" media="screen">
    <link rel="stylesheet" type="text/css" href="css/animate.css" media="screen">
    <link rel="stylesheet" type="text/css" href="css/orange.css" title="jade" media="screen"/>
    <link rel="stylesheet" type="text/css" href="css/normalize.css"/>

    <link rel="apple-touch-icon" sizes="57x57" href="/favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/favicons/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="/favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="/favicons/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="/favicons/manifest.json">
    <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="canonical" href="http://startup.kbtu.kz"/>
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-TileImage" content="/mstile-144x144.png">
    <meta name="theme-color" content="#ffffff">


    <script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="asset/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>

    <!--[if IE 8]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<body>
<div id="container">
    <!-- Start Header Section -->
    <header class="clearfix">
        <!-- Start Top Bar -->
        <div class="top-bar">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <!-- Start Contact Info -->
                        <ul class="contact-details">
                            <li><a href="mailto:startup@kbtu.kz"><i class="fa fa-envelope-o"></i> startup@kbtu.kz</a>
                            </li>
                            <li><a href="tel:87752152642"><i class="fa fa-phone"></i> +7 775 215 26 42</a></li>
                        </ul>
                        <!-- End Contact Info -->
                    </div>
                    <!-- .col-md-4 -->
                    <div class="col-md-6">
                        <!-- Start Social Links -->
                        <ul class="contact-details right">
                            <li><a class="whatsapp" href="https://web.whatsapp.com" target="_blank"><i class="fa fa-whatsapp"></i> WhatsApp :+7 707 319 98 85</a></li>
                        </ul>
                        <!-- End Social Links -->
                    </div>
                    <!-- .col-md-4 -->
                    <div class="container">
                    </div>
                </div>
                <!-- .row -->
            </div>
            <!-- .container -->
        </div>
        <!-- .top-bar -->
        <!-- End Top Bar -->

        <!-- Start  Logo & Naviagtion  -->
        <div class="navbar navbar-default navbar-top">
            <div class="container">
                <div class="navbar-header">
                    <!-- Stat Toggle Nav Link For Mobiles -->
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <i class="fa fa-bars"></i>
                    </button>
                    <!-- End Toggle Nav Link For Mobiles -->
                    <a class="navbar-brand" href="index.php">
                        <img alt="" src="images/logor.png">
                    </a>
					
                </div>

            </div>
        </div>
        <!-- End Header Logo & Naviagtion -->
    </header>
    <!-- End Header Section -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center" style="background-image: url('images/slide222.png'); background-size: 100%; height: 120px;">
                <p class="forma animated4"><a class="animated4 slider btn btn-system btn-min-block" style="margin-top: 50px;" href="#submit">Подать заявку</a></p>
            </div>
        </div>
    </div>

    <!-- Start Home Page Slider -->
    <section id="home">
        <!-- Carousel -->
        <div id="main-slide" class="carousel slide" data-ride="carousel">

            <!-- Carousel inner -->
            <div class="carousel-inner">
                <div class="item active" id="item">
                    <img class="img-responsive" src="images/slide44.png" alt="slider">

                    <div class="slider-content">
                        <div class="col-md-12 text-center">
                            <h3 class="animated2">
                                <span><strong>19 марта</strong> пройдет 1-этап отборочного тура</span>
                            </h3>

                            <p class="animated4 forma"><a class="animated4 slider btn btn-default btn-min-block" href="#submit">Подать заявку</a></p>
                        </div>
                    </div>
                </div>
                <!--/ Carousel item end -->
                <div class="item" id="secondsl">
                    <img class="img-responsive" src="images/slide66.jpg" alt="slider">

                    <div class="slider-content">
                        <div class="col-md-12 text-center">
                           
                            <h3 class="animated2">
                               <span><strong>19 марта</strong> пройдет 1-этап отборочного тура</span>
                            </h3>
                            <p class="animated4 forma"><a class="animated4 slider btn btn-default btn-min-block" href="#submit">Подать заявку</a></p>

                        </div>
                    </div>
                </div>
                <!--/ Carousel item end -->
                <div class="item">
                    <img class="img-responsive" src="images/slide55.jpg" alt="slider">

                    <div class="slider-content">
                        <div class="col-md-12 text-center">
                            
                            <h3 class="animated2">
                                <span><strong>19 марта</strong> пройдет 1-этап отборочного тура</span>
                            </h3>
                            <p class="animated4 forma"><a class="animated4 slider btn btn-default btn-min-block" href="#submit">Подать заявку</a></p>
                        </div>
                    </div>
                </div>
                <!--/ Carousel item end -->

            </div>
            <!-- Carousel inner end-->

            <!-- Controls -->
            <a class="left carousel-control" href="#main-slide" data-slide="prev">
                <span><i class="fa fa-angle-left"></i></span>
            </a>
            <a class="right carousel-control" href="#main-slide" data-slide="next">
                <span><i class="fa fa-angle-right"></i></span>
            </a>
        </div>
        <!-- /carousel -->
    </section>
    <div class="container" id="welcome_text">
        <div class="col-md-2 text-right">
        </div>
        <div class="col-md-9">
            <blockquote>
                <p>Уважаемые студенты и выпускники КБТУ! </p>
                <p>Мы рады сообщить об открытии приема заявок на 1-й сезон работы стартап-инкубатора iKBTU. <br>
                    Не упустите свой шанс реализовать свою идею в успешный стартап! Ждем ваши заявки!</p>
                <small>Желаем удачи и уверенности, Администратор стартап-инкубатора iKBTU <cite title="Source Title">Мустафа Шокан</cite></small>
            </blockquote>
        </div>

    </div>

    <!-- End Home Page Slider -->
    <div class="container">
        <ul class="nav nav-tabs col-md-10 col-md-offset-1 text-center" id="tabnav">
            <li class="active"><a data-toggle="tab" href="#menu1" class="toggle">В чем фишка</a></li>
            <li><a data-toggle="tab" href="#menu2" class="toggle">Критерии отбора</a></li>
            <li><a data-toggle="tab" href="#menu4" class="toggle">Срок подачи</a></li>
            <li><a data-toggle="tab" href="#menu5" class="toggle">Вопросы-ответы</a></li>
            <li><a data-toggle="tab" href="#menu6" class="toggle">Программа</a></li>
            <li><a data-toggle="tab" href="#menu0" class="toggle">О нас</a></li>
			<li><a data-toggle="tab" href="#menu7" class="toggle">Контакты</a></li>
        </ul>
        <p class="forma meduim"><a class="forma btn btn-default btn-min-block" href="#submit">Подать заявку</a></p>
        <div class="form col-md-12" style="margin-top: 50px">
            <form enctype="multipart/form-data" action="upload.php" method="POST" class="form-horizontal" id="submit" name="submit">
                <!-- Form Name -->
                <div class="form-group">
                    <div class="col-md-4 col-md-offset-4">
                    </div>
                    <!-- Text input-->
                </div>
                <div class="form-group">


                    <label class="col-md-4 control-label" for="proinput">ФИО</label>
                    <div class="col-md-4">
                        <input id="fullname" name="fullname" type="text" placeholder="Имя и фамилия" class="form-control input-md" required>

                    </div>
                </div>

                <!-- Textarea -->
                <div class="form-group">
                    <label class="col-md-4 control-label" for="mailinput">E-mail</label>
                    <div class="col-md-4">
                        <input id="email" name="email" type="email" placeholder="Ваша почта" class="form-control input-md" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-md-4 control-label" for="phoneinput">Телефон</label>
                    <div class="col-md-4">
                        <input id="phone" name="phone" type="text" placeholder="Ваш телефон" class="form-control input-md" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-md-4 control-label" for="nameinput">Название проекта</label>
                    <div class="col-md-4">
                        <input id="projectname" name="projectname" type="text" placeholder="Ваш проект" class="form-control input-md" required>
                    </div>
                </div>
				
				<div class="form-group">
                    <label class="col-md-4 control-label" for="descinput">Краткое описание проекта</label>
                    <div class="col-md-4">
                        <textarea id="projectdesc" name="projectdesc" type="text" placeholder="Описание проекта" class="form-control input-md" required></textarea>
                    </div>
                </div>

				<div class="form-group">
                    <label class="col-md-4 control-label" for="selfinput">О себе и составе вашей команды</label>
                    <div class="col-md-4">
                        <textarea id="team" name="team" type="text" placeholder="О себе и составе вашей команды" class="form-control input-md" required></textarea>
                    </div>
                </div>

                <!-- Button -->
                <div class="form-group">
                    <label class="col-md-4 control-label"></label>
                    <div class="col-md-4">
                        <button id="btnsubmit" name="singlebutton" class="btn btn-primary" type="submit" >Зарегистрировать проект</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="content col-md-10 col-md-offset-1"><div class="tab-content">
                <div id="menu0" class="tab-pane fade">
                    <h3>О стартап-инкубаторе IKBTU</h3>
                    <p><span class="change_color">Наша цель</span> - помочь развитию молодежных стартап-проектов в сфере высоких технологий и информационных технологий от идеи до успешного бизнеса.<br/><br/>

                        <span class="change_color">Наша миссия</span> - обеспечение вклада КБТУ в развитие индустриально-инновационной системы Республики Казахстан путем поддержки технологических стартапов и начальных стадий венчурных сделок.<br/><br/>

                        Инкубатор является проектным офисом и осуществляет деятельность по реализации инновационных идей и проектов сообщества студентов и выпускников АО «Казахстанско-Британский технический университет» (далее «КБТУ») в сфере ИТ технологий.<br/><br/>

                        Стартап-инкубатор работает на базе ТОО «Институт инжиниринга и информационных технологий КБТУ». (далее – Инкубатор).  Команда Инкубатора - это сотрудники Департамента реализации инновационных проектов. Наша задача заключается в администрировании и организации процессов работы Инкубатора.<br/><br/>

                        Инкубатор создан  на основе Приказа Ректора АО «КБТУ» №8-П от 18.01.2016 г. и регламентируется Положением о работе Инкубатора и Стратегией развития ТОО «Институт инжиниринга и информационных технологий КБТУ».<br/><br/>

                        ТОО «Институт инжиниринга и информационных технологий КБТУ» - это дочерняя компания АО «Казахстанско-Британский технический университет», которая занимается повышением квалификации специалистов нефтегазового сектора Казахстана, реализует различные проекты в области разработки корпоративного программного обеспечения, развития инновационных проектов и проведения научных исследований.</p>
                </div>
				<div id="menu7" class="tab-pane fade">
                    <h3>Контакты</h3>
                    <ul>
                            <li><span>Телефоны:</span> <br/>
								Гани: <a href="tel:87752152642">+7 775 215 26 42</a><br/>
                                Нурбек: <a href="tel:87089294047">+7 708 929 40 47</a><br/>
                                Абай: <a href="tel:87054101380">+7 705 410 13 80</a><br/>
                                Денис: <a href="tel:87773516384">+7 777 351 63 84</a><br/>
                                Шокан: <a href="tel:87073199885">+7 707 319 98 85</a></li>
                            <li><span>E-mail:</span> <a href="mailto:startup@kbtu.kz" style="text-decoration: none;">startup@kbtu.kz</a></li>
                    </ul>
                </div>
                <div id="menu1" class="tab-pane fade in active">
                    <h3>Преимущества инкубатора iKBTU</h3>
                    <div class="w100">
                        <div class = "col-md-2 bank">
                            <img src="images/banking2.png">
                        </div>
                        <div class = "col-md-10">
                            <p>Фишка нашего Инкубатора в том, что он создан на базе лучшего технического университета в регионе. Наибольшее количество успешных мировых стартапов были созданы именно студентами лучших технических вузов мира. Теперь студенты и выпускники КБТУ имеют возможность реализовать свою идею в стенах родного университета и создать свою компанию как для рынка Казахстана, так и всего мира. Интернет и технологические бизнесы сегодня стирают границы рынка. Для этого Инкубатор iKBTU создает необходимые условия.</p>
                        </div>
                    </div>
                    <br/>
                    <p>Программа обучения в Инкубаторе iKBTU дает следующие возможности:</p><br/><br/>
                    <div class="w100">
                        <div class="col-md-6 col-xs-12">
                            <div class = "col-md-2 col-xs-3">
                                <img src="images/mini/idea1.png">
                            </div>
                            <div class = "col-md-10 col-xs-9">
                                <p>Cоздать прототип своей идеи и протестировать ее на предприятиях-партнерах КБТУ.</p>
                            </div>
                        </div>
                        <div class="col-md-6 col-xs-12">
                            <div class = "col-md-2 col-xs-3">
                                <img src="images/mini/computers.png">
                            </div>
                            <div class = "col-md-10 col-xs-9">
                                <p>Рабочее место и технические ресурсы.</p>
                            </div></div>
                    </div>

                    <br>

                    <div class="w100">
                        <div class="col-md-6 col-xs-12">
                            <div class = "col-md-2 col-xs-3">
                                <img src="images/mini/businessman254.png">
                            </div>

                            <div class = "col-md-10 col-xs-9">
                                <p>Найти людей в свою команду стартапа, например продажника или программиста.</p>
                            </div></div>
                        <div class="col-md-6 col-xs-12">
                            <div class = "col-md-2 col-xs-3">
                                <img src="images/mini/connection119.png">
                            </div>
                            <div class = "col-md-10 col-xs-9">
                                <p>Найти успешную бизнес-модель для своего продукта.</p>
                            </div></div>
                    </div>

                    <br>

                    <div class="w100">
                        <div class="col-md-6 col-xs-12">
                            <div class = "col-md-2 col-xs-3">
                                <img src="images/mini/laptop computer14.png">
                            </div>

                            <div class = "col-md-10 col-xs-9">
                                <p>Получить техническую помощь в разработке продукта от опытных профессионалов.</p>
                            </div></div>
                        <div class="col-md-6 col-xs-12">
                            <div class = "col-md-2 col-xs-3">
                                <img src="images/mini/businessman37.png">
                            </div>
                            <div class = "col-md-10 col-xs-9">
                                <p>Консультации по юридическим, финансовым и административным вопросам ведения бизнеса.</p>
                            </div></div>
                    </div>

                    <br>

                    <div class="w100">
                        <div class="col-md-6 col-xs-12">
                            <div class = "col-md-2 col-xs-3">
                                <img src="images/mini/teacher46.png">
                            </div>

                            <div class = "col-md-10 col-xs-9">
                                <p>Найти своего ментора и регулярно общаться с экспертами.</p>
                            </div></div>
                        <div class="col-md-6 col-xs-12">
                            <div class = "col-md-2 col-xs-3">
                                <img src="images/mini/businessman99.png">
                            </div>
                            <div class = "col-md-10 col-xs-9">
                                <p>Встретиться с потенциальными клиентами или инвесторами и привлечь денежные инвестиций или средства для реализации проекта.</p>
                            </div></div>
                    </div>

                    <br>

                    <div class="w100">
                        <div class="col-md-6 col-xs-12">
                            <div class = "col-md-2 col-xs-3">
                                <img src="images/mini/men14.png">
                            </div>

                            <div class = "col-md-10 col-xs-9">
                                <p>Обмен опытом с другими стартап-командами.</p>
                            </div></div>
                        <div class="col-md-6 col-xs-12">
                            <div class = "col-md-2 col-xs-3">
                                <img src="images/mini/society.png">
                            </div>
                            <div class = "col-md-10 col-xs-9">
                                <p>Наладить связи с выпускниками КБТУ в офисах Facebook, Google, Twitter и других компаниях Кремниевой долины.</p>
                            </div></div>
                    </div>
                </div>
                <div id="menu2" class="tab-pane fade">
                    <h3>Процедура отбора</h3>
                    <p>К рассмотрению принимаются заявки только от студентов и выпускников КБТУ. Участие бесплатное, обязательное условие – в составе команды стартапа должен быть студент, магистрант, выпускник или сотрудник КБТУ.<br/><br/>

                        <span class="change_color"> Этап 1. </span> Подать заявку через сайт startup.kbtu.kz. Окончательный срок приема заявок– 15 марта 2016 года.<br/><br/>

                        <span class="change_color">Этап 2. </span> Команда Инкубатора проведет подготовку проектов для рассмотрения Экспертным советом Инкубатора и информирует о допуске к дальнейшему участию.<br/><br/>

                        <span class="change_color">Этап 3. </span>  Отбор заявок Экспертным и Инвестиционным комитетом Инкубатора. Опубликование результатов.</p>


                    <h3>Критерии отбора</h3>
                    <p>КБТУ входит в автономный кластерный фонд Techgarden. Общей целью КБТУ и Techgarden является развитие отрасли стартапов и отбор проектов в следующих сферах:</p><br/><br/>


                    <div class="w100">
                        <div class="col-md-4 col-md-offset-2 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/roboto.png">
                            </div>

                            <div class = "col-md-8 col-xs-9">
                                <p>Робототехника</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/lightning24.png">
                            </div>
                            <div class = "col-md-8 col-xs-9">
                                <p>Энергообеспечение</p>
                            </div>
                        </div>
                    </div>
                    <br>

                    <div class="w100">
                        <div class="col-md-4 col-md-offset-2 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/shield20.png">
                            </div>

                            <div class = "col-md-8 col-xs-9">
                                <p>Системы обеспечения безопасности</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/factory15.png">
                            </div>
                            <div class = "col-md-8 col-xs-9">
                                <p>Автоматизация промышленности</p>
                            </div>
                        </div>
                    </div>
                    <br>

                    <div class="w100">
                        <div class="col-md-4 col-md-offset-2 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/college1.png">
                            </div>

                            <div class = "col-md-8 col-xs-9">
                                <p>Образование</p>
                            </div></div>
                        <div class="col-md-4 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/tree101.png">
                            </div>
                            <div class = "col-md-8 col-xs-9">
                                <p>Экология</p>
                            </div></div>
                    </div>
                    <br>

                    <div class="w100">
                        <div class="col-md-4 col-md-offset-2 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/smartphone55.png">
                            </div>

                            <div class = "col-md-8 col-xs-9">
                                <p>Мобильные технологии</p>
                            </div></div>
                        <div class="col-md-4 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/shopping109.png">
                            </div>
                            <div class = "col-md-8 col-xs-9">
                                <p>Электронная коммерция</p>
                            </div></div>
                    </div>
                    <br>

                    <div class="w100">
                        <div class="col-md-4 col-md-offset-2 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/databases11.png">
                            </div>

                            <div class = "col-md-8 col-xs-9">
                                <p>Big Data</p>
                            </div></div>
                        <div class="col-md-4 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/touch-screen-phone1.png">
                            </div>
                            <div class = "col-md-8 col-xs-9">
                                <p>Интернет вещей</p>
                            </div></div>
                    </div>
                    <br>

                    <div class="w100">
                        <div class="col-md-4 col-md-offset-2 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/home120.png">
                            </div>

                            <div class = "col-md-8 col-xs-9">
                                <p>Умный дом</p>
                            </div></div>
                        <div class="col-md-4 col-xs-12">
                            <div class = "col-md-4 col-xs-3">
                                <img src="images/mini/man183.png">
                            </div>
                            <div class = "col-md-8 col-xs-9">
                                <p>Умный город</p>
                            </div></div>
                    </div>
                </div>
                <div id="menu4" class="tab-pane fade">
                    <h3>Срок подачи</h3>
                    <p>Окончательный срок подачи заявок на 1-й сезон работы Инкубатора iKBTU- <span class="change_color">15 марта 2016 г.</span>  Начало приема заявок стартует 25 января 2016 г.<br/><br/>

                        В период с 25 января по 15 марта каждый претендент может задавать вопросы, обсудить перспективность своей идеи, а самое главное качественно подготовить заявку в виде заполненного шаблона презентации с командой Инкубатора по указанным выше контактам.  Фактически это уже и есть подготовка стартапа.</p>
                </div>
                <div id="menu5" class="tab-pane fade">
                    <h3>Вопросы-ответы</h3>
                    <div class="list-group">
                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>1. У меня нет идеи, но я хочу что-то сделать, как вы можете помочь?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p> Ответ: Приходи на наши гостевые лекции и открытые дни, возможно ты найдешь свою идею. Следи за календарем событий анонсов нашего Инкубатора.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>2. Что можно почитать про стартапы, чтобы понять что это такое и мое ли это вообще?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Гай Кавасаки <a href="https://www.goodreads.com/book/show/11355099-11" target="_blank">«Стартап»</a> <br/>
                            Джейсон Фрайд <a href="https://www.goodreads.com/book/show/18335125" target="_blank">«Rework»</a> <br/>
                            Eric Ries <a href="https://www.goodreads.com/book/show/10127019" target="_blank">«Lean Startup»</a> <br/>
                            Майк Микаловиц <a href="https://www.goodreads.com/book/show/11928099" target="_blank">«Стартап без бюджета»</a> <br/>
                            Крис Гильбо <a href="https://www.goodreads.com/book/show/26235785-100" target="_blank">«Стартап за 100$»</a> <br/>
                            Стив Бланк <a href="https://www.goodreads.com/book/show/17305976" target="_blank">«Стартап. Настольная книга основателя»</a> <br/>
                            Ash Maurya <a href="https://www.goodreads.com/book/show/13078769" target="_blank">«Running Lean»</a> <br/>
                            Бен Хоровиц <a href="https://www.goodreads.com/book/show/23486767" target="_blank">«Легко не будет»</a> <br/>
                            Питер Тиль <a href="https://www.goodreads.com/book/show/23620339" target="_blank">«От нуля к единице»</a><br/>
							Роб Фитцпатрик <a href="http://momtestbook.com/ru/" target="_blank">«Спроси маму»</a>
</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>3. Каковы условия Инкубатора?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Инкубатор проводит бесплатное обучение и предоставление своих ресурсов стартапу для создания прототипа или апробирования своей идеи. По завершению программы Инкубатора на основе решения Инвестиционного комитета команде стартапа будет предложено финансирование и создание совместной компании. Инкубатор получит долю в размере 30% от создаваемой компании. 70% доли компании будет принадлежать команде стартапа.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>4. Вы украдете мою идею! Как моя идея будет защищена?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Мы будет заключать соглашение с каждым резидентом, там все будет оговорено. Но в целом идея сама о себе ничего- ее реализация все.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>5. У меня есть возможность подать мою идею в другие стартап-инкубаторы, чем вы отличаетесь?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Первое - ты КБТУшник и это твой родной инкубатор. Второе- мы привлекаем лучших экспертов, которые имеют реальную практику. Только практика, только хардкор. Третье- с нами дружат руководители многих компаний и корпораций и мы можем помочь тебе с первыми контрактами твоего стартапа.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>6. Какие денежные обязательства за прохождение программы Инкубатора?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Никаких. Более того, после рассмотрения мы предоставим средства для реализации прототипа продукта.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>7. Сколько реальных денег вы дадите на мой стартап?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Ноль. Все средства будут выделяться только в виде финансовых затрат КБТУ на развитие проекта. Но стартапам после выпуска предоставляется шанс получить инвестиции от Инвестиционного комитета. КБТУ сотрудничает с другими инвесторами и венчурными фондами, которые готовы предоставить от 10 000$ до 500 000$.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>8. На какое финансирование можно рассчитывать?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: В последний день обучения в Инкубаторе пройдет демо-день, когда стартапы представят свои продукты Инвестиционному комитету и приглашенным инвесторам. Инвестиционный комитет принимает решение по финансированию стартапа. Сумма финансирования будет определена в зависимости от необходимых средств для успешного развития предприятия в течение первого полугодия.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>9. Какой график обучения в Инкубаторе?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Первый сезон работы Инкубатор пройдет в течение 4 месяцев апрель-июль. Подробней смотри раздел <a onclick='$("#tabnav a[href=#menu6]").tab("show");'><strong>«Программа»</strong></a></p>.
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>10. Если я пройду в Инкубатор, это не навредит моей учебе?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Будет зависеть только от тебя. Учеба наших студентов для нас это приоритет. График обучения Инкубатора будет гибким и учитывать график обучения в КБТУ.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>11. Засчитывается ли обучение в Инкубаторе, как практика?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Пока нет. Идет процесс согласования с деканатами.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>12. Мои преподаватели/родители запрещают мне заниматься чем-то кроме учебы, но я хочу пройти обучение в Инкубаторе, как быть?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Пригласи преподавателей активно участвовать в жизни Инкубатора и они поймут, что на самом деле у нас одни цели. Покажи им книги, которые ты читаешь. Расскажи родителям о Марке Цукерберге и посмотри с ними фильм «Социальная сеть». Расскажи им как был создан Whatsapp, в конце концов и сколько сейчас стоит этот стартап.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>13. Я не КБТУшник, но хочу попасть со своим проектом в Инкубатор, как быть?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Найди и привлеки в команду КБТУшника. Если не знаешь как, то просто подавай заявку, а мы поможем.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>14. Я придумал идею, но у меня нет нужной команды, что делать?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Приходи на консультацию, обсудим. Подавай идею в любом случае, далее мы поможем собрать в команду других людей для ее реализации.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>15. У меня нет идеи, но я крутой программист, не люблю общаться с людьми, но хочу быть в стартапе, что делать?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Можешь записаться в ряды самураев технических экспертов, а мы найдем тебе стартап-команду.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>16. У меня есть идея, но я не знаю что и как заполнять в вашем шаблоне, что делать?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Приходи и пообщайся вживую с командой Инкубатора. Они тебе помогут подготовится.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>17. Что если мой стартап прошел обучение в Инкубаторе, но в итоге не заинтересовал Инвестиционный комитет и не был профинансирован для создания юридической компании?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Никаких юридических обязательств перед Инкубатором вы не будете нести. После выпуска с Инкубатора и отказе финансирования со стороны Инвестиционного комитета вы будете вправе принимать свое решение о создании компании или поиске и привлечении другого инвестора.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>18. Что если мой стартап во время обучения в Инкубаторе уже заинтересовал других инвесторов и они готовы создать совместную компанию или инвестировать в мою текущую компанию?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Если стартап в данный момент является резидентом Инкубатора и основатели ранее подписали соглашение об этом, то на протяжении всего резидентства Инкубатор имеет приоритетное право «первой ночи» инвестирования в стартап. Это значит, что стартап в таком случае сначала должен предложить Инвестиционному комитету рассмотреть свой проект на возможность инвестирования и только после получения отказа заключать с другими инвесторами подобные сделки.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>19. У меня есть идея и деньги, давайте я вам просто заплачу за реализацию?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: Не наш формат.</p>
                        </div>

                        <a class="list-group-item list-group-item-main">
                            <h6 class="list-group-item-heading">
                                <p>20. У меня еще другие вопросы, куда обращаться?</p>
                                <span class="glyphicon glyphicon-chevron-up"></span></h6>
                        </a>
                        <div class="content_a">
                            <p>Ответ: В верхней и нижней частях сайта есть контакты, смело обращайся туда.</p>
                        </div>
                    </div>
                </div>
                <div id="menu6" class="tab-pane fade">
                    <h3>Программа</h3>
                    <p>После того, как ваша идея или проект будут одобрены и вы официально станете резидентом первого сезона Стартап-Инкубатора iKBTU.<br/><br/>

                        Что Вас ждет, если Вы не сдадитесь и дойдете до победного конца:</p><br/>
                    <div class="text-center happens" style="width: 100%;">
                        <div class="oval">
                            <img src="images/4to1.png" alt="">
                            <p>Инвестиции на создание своей компании</p>
                        </div>
                        <div class="oval">
                            <img src="images/4to2.png" alt="">
                            <p>Максимальный пиар и поддержка в СМИ</p>
                        </div>
                        <div class="oval">
                            <img src="images/4to3.png" alt="">
                            <p>Помощь в привлечении клиентов и новых инвесторов</p>
                        </div>
                    </div>
                    <h4> Основные темы программы Инкубатора</h4><br/><br/>

                    <ul class="list-group">
                        <li class="list-group-item">
                            <p>Поиск и формирование идеи</p>
                        </li>
                        <li class="list-group-item">
                            <p>Создание бизнес-модели</p>
                        </li>
                        <li class="list-group-item">
                            <p>Создание бизнес-плана</p>
                        </li>
                        <li class="list-group-item">
                            <p>Презентация бизнес-идеи</p>
                        </li>
                        <li class="list-group-item">
                            <p>Создание команды</p>
                        </li>
                        <li class="list-group-item">
                            <p>Разработка потребительских ценностей</p>
                        </li>
                        <li class="list-group-item">
                            <p>Бутстреппинг и привлечение первых инвестиций</p>
                        </li>
                        <li class="list-group-item">
                            <p>Создание минимального продукта</p>
                        </li>
                        <li class="list-group-item">
                            <p>Проверка потребительского спроса</p>
                        </li>
                        <li class="list-group-item">
                            <p>Продажи и показатели</p>
                        </li>
                        <li class="list-group-item">
                            <p>Брендинг и маркетинг</p>
                        </li>
                        <li class="list-group-item">
                            <p>Изучение конкурентов</p>
                        </li>
                        <li class="list-group-item">
                            <p>Защита интеллектуальной собственности</p>
                        </li>
                        <li class="list-group-item">
                            <p>Венчурные сделки</p>
                        </li>
                    </ul>

                    <h4>Практическая часть программы Инкубатора</h4><br/><br/>
                    <img src="images/u47.png"/><br/><br/>

                    <p>Вы должны будете приготовится к трудному, но интересному периоду вашей жизни. В четыре месяца мы вместим максимум информации, дел и задач, чтобы к окончанию вы имели то зачем пришли в Инкубатор:
                        <br/><br/>
                        • Команда Инкубатора, эксперты, менторы все мы будем помогать вам сделать из вашей идеи что-то рабочее – прототип или проверку жизнеспособности вашей идеи.<br/>
                        • Каждый из нас будет тратить свое время, ресурсы и мысли на то, чтобы у вас получилось нечто ценное.<br/>
                        • Практически все свое свободное время вам придется тратить на свой проект.<br/>
                        • Одновременно вам надо будет успевать прокачиваться теорией построения стартапа- посещать лекции, семинары, воркшопы, конференции, читать статьи, выдержки из книг, слушать онлайн-модули<br/>
                        • Вас будет удивлять, что эксперты не дают конкретных советов<br/>
                        • Вас будет напрягать, что ментор не делает за вас вашу работу<br/>
                        • Вас будет бесить, что вокруг все только советуют и никто будто не помогает<br/>
                        • Вы впадете в депрессию, когда вдруг поймете, что после таких усилий по созданию прототипа он оказался никому не интересен и никто не хочет им пользоваться, даже бесплатно<br/>
                        • Вы поймете, что значит фраза «стартап не взлетает не потому что у них не было продукта, а потому что у них не было клиента»</p>
                </div>
            </div>
        </div>
    </div>

    <div id="partners" class="partner">
        <div class="container">
            <div class="row">


            </div>
            <!-- .row -->
        </div>
        <!-- .container -->
    </div>

    <!-- Start Footer Section -->
    <footer>
        <div class="container">
            <div class="row footer-widgets">
                <div class="col-md-3 col-xs-12">
                    <div class="footer-widget mail-subscribe-widget">
                        <h4>Подписывайся<span class="head-line"></span></h4>

                        <p>Будь в курсе всех событий!</p>

                        <form class="subscribe" action="subscribe.php" method="post" id="subscribe">
                            <input type="email" class="input-sm" name="subemail" placeholder="mail@example.com" required style="width:50%; color: #555">
                            <input type="submit" class="btn-system" value="Подписаться">
                        </form>
                    </div>
                </div>
                <!-- Start Contact Widget -->
                <div class="col-md-3 col-xs-12">
                    <div class="footer-widget contact-widget">
                        <h4>Контакты<span class="head-line"></span></h4>

                        <ul>
                            <li><span>Телефоны:</span> <br/>Гани: <a href="tel:87752152642">+7 775 215 26 42</a><br/>
                                Нурбек: <a href="tel:87089294047">+7 708 929 40 47</a><br/>
                                Абай: <a href="tel:87054101380">+7 705 410 13 80</a><br/>
                                Денис: <a href="tel:87773516384">+7 777 351 63 84</a><br/>
                                Шокан: <a href="tel:87073199885">+7 707 319 98 85</a></li>
                            <li><span>E-mail:</span> <a href="mailto:startup@kbtu.kz" style="text-decoration: none;">startup@kbtu.kz</a></li>
                        </ul>
                    </div>
                </div>
                <!-- .col-md-3 -->
                <!-- End Contact Widget -->
                <div class="col-md-3 col-xs-12">
                    <div class="footer-widget social-widget">
                        <h4>Мы в социальных сетях!<span class="head-line"></span></h4>
                        <ul class="social-icons">
                            <li>
                                <a class="facebook" href="https://www.facebook.com/kbtustartup" target="_blank"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li>
                                <a class="vk" href="http://vk.com/kbtustartup" target="_blank"><i class="fa fa-vk"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- .row -->

            <!-- Start Copyright -->
            <div class="copyright-section">
                <div class="row">
                    <div class="col-md-11">
                        <p>&copy; 2016 Департамент реализации инновационных проектов ТОО «Институт инжиниринга и информационных технологий Казахстанско-Британского технического университета» </p>
                    </div>
                    <!-- .col-md-6 -->
                    <div class="counter col-md-1">
                        <button class="count btn btn-default" style="background: #222; border-color: #222"></button>
                        <div id="qoo-counter">
                            <a href="http://qoo.by/" title="Бесплатный счетчик посещений на сайт">
                                <img src="http://qoo.by/counter/standard/016.png" alt="Счетчик посещаемости и статистика сайта">
                                <div id="qoo-counter-visits"></div>
                                <div id="qoo-counter-views"></div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- .row -->
            </div>
            <!-- End Copyright -->

        </div>
    </footer>
    <!-- End Footer Section -->


</div>
<!-- End Full Body Container -->

<!-- Go To Top Link -->
<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

<div id="loader">
    <div class="spinner">
        <div class="dot1"></div>
        <div class="dot2"></div>
    </div>
</div>
<script type="text/javascript" src="js/classie.js"></script>
<script type="text/javascript" src="js/demo1.js"></script>
<script type="text/javascript" src="http://qoo.by/counter.js"></script>
<script type="text/javascript" src="js/script.js"></script>
												 
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
	(function(){ 
		var widget_id = 'QKsxfmiMgi';
		var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = 	'//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);})();</script>
<!-- {/literal} END JIVOSITE CODE -->

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-73037056-1', 'auto');
    ga('send', 'pageview');

</script>

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter34986055 = new Ya.Metrika({
                    id:34986055,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true,
                    webvisor:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/34986055" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery("a.scrollto").click(function () {
            elementClick = jQuery(this).attr("href")
            destination = jQuery(elementClick).offset().top;
            jQuery("html:not(:animated),body:not(:animated)").animate({scrollTop: destination}, 1100);
            return false;
        });
    });
    $(".list-group a.list-group-item-main").next().slideToggle();
    $(".list-group a.list-group-item-main").find("span").toggleClass('glyphicon-chevron-down');
    $(".list-group a.list-group-item-main").find("span").toggleClass('glyphicon-chevron-up');

    $(".list-group a.list-group-item-main").click(function () {
        $(this).next().slideToggle();
        $(this).find("span").toggleClass('glyphicon-chevron-down');
        $(this).find("span").toggleClass('glyphicon-chevron-up');
    });

</script>
<script>
    $('.forma').click(function(){
        $('.form').css('display', 'block');
        $('.content').css('display', 'none');
    });

    $('.toggle').click(function(){
        $('.form').css('display', 'none');
        $('.content').css('display', 'block');
    });

    jQuery(document).ready(function($) {
        $('a[href^="#"]').click(function (e) {
            e.preventDefault();
            var target = this.hash,
                $target = $(target);

            $('html, body').animate( {
                'scrollTop': $target.offset().top-40
            }, 900, 'swing', function () {
                window.location.hash = target;
            } );
        } );
    } );

    $('.count.btn').click(function(){
        $('#qoo-counter').toggle('slow');
    });
</script>
<script>
    function passcorr() {
        var str = document.getElementById("filebtn").value;
        var pos = str.lastIndexOf(".");
        var ext = str.substr(pos);

        if (ext == ".pptx")
        {
            error = "<font color=\'green\'>Правильный формат</font>";
        }
        else if (ext == ".ppt")
        {
            error = "<font color=\'green\'>Правильный формат</font>";
        }
        else if (ext == ".pdf")
        {
            error = "<font color=\'green\'>Правильный формат</font>";
        }
        else {
            error = "<font color=\'red\'>Загрузите pptx, ppt или pdf</font>";
        }
        document.getElementById("error").innerHTML=error;
    }
</script>
<noscript>
    Для полной функциональности этого сайта необходимо включить JavaScript.
    Вот <a href="http://www.enable-javascript.com/ru/" target="_blank">
        инструкции, как включить JavaScript в вашем браузере</ a>.
</noscript>
</body>

</html>