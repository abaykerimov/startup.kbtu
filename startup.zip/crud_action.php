<?php
session_start();
include("bd.php");
require 'phpmailer/PHPMailerAutoload.php';   

$user_id = $_SESSION['user_id'];
$hour = date("H:i:s", time());
$year = date("d-m-Y ");
$date = $hour . " " .$year;
$heading = $_POST["heading"];
$heading = stripslashes($heading);
$heading = htmlspecialchars($heading);
$heading = trim($heading);

$txtmessage = $_POST["txtmessage"];
$txtmessage = stripslashes($txtmessage);
$txtmessage = htmlspecialchars($txtmessage);
$txtmessage = trim($txtmessage);
$txtmessage = mb_ereg_replace('\n', '<br />', $txtmessage);

$get_name = $_POST['get_name'];
$get_name = stripslashes($get_name);
$get_name = htmlspecialchars($get_name);
$get_name = trim($get_name);

$message_id = $_POST['message_id'];
$message_id = stripslashes($message_id);
$message_id = htmlspecialchars($message_id);
$message_id = trim($message_id);

$channelname = $_POST['channelname'];
$channelname = stripslashes($channelname);
$channelname = htmlspecialchars($channelname);
$channelname = trim($channelname);

$firstmsgname = $_POST['firstmsgname'];
$firstmsgname = stripslashes($firstmsgname);
$firstmsgname = htmlspecialchars($firstmsgname);
$firstmsgname = trim($firstmsgname);

$userid = $_POST['user_id'];
$userid = stripslashes($userid);
$userid = htmlspecialchars($userid);
$userid = trim($userid);

$get_id = $_POST['get_id'];
$get_id = stripslashes($get_id);
$get_id = htmlspecialchars($get_id);
$get_id = trim($get_id);

$stageid = $_POST['hidst'];

$hidchannelid = $_POST['hidchannelid'];
$hidchannelid = stripslashes($hidchannelid);
$hidchannelid = htmlspecialchars($hidchannelid);
$hidchannelid = trim($hidchannelid);

$hidimportid = $_POST['hidimportid'];
$hidimportid = stripslashes($hidimportid);
$hidimportid = htmlspecialchars($hidimportid);
$hidimportid = trim($hidimportid);

$hidteamid = $_POST['hidteamid'];
$hidteamid = stripslashes($hidteamid);
$hidteamid = htmlspecialchars($hidteamid);
$hidteamid = trim($hidteamid);

$get_userid = $_POST['get_userid'];
$get_userid = stripslashes($get_userid);
$get_userid = htmlspecialchars($get_userid);
$get_userid = trim($get_userid);

$get_channel = $_POST['get_channel'];
$get_channel = stripslashes($get_channel);
$get_channel = htmlspecialchars($get_channel);
$get_channel = trim($get_channel);

$msgname = $_POST['msgname'];
$msgname = stripslashes($msgname);
$msgname = htmlspecialchars($msgname);
$msgname = trim($msgname);

$action = $_POST["action"];
if(!empty($action)) {
	switch($action) {
		case "add":
			$sql = "SELECT * FROM UploadProject WHERE short = '$get_name'";
			$result = $conn->query($sql);
			$row = $result->fetch_assoc();
			$project_id = $row['id'];

			if(isset($project_id)){

				if($txtmessage != "" && $heading != ""){
				$query = $conn->query("set names utf8");
				$query = $conn->prepare('INSERT INTO Updates (heading ,text, date, user_id, project_id) VALUES (?,?,?,?,?)');
				$query->bind_param('sssii', $heading, $txtmessage, $date, $user_id, $project_id);
				$query->execute();
					if ($conn->errno) {
						die('Select Error (' . $conn->errno . ') ' . $conn->error);
					}
				}
			}
			if($query){
				$insert_id = $conn->insert_id;
			?>
			<div class="list-group text-left news message-box" id="message_<?php echo $insert_id ?>">
				<div>
					<button class="btnEditAction btn btn-primary" name="edit" onClick="showEditBox(this, <?php echo $insert_id ?>)">Изменить</button>
					<button class="btnDeleteAction btn btn-primary" name="delete" onClick="callCrudAction('delete', <?php echo $insert_id ?>)">Удалить</button>
				</div>
				<div class="list-group-item">
				<!-- шапка новости-->
				<h6 class="list-group-item-heading"><img src="https://pp.vk.me/c631419/v631419339/1e155/dGpvrDddE2I.jpg" alt="Имя Фамилия"> <a href="profile.php?id="></a> > <a href="pages/view_project.php?"></a><span class="info"></span></h6>
				<h5 class="list-group-item-heading message-heading"><b><?php echo $heading ?></b></h5>
				<p class="list-group-item-text message-content"><?php echo $txtmessage ?></p>
				</div>
			</div>
			<?php
			}

			break;
			
		case "edit":
			$query = $conn->query("set names utf8");
			$query = $conn->prepare("UPDATE Updates SET text = '$txtmessage' WHERE id = ?");
			$query->bind_param('i', $message_id);
			$query->execute();
			if ($conn->errno) {
				die('Select Error (' . $conn->errno . ') ' . $conn->error);
			}
			if($query){
				echo $txtmessage;
			}
			break;			
		
		case "delete": 
			if(!empty($message_id)) {
				$query = $conn->prepare('DELETE FROM Updates WHERE id = ?');
				$query->bind_param('i', $message_id);
				$query->execute();
				if ($conn->errno) {
					die('Select Error (' . $conn->errno . ') ' . $conn->error);
				}
				$query->close();
			}
			break;

		case "addchannel":
		if($channelname != ""){
			$query = $conn->query("set names utf8");
			$query = $conn->prepare('INSERT INTO Channel (channelname ,project_id, stage_id, user_id, date_open) VALUES (?,?,?,?,?)');
			$query->bind_param('siiis', $channelname, $get_id, $stageid, $user_id, $date);
			$query->execute();
			if ($conn->errno) {
				die('Select Error (' . $conn->errno . ') ' . $conn->error);
			}

			if($query){
			$insert_id = $conn->insert_id;
				?>
                <a href="project.php?id=<?php echo $get_id ?>&stage=<?php echo $stageid ?>&channel=<?php echo $insert_id ?>" class="btn btn-primary btn-xs"><?php echo $row['channelname'];?></a>
				<?php
				echo '
				<script>
					setTimeout(function(){
            			window.location = "project.php?id='.$get_id.'&stage='.$stageid. '&channel='.$insert_id.'";
        			},1500);
				</script>
				';
				$sql2 = "SELECT * FROM Usersproject WHERE project_id = '$get_id'";
            	$result2 = $conn->query($sql2);
            	if ($result2->num_rows > 0) {
                while ($row2 = $result2->fetch_assoc()) {
                $fetchuid = $row2['user_id'];

                    $result = $conn->prepare('INSERT INTO Channeluser (channel_id ,user_id) VALUES (?,?)');
					$result->bind_param('ii', $insert_id, $fetchuid);
					$result->execute();
						if ($conn->errno) {
							die('Select Error (' . $conn->errno . ') ' . $conn->error);
						}
                    }
            	}
				if($result){
					if($firstmsgname != ""){
						$hour = date("H:i:s", time());
						$year = date("d-m-Y ");
						$datemsg = $hour . " " .$year;
						$result3 = $conn->prepare('INSERT INTO Chat(message, user_id, project_id, channel_id, date) VALUES(?,?,?,?,?)');
						$result3->bind_param('siiis', $firstmsgname, $user_id, $get_id, $insert_id, $datemsg);
						$result3->execute();
					}
				}
			}
		}
		break;

		case "remove":
			if(!empty($userid)) {
				$query = $conn->prepare('DELETE FROM Notifications WHERE user_id = ?');
				$query->bind_param('i', $userid);
				$query->execute();
				if ($conn->errno) {
					die('Select Error (' . $conn->errno . ') ' . $conn->error);
				}
				$query->close();
			}
			break;
		case "deletechannel":
			$query = $conn->prepare('DELETE FROM Chat WHERE channel_id = ?');
			$query->bind_param('i', $hidchannelid);
			$query->execute();
			if ($query) {
				$result = $conn->prepare('DELETE FROM Channel WHERE id = ?');
				$result->bind_param('i', $hidchannelid);
				$result->execute();
			}
			$result->close();
			break;
		case "deleteimportant":
			$query = $conn->prepare('DELETE FROM Importantmessages WHERE id = ?');
			$query->bind_param('i', $hidimportid);
			$query->execute();
			$query->close();
			break;
		case "deletefromteam":
			$query = $conn->prepare('DELETE FROM Usersproject WHERE id = ?');
			$query->bind_param('i', $hidteamid);
			$query->execute();
			$query->close();
			break;
			
		case "sendmessage":
		
		$hour = date("H:i:s", time());
		$year = date("d-m-Y ");
		$datemsg = $hour . " " .$year;
		$sql2 = "SELECT * FROM Channel ch
		JOIN Userslan u ON ch.forward_id = u.id
		WHERE ch.forward_id = '$get_userid'";
		$result2 = $conn->query($sql2);
		if ($result2->num_rows > 0) {
			$row2 = $result2->fetch_assoc();
			$channelid = $row2['id'];
			$emails = $row2['email'];
			$result4 = $conn->prepare('INSERT INTO Messages(message, channel_id, user_id, forward_id, date) VALUES(?,?,?,?,?)');
			$result4->bind_param('siiis', $msgname, $channelid, $user_id, $get_userid, $datemsg);
			$result4->execute();
		} else {
		if($msgname != ""){
			$query = $conn->query("set names utf8");
			$query = $conn->prepare('INSERT INTO Channel (channelname, user_id, date_open, forward_id) VALUES (?,?,?,?)');
			$query->bind_param('sisi', $get_channel, $user_id, $datemsg, $get_userid);
			$query->execute();
		}
		$insert_id = $conn->insert_id;
			if($query){
				
				$result3 = $conn->prepare('INSERT INTO Messages(message, channel_id, user_id, forward_id, date) VALUES(?,?,?,?,?)');
				$result3->bind_param('siiis', $msgname, $insert_id, $user_id, $get_userid, $datemsg);
				$result3->execute();	
				
				$mail = new PHPMailer;
					
				$message  = "<html><body>";
				$message .= "<table width='100%' bgcolor='#e0e0e0' cellpadding='0' cellspacing='0' border='0'>";		   
				$message .= "<tr><td>";		   
				$message .= "<table align='center' width='100%' border='0' cellpadding='0' cellspacing='0' style='max-width:650px; background-color:#fff; font-family:Verdana, Geneva, sans-serif;'>";	
				$message .= "<thead>
				  <tr height='80'>
				   <th colspan='4' style='background-color:#f5f5f5; border-bottom:solid 1px #bdbdbd; font-family:Verdana, Geneva, sans-serif; color:#333; font-size:34px;' >Coding Cage</th>
				  </tr>
				  </thead>";
				$message .= "<tbody>
				  <tr align='center' height='50' style='font-family:Verdana, Geneva, sans-serif;'>
				   <td style='background-color:#00a2d1; text-align:center;'><a href='http://www.codingcage.com/search/label/PDO' style='color:#fff; text-decoration:none;'>PDO</a></td>
				   <td style='background-color:#00a2d1; text-align:center;'><a href='http://www.codingcage.com/search/label/jQuery' style='color:#fff; text-decoration:none;'>jQuery</a></td>
				   
				  </tr>
				  
				  <tr>
				   <td colspan='4' style='padding:15px;'>
					
					<p style='font-size:25px;'>Sending HTML eMail using PHPMailer</p>
					<img src='https://4.bp.blogspot.com/-rt_1MYMOzTs/VrXIUlYgaqI/AAAAAAAAAaI/c0zaPtl060I/s1600/Image-Upload-Insert-Update-Delete-PHP-MySQL.png' alt='Sending HTML eMail using PHPMailer in PHP' title='Sending HTML eMail using PHPMailer in PHP' style='height:auto; width:100%; max-width:100%;' />
				   </td>
				  </tr>
				  
				  </tbody>";
				
				$message .= "</table>";   
				$message .= "</td></tr>";
				$message .= "</table>";   
				$message .= "</body></html>";

				$mail->isSMTP();                                      
				$mail->Host = 'smtp.mail.ru';  
				$mail->SMTPAuth = true;                               
				$mail->Username = 'startup.kbtu.kz@inbox.ru';                
				$mail->Password = 'Incubator2016';                           
				$mail->SMTPSecure = 'ssl';                            
				$mail->Port = 465;                                    
				$mail->From = 'startup.kbtu.kz@inbox.ru';
				$mail->FromName = 'startup@kbtu.kz';
				$mail->addAddress($emails);
				$mail->CharSet = "UTF-8";
				$mail->Subject = 'реги';
				$mail->Subject = 'Новое личное сообщение';
				$mail->Body = $message;
				$mail->ClearCustomHeaders();
				$mail->isHTML(true);                                  
				$mail->send();
			}
		}
		break;
	}
}
?>