<?php
include("bd.php");

$project_id = $_POST['project_id'];
$project_id = stripslashes($project_id);
$project_id = htmlspecialchars($project_id);
$project_id = trim($project_id);

$stage_id = $_POST['stage_id'];
$stage_id = stripslashes($stage_id);
$stage_id = htmlspecialchars($stage_id);
$stage_id = trim($stage_id);
//$sql = mysql_query("UPDATE UploadProject SET projectname = '" . $_POST["projectname"] . "', description = '" . $_POST["description"] . "', category = '" . $_POST["category"] . "', stage = '" . $_POST["stage"] . "', team = '" . $_POST["team"] . "' WHERE  id=" . $project_id);
$query = $conn->prepare('UPDATE UploadProject SET stage_id=? WHERE id=?');
$query->bind_param('ii', $stage_id, $project_id);
$query->execute();
/*if($query){
    header("Location: timeline.php");
}*/