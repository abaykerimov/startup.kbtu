<?php
include("bd.php");
if (isset($_GET['id'])) {
    $id = $_GET['id'];
}
$id = $_GET['id'];
$result = $conn->query("set names utf8");
$sql = "SELECT DISTINCT c.id, c.user_id, c.project_id, u.id AS userid, u.avatar, u.fullname, u.userposition FROM Usersproject c JOIN Userslan u ON c.user_id = u.id WHERE c.project_id = '$id'";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    ?>
	<div id="projteam_<?php echo $row['id'] ?>">
    <a href="profile.php?id=<?php echo $row['userid'] ?>" class="list-group-item teamdisp">
        <img src="<?php echo $row['avatar'] ?>" alt="Имя Фамилия">

        <p class="list-group-item-text"><span><?php echo $row['fullname']; ?></span><br><?php echo $row['userposition']; ?>
        </p>
    </a>
	<span class="glyphicon glyphicon-remove removeteam" title="Исключить из команды" style="float: right; cursor: pointer; margin-top: -45px" onclick="callCrudAction('deletefromteam', '<?php echo $row['id'] ?>')"></span>
	</div>
    <style>
        .glyphicon.glyphicon-envelope{
            position: absolute;
            float: right;
            right: 5px;
            margin-top: 7px;
        }
		
		
    </style>
	
    <?php
}if($result->num_rows == 0) {
    echo '
    <a href="#" class="list-group-item">
        <p class="list-group-item-text">Нет команды</p>
    </a>1
    ';
}
?>
