<?php
include("bd.php");

$user_id = $_POST['uid'];
$user_id = stripslashes($user_id);
$user_id = htmlspecialchars($user_id);
$user_id = trim($user_id);

$username = $_GET["username"];
$username = stripslashes($username);
$username = htmlspecialchars($username);
$username = trim($username);

$fullname = $_GET["fullname"];
$fullname = stripslashes($fullname);
$fullname = htmlspecialchars($fullname);
$fullname = trim($fullname);

$phone = $_GET["phone"];
$phone = stripslashes($phone);
$phone = htmlspecialchars($phone);
$phone = trim($phone);

$position = $_GET["position"];
$position = stripslashes($position);
$position = htmlspecialchars($position);
$position = trim($position);

$avatar = $_GET["avatar"];
$avatar = stripslashes($avatar);
$avatar = htmlspecialchars($avatar);
$avatar = trim($avatar);

$query = $conn->query("set names utf8");
$query = $conn->prepare("UPDATE Userslan SET avatar = '$avatar', username = '$username', fullname = '$fullname', phone = '$phone', userposition = '$position' WHERE id = ?");
$query->bind_param('i', $user_id);
$query->execute();
if ($conn->errno) {
    die('Select Error (' . $conn->errno . ') ' . $conn->error);
}
$query->close();

if($query){
    echo "<script>setTimeout(function(){location.reload()}, 1000);</script>";
}