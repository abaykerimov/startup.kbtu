<?php
session_start();
include("bd.php");
require 'phpmailer/PHPMailerAutoload.php';   

$projectid = $_POST['projectid'];
$projectid = stripslashes($projectid);
$projectid = htmlspecialchars($projectid);
$projectid = trim($projectid);

$mytext = $_POST['val'];
$mytext = stripslashes($mytext);
$mytext = htmlspecialchars($mytext);
$mytext = trim($mytext);

$res = $conn->query("set names utf8");
$res = $conn->query("SELECT id FROM Userslan WHERE fullname = '$mytext'");
$rows = $res->fetch_assoc();
$user_id = $rows['id'];
if (isset($mytext)) {
    $mytext = mysqli_real_escape_string($conn, $mytext);
    $insert_row = $conn->query("set names utf8");
    //$insert_row = $conn->query("INSERT INTO Usersproject ( project_id, user_id ) VALUES('$projectid', '$user_id')");
    $insert_row = $conn->prepare('INSERT INTO Usersproject (project_id, user_id) VALUES (?,?)');
    $insert_row->bind_param('ii', $projectid, $user_id);
    $insert_row->execute();

    $insert_id = $conn->insert_id;
    if ($insert_row) {
        $result = $conn->query("set names utf8");
        $sql = "SELECT * FROM Usersproject usp
        JOIN UploadProject up ON up.id = usp.project_id
		JOIN Userslan u ON u.id = usp.user_id
        WHERE usp.id = '$insert_id'";
        $result = $conn->query($sql);

        $row = $result->fetch_assoc();
        $projectname = $row['projectname'];
		$fullname = $row['fullname'];
        $userid = $row['user_id'];
        $project_id = $row['project_id'];
        $hour = date("H:i:s", time());
        $year = date("d-m-Y ");
        $date = $hour . " " . $year;
		$emails = $row['email'];

        if ($result) {
            $text = "<div style='color:#fff;margin-left: 15px;'><a style='color:#fff;'>Вас добавили в проект</a> <a href='project.php?id=$project_id'>$projectname</a></div>";
            $result2 = $conn->prepare('INSERT INTO Notifications(text, date, user_id) VALUES (?,?,?)');
            $result2->bind_param('ssi', $text, $date, $userid);
            $result2->execute();
			
			$mail = new PHPMailer;
					
			$message  = "<html><body>";
			$message .= "<table width='100%' bgcolor='#e0e0e0' cellpadding='0' cellspacing='0' border='0'>";		   
			$message .= "<tr><td>";		   
			$message .= "<table align='center' width='100%' border='0' cellpadding='0' cellspacing='0' style='max-width:650px; background-color:#fff; font-family:Verdana, Geneva, sans-serif;'>";	
			$message .= "<thead>
			  <tr height='80'>
			   <th colspan='4' style='background-color:#f5f5f5; border-bottom:solid 1px #bdbdbd; font-family:Verdana, Geneva, sans-serif; color:#333; font-size:34px;' >Coding Cage</th>
			  </tr>
			  </thead>";
			$message .= "<tbody>
			  <tr align='center' height='50' style='font-family:Verdana, Geneva, sans-serif;'>
			   <td style='background-color:#00a2d1; text-align:center;'><a href='http://www.codingcage.com/search/label/PDO' style='color:#fff; text-decoration:none;'>PDO</a></td>
			   <td style='background-color:#00a2d1; text-align:center;'><a href='http://www.codingcage.com/search/label/jQuery' style='color:#fff; text-decoration:none;'>jQuery</a></td>
			   
			  </tr>
			  
			  <tr>
			   <td colspan='4' style='padding:15px;'>
				
				<p style='font-size:25px;'>Sending HTML eMail using PHPMailer</p>
				<img src='https://4.bp.blogspot.com/-rt_1MYMOzTs/VrXIUlYgaqI/AAAAAAAAAaI/c0zaPtl060I/s1600/Image-Upload-Insert-Update-Delete-PHP-MySQL.png' alt='Sending HTML eMail using PHPMailer in PHP' title='Sending HTML eMail using PHPMailer in PHP' style='height:auto; width:100%; max-width:100%;' />
			   </td>
			  </tr>
			  
			  </tbody>";
			
			$message .= "</table>";   
			$message .= "</td></tr>";
			$message .= "</table>";   
			$message .= "</body></html>";

			$mail->isSMTP();                                      
			$mail->Host = 'smtp.mail.ru';  
			$mail->SMTPAuth = true;                               
			$mail->Username = 'startup.kbtu.kz@inbox.ru';                
			$mail->Password = 'Incubator2016';                           
			$mail->SMTPSecure = 'ssl';                            
			$mail->Port = 465;                                    
			$mail->From = 'startup.kbtu.kz@inbox.ru';
			$mail->FromName = 'startup@kbtu.kz';
			$mail->addAddress($emails);
			$mail->CharSet = "UTF-8";
			$mail->Subject = 'реги';
			$mail->Subject = 'Вас добавили в команду';
			$mail->Body = $message;
			$mail->ClearCustomHeaders();
			$mail->isHTML(true);                                  
			$mail->send();
        }
		if ($result2) {
			$text = '<a href="profile.php?id='.$userid.'">'.$fullname.'</a> присоединился к проекту "'.$projectname.'"';
			$result3 = $conn->prepare('INSERT INTO Updates(text, date, user_id, project_id, isNotification) VALUES (?,?,?,?,2)');
			$result3->bind_param('ssii', $text, $date, $userid, $project_id);
			$result3->execute();
        }
		if ($result3) {
			$result4 = $conn->prepare('INSERT INTO SubscribeProject (user_id, project_id, date, own) VALUES (?,?,?,1)');
			$result4->bind_param('iis', $userid, $project_id, $date);
			$result4->execute();
        }
    }


}
//echo '<script>alert('.$insert_id.')</script>';


?>