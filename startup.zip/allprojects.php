<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("bd.php");
$id = $_SESSION['user_id'];
//require_once 'classes/Auth.class.php';
if (!isset($id)){
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />

    <title>Все проекты</title>
    <link rel="canonical" href=""/>
    <meta name="robots" content="index, follow" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="css/main.less">
    <script type="text/javascript" src="js/less.min.js"></script>

    <style>
        .row-all-project {
            margin: 0;
            padding: 0;
            vertical-align: top;
            background-color: white!important;
            border: none!important;
        }
        .row-all-project h4 {
            border-bottom: 2px solid #dddddd;
            padding: 10px 15px;
            margin: 0;
            color:black;
        }
        .row-all-project a {
            border-bottom: 1px solid #dddddd;
            padding: 7px 10px;
            margin: 0;
            display: block;
            text-shadow: none;
        }
        .row-all-project a:hover {
            background-color: #f6f6f6;
        }
        .row-all-project:hover h4 {
            background-color: #f6f6f6;
        }
        table.dataTable{clear:both;margin-top:6px !important;margin-bottom:6px !important;max-width:none !important}table.dataTable td,table.dataTable th{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box}table.dataTable td.dataTables_empty,table.dataTable th.dataTables_empty{text-align:center}table.dataTable.nowrap th,table.dataTable.nowrap td{white-space:nowrap}div.dataTables_wrapper div.dataTables_length label{font-weight:normal;text-align:left;white-space:nowrap}div.dataTables_wrapper div.dataTables_length select{width:75px;display:inline-block}div.dataTables_wrapper div.dataTables_filter{text-align:right}div.dataTables_wrapper div.dataTables_filter label{font-weight:normal;white-space:nowrap;text-align:left}div.dataTables_wrapper div.dataTables_filter input{margin-left:0.5em;display:inline-block;width:auto}div.dataTables_wrapper div.dataTables_info{padding-top:8px;white-space:nowrap}div.dataTables_wrapper div.dataTables_paginate{margin:0;white-space:nowrap;text-align:right}div.dataTables_wrapper div.dataTables_paginate ul.pagination{margin:2px 0;white-space:nowrap}div.dataTables_wrapper div.dataTables_processing{position:absolute;top:50%;left:50%;width:200px;margin-left:-100px;margin-top:-26px;text-align:center;padding:1em 0}table.dataTable thead>tr>th.sorting_asc,table.dataTable thead>tr>th.sorting_desc,table.dataTable thead>tr>th.sorting,table.dataTable thead>tr>td.sorting_asc,table.dataTable thead>tr>td.sorting_desc,table.dataTable thead>tr>td.sorting{padding-right:30px}table.dataTable thead>tr>th:active,table.dataTable thead>tr>td:active{outline:none}table.dataTable thead .sorting,table.dataTable thead .sorting_asc,table.dataTable thead .sorting_desc,table.dataTable thead .sorting_asc_disabled,table.dataTable thead .sorting_desc_disabled{cursor:pointer;position:relative}table.dataTable thead .sorting:after,table.dataTable thead .sorting_asc:after,table.dataTable thead .sorting_desc:after,table.dataTable thead .sorting_asc_disabled:after,table.dataTable thead .sorting_desc_disabled:after{position:absolute;bottom:8px;right:8px;display:block;font-family:'Glyphicons Halflings';opacity:0.5}table.dataTable thead .sorting:after{opacity:0.2;content:"\e150"}table.dataTable thead .sorting_asc:after{content:"\e155"}table.dataTable thead .sorting_desc:after{content:"\e156"}table.dataTable thead .sorting_asc_disabled:after,table.dataTable thead .sorting_desc_disabled:after{color:#eee}div.dataTables_scrollHead table.dataTable{margin-bottom:0 !important}div.dataTables_scrollBody table{border-top:none;margin-top:0 !important;margin-bottom:0 !important}div.dataTables_scrollBody table thead .sorting:after,div.dataTables_scrollBody table thead .sorting_asc:after,div.dataTables_scrollBody table thead .sorting_desc:after{display:none}div.dataTables_scrollBody table tbody tr:first-child th,div.dataTables_scrollBody table tbody tr:first-child td{border-top:none}div.dataTables_scrollFoot table{margin-top:0 !important;border-top:none}@media screen and (max-width: 767px){div.dataTables_wrapper div.dataTables_length,div.dataTables_wrapper div.dataTables_filter,div.dataTables_wrapper div.dataTables_info,div.dataTables_wrapper div.dataTables_paginate{text-align:center}}table.dataTable.table-condensed>thead>tr>th{padding-right:20px}table.dataTable.table-condensed .sorting:after,table.dataTable.table-condensed .sorting_asc:after,table.dataTable.table-condensed .sorting_desc:after{top:6px;right:6px}table.table-bordered.dataTable{border-collapse:separate !important}table.table-bordered.dataTable th,table.table-bordered.dataTable td{border-left-width:0}table.table-bordered.dataTable th:last-child,table.table-bordered.dataTable th:last-child,table.table-bordered.dataTable td:last-child,table.table-bordered.dataTable td:last-child{border-right-width:0}table.table-bordered.dataTable tbody th,table.table-bordered.dataTable tbody td{border-bottom-width:0}div.dataTables_scrollHead table.table-bordered{border-bottom-width:0}div.table-responsive>div.dataTables_wrapper>div.row{margin:0}div.table-responsive>div.dataTables_wrapper>div.row>div[class^="col-"]:first-child{padding-left:0}div.table-responsive>div.dataTables_wrapper>div.row>div[class^="col-"]:last-child{padding-right:0}

        .alert-box {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        .success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
            display: none;
        }
        #logoutbtn {
            background-color: transparent;
            font-size: 13px;
            color: white;
            padding: 12px 15px;
            margin-bottom: 10px;
            border-color: transparent;
        }
        #logoutbtn:hover {
            background: black;
        }

        .col-lg-9 {
            margin-bottom: 15px;
        }
    </style>

</head>
<body>

<!-- Верхний навбар, всегда одинаковый, брать с файла home.php -->
<nav class="navbar navbar-default" style="z-index: 10">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">iKBTU Incubator</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <!-- Активный элемент меню это у ли класс актив и  <span class="sr-only">(current)</span> -->
                <li><a href="timeline.php">Лента <span class="sr-only">(current)</span></a></li>
                <li class="active"><a href="#">Проекты</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <!-- Это кнопка с уведомлениями -->
                <?php
                $result = $conn->query("set names utf8");
                $sql = "SELECT COUNT(user_id) as cnt FROM Notifications WHERE user_id = '$id'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                    ?>
                    <li><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="glyphicon glyphicon-info-sign"></span><span class="nav badge"><?php echo $row['cnt'] ?></span></a>
                        <ul class="dropdown-menu notificate" role="menu">
                        </ul>
                    </li>
                <?php } } ?>
                <!-- Это кнопка действиями над профилем -->
                <?php
                $result = $conn->query("set names utf8");
                $id = $_SESSION['user_id'];
                $sql = "SELECT id, fullname FROM Userslan WHERE id=$id";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {

                while($row = $result->fetch_assoc()) {
                ?>
                <!-- Это кнопка действиями над профилем -->
                <li><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><?php echo $row['fullname'] ?><span class="caret"></span></a>
                    <?php
                    }
                    }
                    ?>

                    <ul class="dropdown-menu" role="menu">

                        <li><a href="#user_profile" role="button" data-toggle="modal">Настройки</a></li>
                        <li class="divider"></li>
                        <form class="ajax" method="post" action="./logout.php">
                            <button id="logoutbtn" type="submit">Выход</button>
                        </form>

                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>


<div id="contant">
    <ul class="nav nav-tabs">
        <li class="active"><a aria-expanded="true" href="#studied" data-toggle="tab">По стадиям</a></li>
        <li class=""><a aria-expanded="false" href="#category" data-toggle="tab">По категориям</a></li>
        <li class=""><a aria-expanded="false" href="#tables" data-toggle="tab">Таблица</a></li>
    </ul>
    <div id="myTabContent" class="tab-content">
        <div class="tab-pane fade active in" id="studied">
            <!-- Внутри ничего не нужно, кроме -->
            <div class="btn-group btn-group-justified" id="advanced">
                <?php
                $result = $conn->query("set names utf8");
                $sql = "SELECT * FROM Stage";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $sid = $row['id'];
                        ?>
                        <div class="btn btn-default row-all-project drag" id="advanced<?php echo $sid ?>" data-id="<?php echo $sid ?>">
                            <h4 class="block__list-title"><?php echo $row['stagename']; ?></h4>
                            <?php
                            echo "";
                            $result2 = $conn->query("set names utf8");
                            $sql2 = "SELECT * FROM UploadProject WHERE stage_id = '$sid'";
                            $result2 = $conn->query($sql2);
                            if ($result2->num_rows > 0) {
                                while ($row2 = $result2->fetch_assoc()) {
                                    ?>
                                    <a data-id="<?php echo $row2['id'] ?>" href="project.php?id=<?php echo $row2['id'] ?>&stage=1"><?php echo $row2['projectname']; ?></a>
                                    <?php
                                }
                            }
                            ?>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
        </div>

        <div class="tab-pane fade" id="category">

            <div class="btn-group btn-group-justified">
                <?php
                $result = $conn->query("set names utf8");
                $sql = "SELECT * FROM Category";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $sid = $row['id'];
                        ?>
                        <div class="btn btn-default row-all-project">
                            <h4 class="block__list-title"><?php echo $row['name']; ?></h4>
                            <?php
                            echo "";
                            $result2 = $conn->query("set names utf8");
                            $sql2 = "SELECT * FROM UploadProject WHERE category_id = '$sid'";
                            $result2 = $conn->query($sql2);
                            if ($result2->num_rows > 0) {
                                while ($row2 = $result2->fetch_assoc()) {
                                    ?>
                                    <a href="project.php?id=<?php echo $row2['id'] ?>&stage=1"><?php echo $row2['projectname']; ?></a>
                                    <?php
                                }
                            }
                            ?>
                        </div>
                        <?php
                    }
                }
                ?>

            </div>

        </div>
        <?php
        $result3 = $conn->query("set names utf8");
        $sql3 = "SELECT p.id, p.projectname, p.description, c.name, s.stagename, p.team
                   FROM UploadProject p
                   JOIN Category c ON c.id = p.category_id
                   JOIN Stage s ON s.id = p.stage_id";
        $result3 = $conn->query($sql3);

        if ($result3->num_rows > 0) { ?>
            <div class="tab-pane fade" id="tables">
                <table class="table table-striped table-hover " id="tablesorted" style="width: 100%">
                    <thead>
                    <tr>
                        <th class='th_name'>№</th>
                        <th>Название проекта</th>
                        <th>Описание</th>
                        <th>Категория</th>
                        <th>Стадия</th>
                        <th>Команда</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    // output data of each row
                    while ($row3 = $result3->fetch_assoc()) {
                        ?>
                        <tr>
                            <input type="hidden" value="<?php echo $row3['id'] ?>" class="hidden" name="hidden">
                            <td><?php echo $row3['id'] ?></td>
                            <td>
                                <a href="project.php?id=<?php echo $row3['id'] ?>&stage=1"><?php echo $row3['projectname'] ?></a>
                            </td>
                            <td><?php echo $row3['description'] ?></td>

                            <td><?php echo $row3['name'] ?></td>
                            <td><?php echo $row3['stagename'] ?></td>
                            <td><?php echo $row3['team'] ?></td>
                        </tr>
                        <?php
                    }
                    ?>
                    </tbody></table></div>
            <?php
        }
        ?>
    </div>

    <?php
    $id = $_SESSION["user_id"];
    $result = $conn->query("set names utf8");
    $sql = "SELECT * FROM Userslan WHERE id = '$id'";
    $result = $conn->query($sql);
    while($row = $result->fetch_assoc()) {
        ?>
        <!-- Редактировать личный кабинет модалка -->
        <div class="modal fade" id="user_profile">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove"></span></button>
                        <h4 class="modal-title">Редактировать личный кабинет</h4>
                    </div>
                    <div class="modal-body">

                        <fieldset>
                            <input name="uid" type="hidden" class="uid" value="<?php echo $row['id']; ?>">

                            <div class="form-group">
                                <label for="inputFoto" class="col-lg-3 control-label">Сменить аватар</label>
                                <div class="col-lg-9">
                                    <form id="uploadForm" action="upload.php" method="post">
                                        <div id="targetLayer">
                                            <img id="avatar" src="<?php echo $row['avatar']; ?>" width="100px" height="100px" />
                                        </div>
                                        <div id="uploadFormLayer">

                                    <span class="btn btn-default btn-file">
                                        Выбрать <input name="userImage" type="file" class="inputFile" />
                                    </span>

                                            <button type="submit" class="btn btn-success btnSubmit">Загрузить</button>
                                        </div>
                                    </form>
                                </div>
                                <!--<form action="upload.php"><div class="col-lg-9">
                                    <input class="form-control" id="selectphoto" placeholder="" type="file">
                                </div></form>-->
                            </div>
							<div class="form-group">
								<label for="username" class="col-lg-3 control-label">Никнейм</label>
								<div class="col-lg-9">
									<input name="username" id="username" class="form-control" value="<?php echo $row['username']; ?>" placeholder="Ваш никнейм" type="text">
								</div>
							</div>
                            <div class="form-group">
                                <label for="inputEmail" class="col-lg-3 control-label">Email</label>
                                <div class="col-lg-9">
                                    <input name="email" disabled="" class="form-control email" placeholder="Ваш email" type="text" value="<?php echo $row['email']; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="name_com" class="col-lg-3 control-label">ФИО</label>
                                <div class="col-lg-9">
                                    <input name="fullname" id="userfullname" class="form-control" value="<?php echo $row['fullname']; ?>" placeholder="Ваше ФИО" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="con_tel" class="col-lg-3 control-label">Контактный телефон</label>
                                <div class="col-lg-9">
                                    <input name="phone" class="form-control" id="userphone" placeholder="Контактный телефон" pattern="+7 ([0-9]{3}) [0-9]{3}-[0-9]{2}-[0-9]{2}" type="tel" value="<?php echo $row['phone']; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="bin" class="col-lg-3 control-label">Должность</label>
                                <div class="col-lg-9">
                                    <select id="userposition" name="position" class="form-control">
                                        <option
                                            value="UI дизайнер"<?php if ($row['userposition'] == 'UI дизайнер') echo ' selected="selected"'; ?>>
                                            UI дизайнер
                                        </option>
                                        <option
                                            value="PHP разработчик"<?php if ($row['userposition'] == 'PHP разработчик') echo ' selected="selected"'; ?>>
                                            PHP разработчик
                                        </option>
                                        <option
                                            value="Web-маркетолог"<?php if ($row['userposition'] == 'Web-маркетолог') echo ' selected="selected"'; ?>>
                                            Web-маркетолог
                                        </option>
                                        <option
                                            value="Мобильный разработчик"<?php if ($row['userposition'] == 'Мобильный разработчик') echo ' selected="selected"'; ?>>
                                            Мобильный разработчик
                                        </option>

                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <div id="editnot" class="col-lg-9 col-lg-offset-3">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                    <button type="submit" class="btn btn-primary update_info" onclick="editUser('<?php echo $row['id'] ?>')">Сохранить</button>
                                </div>
                            </div>
                        </fieldset>
                        <!--<form class="form-horizontal">
                            <div class="alert alert-dismissible alert-success dnone">
                                Пароль успешно обновлен!
                            </div>
                            <fieldset>
                                <legend>Сменить пароль</legend>
                                <div class="form-group">
                                    <label for="inputPassword1" class="col-lg-3 control-label">Старый пароль</label>
                                    <div class="col-lg-9">
                                        <input class="form-control oldpass" name="oldpass" id="inputPassword1" placeholder="Старый пароль" type="password">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputPassword2" class="col-lg-3 control-label">Новый пароль</label>
                                    <div class="col-lg-9">
                                        <input class="form-control pass" id="inputPassword2" name="pass" placeholder="Новый пароль" type="password">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputPassword3" class="col-lg-3 control-label">Еще раз</label>
                                    <div class="col-lg-9">
                                        <input class="form-control pass1" id="inputPassword3" placeholder="Повторите пароль" type="password">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <div class="col-lg-9 col-lg-offset-3">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                        <button type="submit" class="btn btn-primary update_pass">Сохранить</button>
                                    </div>
                                </div>
                            </fieldset>
                        </form>-->
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    ?>
    <!-- тут всегда лучше все модалки выводить из home.php -->
</body>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
<script src="https://bootswatch.com/bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slideout/0.1.11/slideout.min.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="js/jquery.maskedinput.js" type="text/javascript"></script>

<script type="text/javascript">
    jQuery(function($){
        $("#userphone").mask("+7 (999) 999-9999");
    });
</script>

<!-- Latest Sortable -->
<script src="http://rubaxa.github.io/Sortable/Sortable.js"></script>

<script src="./js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.11/js/dataTables.bootstrap.min.js"></script>
<script>
    /*$(document).ready(function() {
        $('#tablesorted').DataTable();
    } );*/

    $(function(){
        $("#tablesorted").dataTable({
            "bPaginate": false,
            "bLengthChange": false,

            "aoColumnDefs":[{
                "aTargets": [ "th_name" ]
            },{
                "aTargets": [ 1 ]
                , "bSortable": false
            }
            ]
        });


    })
</script>

<script>
    function editUser(userid) {
        var ava = $("img#avatar").attr('src');
        //alert(ava);
        var ab = $(".modal-body").find("#username").val();
        var bc = $(".modal-body").find("#userfullname").val();
        var cd = $(".modal-body").find("#userphone").val();
        var de = $(".modal-body").find("#userposition").val();
        //alert(ab, bc, cd, de);
        //console.log(ab, bc, cd, de);
        $.ajax({
            url: "edituser.php?avatar="+ava+"&username="+ab+"&fullname="+bc+"&phone="+cd+"&position="+de,
            type: "POST",
            data:  {uid:userid},
            success: function(){
                //console.log(userid, bc, cd, de);
                $("#editnot").append("<div id='importmsg' class='alert-box success'>Ваш профиль успешно изменен</div>");
                $( "div#importmsg" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                setTimeout(function () {
                    location.reload();
                }, 2000);
            }
        });
    }
</script>
<style>

    .bgColor label{
        font-weight: bold;
        color: #A0A0A0;
    }
    #targetLayer{
        float:left;
        width:100px;
        height:100px;
        text-align:center;
        line-height:100px;
        font-weight: bold;
        color: #C0C0C0;
        background-color: #F0E8E0;
        overflow:auto;
    }
    #uploadFormLayer{
        float:right;
    }
    .btnSubmit {
        background-color: #3FA849;
        padding:4px;
        border: #3FA849 1px solid;
        color: #FFFFFF;
    }
    .inputFile {
        padding: 3px;
        background-color: #FFFFFF;
    }

    .btn.btn-default.btn-file {
        position: relative;
        overflow: hidden;
        padding: 4px 8px;
    }
    .btn-file input[type=file] {
        position: absolute;
        top: 0;
        right: 0;
        min-width: 100%;
        min-height: 100%;
        font-size: 100px;
        text-align: right;
        filter: alpha(opacity=0);
        opacity: 0;
        outline: none;
        background: white;
        cursor: inherit;
        display: block;
    }
</style>
<script type="text/javascript">
    $(document).ready(function (e) {
        $("#uploadForm").on('submit',(function(e) {
            e.preventDefault();
            $.ajax({
                url: "upload.php",
                type: "POST",
                data:  new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success: function(data)
                {
                    $("#targetLayer").html(data);
                },
                error: function()
                {
                }
            });
        }));
    });
</script>
<!--<script>
    var byId = function (id) { return document.getElementById(id); };

    var elems = document.getElementsByClassName("row-all-project");
    elems = Array.prototype.slice.call(elems); // теперь elems - массив
    elems.forEach(function(aaa,i) { // нет такого метода!
        Sortable.create(byId('advanced' + (i + 1)), {
            sort: true,
            group: "sorting",
            animation: 150,
            filter: ".block__list-title",
            onAdd: function (/**Event*/evt) {
                var itemEl = evt.item;  // dragged HTMLElement
                //evt.from;  // previous list
                // + indexes from onEnd
                //ЗДЕСЬ ПОКАЗЫВАЕМ ID ЭЛЕМЕНТА КОТОРЫЙ ПЕРЕТАЩИЛИ
                var a = (itemEl.getAttribute("data-id"));
                //alert(itemEl.getAttribute("data-id"));
                //ЗДЕСЬ ПОКАЗЫВАЕМ ID КУДА перетащили ЭЛЕМЕНТ
                var b = (evt.to.getAttribute("data-id"));
                //alert(evt.to.getAttribute("data-id"));

                $.ajax({
                    url: "updatestage.php",
                    type: "POST",
                    data: {project_id: a, stage_id: b},
                    success: function (data) {
                        console.log(a, b);
                        $('#contant').append("<div class='alert-box success'>Стадия проекта изменена!</div>");
                        $( "div.success" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                        /*setTimeout(function() {
                         $('div.success').fadeOut();
                         $('body').load('#contant');
                         }, 2000);*/
                        //window.location = "allprojects.php";
                    }
                });
                $( "div.success").remove();
            },
        });
    });

</script>-->
<script>
    $(document).ready(function() {
        $(".dropdown-menu.notificate").load("displaynotification.php");
    })

    function callAction(action, id) {
        var queryString;
        switch (action) {
            case "remove":
                queryString = 'action=' + action + '&user_id=' + id;
                break;
        }
        jQuery.ajax({
            url: "crud_action.php",
            data: queryString,
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "remove":
                        $('.usernotification').fadeOut();
                        break;
                }
                $(".nav.badge").text('0');
            },
            error: function () {

            }
        });
    }
</script>
</html>