<?php
include("bd.php");
if (!isset($_GET['channel'])){
    $channel = $_GET['channel'];
}
$channel = $_GET['channel'];
$result = $conn->query("set names utf8");
$sql = "SELECT u.id, u.fullname FROM Channeluser cu
                JOIN Userslan u ON u.id = cu.user_id
                WHERE cu.channel_id = '$channel'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        ?>
        <a href="profile.php?id=<?php echo $row['id'] ?>" class="list-group-item">
            <p class="list-group-item-text"><span><?php echo $row['fullname'] ?></span></p>
        </a>
        <?php
    }
}
?>