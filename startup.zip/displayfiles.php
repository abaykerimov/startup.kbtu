<?php
session_start();
include("bd.php");
if (!isset($_GET['channel'])){
    $channel = $_GET['channel'];
}
$channel = $_GET['channel'];
$id = $_SESSION["user_id"];
$result = $conn->query("set names utf8");
$sql = "SELECT * FROM Chat WHERE channel_id = '$channel'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    $newstring = substr($row['message'], -4);
    if(preg_match('/uploads/',$row['message'])) {
        if ($newstring == "docx" || $newstring == "pptx" || $newstring == ".pdf" || $newstring == ".doc") {
            ?>
            <a href="<?php echo $row['message'] ?>" class="list-group-item text-left" target="_blank">
                <p class="list-group-item-text"><span class="glyphicon glyphicon-link"></span> <span>
				<?php echo $row['filename'] ?></span>
                </p>
            </a>
            <?php
        }
    }
}
?>