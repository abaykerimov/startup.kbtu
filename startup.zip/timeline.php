<?php
header('Content-type: text/html; charset=utf8');

session_start();
include("bd.php");
$id = $_SESSION['user_id'];
if (!isset($id)){
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

    <title>Лента</title>
    <link rel="canonical" href=""/>
    <meta name="robots" content="index, follow" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link rel="apple-touch-icon" sizes="57x57" href="/favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/favicons/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="/favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="/favicons/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="css/main.less">
    <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="js/less.min.js"></script>
    <style>
        .alert-box {
            padding: 15px;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        .success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
            display: none;
        }

        .panel-body .list-group-item {
            overflow: hidden;
            margin: -9px;
            padding: 6px;
        }

        #logoutbtn {
            background-color: transparent;
            font-size: 13px;
            color: white;
            padding: 12px 15px;
            margin-bottom: 10px;
            border-color: transparent;
        }
        #logoutbtn:hover {
            background: black;
        }

        .col-lg-9 {
            margin-bottom: 15px;
        }
    </style>

</head>

<body>
<!-- Верхний навбар, всегда одинаковый, брать с файла home.php -->
<nav class="navbar navbar-default" style="z-index: 10">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">iKBTU Incubator</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <!-- Активный элемент меню это у ли класс актив и  <span class="sr-only">(current)</span> -->
                <li class="active"><a href="#">Лента <span class="sr-only">(current)</span></a></li>
                <li><a href="allprojects.php">Проекты</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <!-- Это кнопка с уведомлениями -->
                <?php
                $result = $conn->query("set names utf8");
                $sql = "SELECT COUNT(user_id) as cnt FROM Notifications WHERE user_id = '$id'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                    ?>
                    <li><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="glyphicon glyphicon-info-sign"></span><span class="nav badge"><?php echo $row['cnt'] ?></span></a>
                        <ul class="dropdown-menu notificate" role="menu">
                        </ul>
                    </li>
                <?php } } ?>
                <!-- Это кнопка действиями над профилем -->
                <?php
                $result = $conn->query("set names utf8");
                $id = $_SESSION['user_id'];
                $sql = "SELECT id, fullname FROM Userslan WHERE id=$id";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {

                while($row = $result->fetch_assoc()) {
                ?>
                <!-- Это кнопка действиями над профилем -->
                <li><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><?php echo $row['fullname'] ?><span class="caret"></span></a>
                    <?php
                    }
                    }
                    ?>

                    <ul class="dropdown-menu" role="menu">

                        <li><a href="#user_profile" role="button" data-toggle="modal">Настройки</a></li>
                        <li class="divider"></li>
                        <form class="ajax" method="post" action="./logout.php">
                            <button id="logoutbtn" type="submit">Выход</button>
                        </form>

                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div id="contant">

    <!-- Правая колонка своя, можно схитрить, и на этой странице выводить только все проекты, при нажатии на проект оправлять его на страницу index_news.php -->
    <div class="col-lg-2 text-center blocks">
        <div class="panel panel-default">
            <div class="panel-heading">Проекты по стадиям <span class="glyphicon glyphicon-chevron-down"></span></div>
            <div class="panel-body" style="display: none">
                <div class="list-group text-left">
                    <!-- Общая лента -->
                    <a href="#" class="list-group-item" style="margin-bottom: 9px;">Общая лента</a>
                </div>
                <?php
                $result = $conn->query("set names utf8");
                $sql = "SELECT * FROM Stage";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                $sid = $row['id'];
                ?>
                    <h5 style="margin-bottom: -5px; margin-top: -2px;"><?php echo $row['stagename']; ?></h5>
                    <br>
                <?php
                echo '<div class="list-group text-left">';
                $result2 = $conn->query("set names utf8");
                $sql2 = "SELECT up.id, up.projectname, up.short FROM SubscribeProject sp
                JOIN UploadProject up ON up.id = sp.project_id
                WHERE stage_id = '$sid' AND sp.user_id = '$id'";
                $result2 = $conn->query($sql2);
                if ($result2->num_rows > 0) {
                    while ($row2 = $result2->fetch_assoc()) {
                        ?>
                            <a href="<?php echo $row2['short']; ?>" class="list-group-item"><?php echo $row2['projectname']; ?></a>
                        <br>
                        <?php
                    }
                }
                echo "</div>";//list-group text-left
                }

                }
                ?>
            </div>
        </div>

    </div>

    <!-- Центральная колонка опять 10, правой нету -->
    <div class="col-lg-10 text-center blocks">
        <!-- Либо название проекта либо общая лента -->
        <!-- новости точно такие же как и у проекта -->
        <!-- новость, везде одинаковый шаблон-->

            <?php
            $user_id = $_SESSION['user_id'];
            //echo $user_id;
            $result = $conn->query("set names utf8");
            $sql = "SELECT u.id AS userid, u.avatar, up.id AS updateid, up.text AS news, sp.user_id, up.heading, up.project_id, u.fullname, upl.projectname, up.date, up.isNotification, upl.short FROM SubscribeProject sp
                    JOIN Updates up ON sp.project_id = up.project_id
                    JOIN Userslan u ON up.user_id = u.id
                    JOIN UploadProject upl ON up.project_id = upl.id
					
                    WHERE sp.user_id = '$user_id' ORDER by updateid DESC";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
					$short = $row['short'];
                    $update_id = $row['updateid'];
                    ?>
                    <input id="hidusid" type="hidden" value="<?php echo $id ?>">
                    <div class="list-group text-left news">
                    <div data-id="<?php echo $update_id ?>" class="list-group-item updid">
                        <input name="updateid" type="hidden" value="<?php echo $update_id ?>">
						<?php if($row['isNotification'] == 0) { ?>
                        <!-- шапка новости-->
                        <h6 class="list-group-item-heading"><img src="<?php echo $row['avatar'] ?>" alt="Имя Фамилия"> <a href="profile.php?id=<?php echo $row["userid"]; ?>"><?php echo $row['fullname'] ?></a> > <a href="project.php?id=<?php echo $row["project_id"]; ?>&stage=1"><?php echo $row['projectname'] ?></a><span class="info"><?php echo $row['date'] ?></span></h6>
                            <hr>
                        <!-- заголовок новости-->
                        <h5 class="list-group-item-heading"><?php echo $row["heading"]; ?></h5>
                        <!-- текст новости-->
                        <p class="list-group-item-text">
                            <?php echo $row["news"]; ?>
                        </p>
                            <hr>
                        <?php
                        $sql8 = "SELECT * FROM UpdateLikes WHERE user_id = '$id' AND update_id = '$update_id'";
                        $result8 = $conn->query($sql8);
                        if (mysqli_num_rows($result8) == 1) {
                        ?>
                            <a id="likebtn_<?php echo $update_id ?>" role="button" onclick="unlike('<?php echo $update_id ?>')"><span class="glyphicon glyphicon-heart-empty"></span> Unlike</a>
                        <?php
                        } else {
                        ?>
                            <a id="likebtn_<?php echo $update_id ?>" role="button" onclick="like('<?php echo $update_id ?>')"><span class="glyphicon glyphicon-heart"></span> Like</a>
                        <?php
                        }
                        ?>

						<div style="display: inline-block"><a href="<?php echo $short ?>/<?php echo $update_id ?>"><span class="glyphicon glyphicon-send"></span> Share</a></div>
                            <a role="button" onclick="$(this).parent().find('.commenttext').focus();"><span class="glyphicon glyphicon-comment"></span> Comment</a>
                            <div id="likeload_<?php echo $update_id ?>"></div>
                        <div class="bg_gray">
                            <div id="listcomment_<?php echo $update_id ?>" class="list-group comment">
                                <!-- комментарий-->
                            </div>
                            <!-- новый комментарий-->
                            <textarea name="commenttext" id="commenttext_<?php echo $update_id ?>" class="form-control commenttext" rows="2">Добавить комментарий...</textarea>
                            <!--<button id="commentbtn_<?php echo $update_id ?>" type="submit" class="btn btn-primary btn-xs btn-block" onclick="create('<?php echo $update_id ?>')">Добавить комментарий</button>-->
                            <button data-id="<?php echo $update_id ?>" type="submit" class="btn btn-primary btn-xs dnone JScommentbtn"> Отправить</button>
                        </div>
						<?php } else if($row['isNotification'] == 1) {
                        ?>
                        <h6 class="list-group-item-heading"><img src="<?php echo $row['avatar'] ?>"> <a href="profile.php?id=<?php echo $row["userid"]; ?>"><?php echo $row['fullname'] ?></a> подписался на проект <a href="project.php?id=<?php echo $row["project_id"]; ?>&stage=1"><?php echo $row['projectname'] ?></a><span class="info"><?php echo $row['date'] ?></span></h6>
                        <?php
                        } else if($row['isNotification'] == 2) {
                        ?>
                        <h6 class="list-group-item-heading"><img src="<?php echo $row['avatar'] ?>"> <a href="profile.php?id=<?php echo $row["userid"]; ?>"><?php echo $row['fullname'] ?></a> присоединился к проекту <a href="project.php?id=<?php echo $row["project_id"]; ?>&stage=1"><?php echo $row['projectname'] ?></a><span class="info"><?php echo $row['date'] ?></span></h6>
                        <?php
                        } ?>
                    </div>
                </div>
            <?php } } ?>
    </div>

    <?php
    $id = $_SESSION["user_id"];
    $result = $conn->query("set names utf8");
    $sql = "SELECT * FROM Userslan WHERE id = '$id'";
    $result = $conn->query($sql);
    while($row = $result->fetch_assoc()) {
        ?>
            <!-- Редактировать личный кабинет модалка -->
    <div class="modal fade" id="user_profile">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove"></span></button>
                    <h4 class="modal-title">Редактировать личный кабинет</h4>
                </div>
                <div class="modal-body">

                    <fieldset>
                        <input name="uid" type="hidden" class="uid" value="<?php echo $row['id']; ?>">

                        <div class="form-group">
                            <label for="inputFoto" class="col-lg-3 control-label">Сменить аватар</label>
                            <div class="col-lg-9">
                            <form id="uploadForm" action="upload.php" method="post">
                                <div id="targetLayer">
                                    <img id="avatar" src="<?php echo $row['avatar']; ?>" width="100px" height="100px" />
                                </div>
                                <div id="uploadFormLayer">

                                    <span class="btn btn-default btn-file">
                                        Выбрать <input name="userImage" type="file" class="inputFile" />
                                    </span>

                                    <button type="submit" class="btn btn-success btnSubmit">Загрузить</button>
                                </div>
                            </form>
                            </div>
                            <!--<form action="upload.php"><div class="col-lg-9">
                                <input class="form-control" id="selectphoto" placeholder="" type="file">
                            </div></form>-->
                        </div>
						<div class="form-group">
                            <label for="username" class="col-lg-3 control-label">Никнейм</label>
                            <div class="col-lg-9">
                                <input name="username" id="username" class="form-control" value="<?php echo $row['username']; ?>" placeholder="Ваш никнейм" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmail" class="col-lg-3 control-label">Email</label>
                            <div class="col-lg-9">
                                <input name="email" disabled="" class="form-control email" placeholder="Ваш email" type="text" value="<?php echo $row['email']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="name_com" class="col-lg-3 control-label">ФИО</label>
                            <div class="col-lg-9">
                                <input name="fullname" id="userfullname" class="form-control" value="<?php echo $row['fullname']; ?>" placeholder="Ваше ФИО" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="con_tel" class="col-lg-3 control-label">Контактный телефон</label>
                            <div class="col-lg-9">
                                <input name="phone" class="form-control" id="userphone" placeholder="Контактный телефон" pattern="+7 ([0-9]{3}) [0-9]{3}-[0-9]{2}-[0-9]{2}" type="tel" value="<?php echo $row['phone']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="bin" class="col-lg-3 control-label">Должность</label>
                            <div class="col-lg-9">
                                <select id="userposition" name="position" class="form-control">
                                    <option
                                        value="UI дизайнер"<?php if ($row['userposition'] == 'UI дизайнер') echo ' selected="selected"'; ?>>
                                        UI дизайнер
                                    </option>
                                    <option
                                        value="PHP разработчик"<?php if ($row['userposition'] == 'PHP разработчик') echo ' selected="selected"'; ?>>
                                        PHP разработчик
                                    </option>
                                    <option
                                        value="Web-маркетолог"<?php if ($row['userposition'] == 'Web-маркетолог') echo ' selected="selected"'; ?>>
                                        Web-маркетолог
                                    </option>
                                    <option
                                        value="Мобильный разработчик"<?php if ($row['userposition'] == 'Мобильный разработчик') echo ' selected="selected"'; ?>>
                                        Мобильный разработчик
                                    </option>

                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <div id="editnot" class="col-lg-9 col-lg-offset-3">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                <button type="submit" class="btn btn-primary update_info" onclick="editUser('<?php echo $row['id'] ?>')">Сохранить</button>
                            </div>
                        </div>
                    </fieldset>
                    <!--<form class="form-horizontal">
                        <div class="alert alert-dismissible alert-success dnone">
                            Пароль успешно обновлен!
                        </div>
                        <fieldset>
                            <legend>Сменить пароль</legend>
                            <div class="form-group">
                                <label for="inputPassword1" class="col-lg-3 control-label">Старый пароль</label>
                                <div class="col-lg-9">
                                    <input class="form-control oldpass" name="oldpass" id="inputPassword1" placeholder="Старый пароль" type="password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputPassword2" class="col-lg-3 control-label">Новый пароль</label>
                                <div class="col-lg-9">
                                    <input class="form-control pass" id="inputPassword2" name="pass" placeholder="Новый пароль" type="password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputPassword3" class="col-lg-3 control-label">Еще раз</label>
                                <div class="col-lg-9">
                                    <input class="form-control pass1" id="inputPassword3" placeholder="Повторите пароль" type="password">
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="col-lg-9 col-lg-offset-3">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                    <button type="submit" class="btn btn-primary update_pass">Сохранить</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>-->
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
</div>

<!-- тут всегда лучше все модалки выводить из home.php -->
</body>

<script src="https://bootswatch.com/bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slideout/0.1.11/slideout.min.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script></script>
<script src="js/jquery.maskedinput.js"></script>
<script type="text/javascript">
    jQuery(function($){
        $("#userphone").mask("+7 (999) 999-9999");
    });
</script>
<script>
    function editUser(userid) {
        var ava = $("img#avatar").attr('src');
        //alert(ava);
        var ab = $(".modal-body").find("#username").val();
        var bc = $(".modal-body").find("#userfullname").val();
        var cd = $(".modal-body").find("#userphone").val();
        var de = $(".modal-body").find("#userposition").val();
        //alert(ab, bc, cd, de);
        //console.log(ab, bc, cd, de);
        $.ajax({
            url: "edituser.php?avatar="+ava+"&username="+ab+"&fullname="+bc+"&phone="+cd+"&position="+de,
            type: "POST",
            data:  {uid:userid},
            success: function(){
                //console.log(userid, bc, cd, de);
                $("#editnot").append("<div id='importmsg' class='alert-box success'>Ваш профиль успешно изменен</div>");
                $( "div#importmsg" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                setTimeout(function () {
                    location.reload();
                }, 2000);
            }
        });
    }
</script>
<script>
    function create(updateid) {
        $("#commenttext_" + updateid).each(function(){
            var commenttext = $(this).val();
            //console.log(commenttext);
            //var queryString = 'commenttext=' + commenttext + '&update=' + updateid;
            $.ajax({
                type:'POST',
                url:'insertcomment.php?update='+updateid,
                data:{commenttext:commenttext},
                success:function(){
                    $("#commenttext_" + updateid).val("");
                    $("#listcomment_" + updateid).load("displaycomments.php?dataid=" + updateid).fadeIn();
                }
            });
        });
    }
    $(".JScommentbtn").bind("mousedown", function(e){
        var updateid = $(this).attr("data-id");
        var commenttext = $(this).prev(".commenttext");
        //var queryString = 'commenttext=' + commenttext + '&update=' + updateid;
        $.ajax({
            type:'POST',
            url:'insertcomment.php?update='+updateid,
            data:{commenttext:commenttext.val()},
            success:function(){
                commenttext.val("");
                $("#listcomment_" + updateid).load("displaycomments.php?dataid=" + updateid).fadeIn();
                commenttext.trigger('blur');
            }
        });
    });

    $(document).ready(function(){

        $(".commenttext").focus(function(){
            if($.trim($(this).val()) == "Добавить комментарий..."){
                $(this).val("");
                $(this).next().show();
            }
        });
        $(".commenttext").blur(function(){
            if($.trim($(this).val()) == ""){
                $(this).val("Добавить комментарий...");
                $(this).next().hide();
            }

        });

        $(".list-group-item.updid").each(function(){
            var updateid = $(this).attr("data-id");
            //console.log(updateid);
            $.ajax({
                type:'POST',
                url:'displaycomments.php?dataid=' + updateid,
                //data:{"dataid":updateid.attr("data-id")},
                success:function(){
                    setTimeout(function(){
                        $("#listcomment_" + updateid).load("displaycomments.php?dataid=" + updateid);
                    },500);
                }
            });
        });
    });
</script>
<style>

    .bgColor label{
        font-weight: bold;
        color: #A0A0A0;
    }
    #targetLayer{
        float:left;
        width:100px;
        height:100px;
        text-align:center;
        line-height:100px;
        font-weight: bold;
        color: #C0C0C0;
        background-color: #F0E8E0;
        overflow:auto;
    }
    #uploadFormLayer{
        float:right;
    }
    .btnSubmit {
        background-color: #3FA849;
        padding:4px;
        border: #3FA849 1px solid;
        color: #FFFFFF;
    }
    .inputFile {
        padding: 3px;
        background-color: #FFFFFF;
    }

    .btn.btn-default.btn-file {
        position: relative;
        overflow: hidden;
        padding: 4px 8px;
    }
    .btn-file input[type=file] {
        position: absolute;
        top: 0;
        right: 0;
        min-width: 100%;
        min-height: 100%;
        font-size: 100px;
        text-align: right;
        filter: alpha(opacity=0);
        opacity: 0;
        outline: none;
        background: white;
        cursor: inherit;
        display: block;
    }
</style>
<script type="text/javascript">
    $(document).ready(function (e) {
        $("#uploadForm").on('submit',(function(e) {
            e.preventDefault();
            $.ajax({
                url: "upload.php",
                type: "POST",
                data:  new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success: function(data)
                {
                    $("#targetLayer").html(data);
                },
                error: function()
                {
                }
            });
        }));
    });
</script>
<script>
    function like(updateid) {
        $.ajax({
            type:'POST',
            url:'actions.php',
            data:{update:updateid},
            success:function(){
                $("#likebtn_"+updateid).remove();
                $("#likeload_" + updateid).load("displaylikes.php?update=" + updateid);
            }
        });
    }

    $(document).ready(function(){
        $(".list-group-item.updid").each(function(){
            var updateid = $(this).attr("data-id");
            console.log(updateid);
            $.ajax({
                type:'POST',
                url:'displaylikes.php?update=' + updateid,
                //data:{"update":updateid.attr("data-id")},
                success:function(){
                    setTimeout(function(){
                        $("#likeload_" + updateid).load("displaylikes.php?update=" + updateid);
                    },500);
                }
            });
        });
    });
</script>
<script>
    $(document).ready(function() {
        $(".dropdown-menu.notificate").load("displaynotification.php");
    })

    function callAction(action, id) {
        var queryString;
        switch (action) {
            case "remove":
                queryString = 'action=' + action + '&user_id=' + id;
                break;
        }
        jQuery.ajax({
            url: "crud_action.php",
            data: queryString,
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "remove":
                        $('.usernotification').fadeOut();
                        break;
                }
                $(".nav.badge").text('0');
            },
            error: function () {

            }
        });
    } 
</script>
</html>