<?php
include("bd.php");
session_start();
$user_id =  $_SESSION['user_id'];
$chatid = $_POST['ChatId'];
$chatid = stripslashes($chatid);
$chatid = htmlspecialchars($chatid);
$chatid = trim($chatid);

$query = $conn->query("set names utf8");
$query = $conn->prepare('INSERT INTO Importantmessages (chat_id ,user_id) VALUES (?,?)');
$query->bind_param('ii', $chatid, $user_id);
$query->execute();
if ($conn->errno) {
    die('Select Error (' . $conn->errno . ') ' . $conn->error);
}
?>