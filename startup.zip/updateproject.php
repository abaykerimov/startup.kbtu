<?php
include("bd.php");

$projectname = $_GET["projectname"];
$projectname = stripslashes($projectname);
$projectname = htmlspecialchars($projectname);
$projectname = trim($projectname);

$description = $_GET["description"];
$description = stripslashes($description);
$description = htmlspecialchars($description);
$description = trim($description);

$category = $_GET["category"];
$category = stripslashes($category);
$category = htmlspecialchars($category);
$category = trim($category);

$team = $_GET["team"];
$team = stripslashes($team);
$team = htmlspecialchars($team);
$team = trim($team);

$project_id = $_POST['id'];
$project_id = stripslashes($project_id);
$project_id = htmlspecialchars($project_id);
$project_id = trim($project_id);

$result = $conn->query("set names utf8");
$sql = "SELECT * FROM Category WHERE name = '$category'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$category_id = $row['id'];
if($result){
    $query = $conn->query("set names utf8");
//$sql = mysql_query("UPDATE UploadProject SET projectname = '" . $_POST["projectname"] . "', description = '" . $_POST["description"] . "', category = '" . $_POST["category"] . "', stage = '" . $_POST["stage"] . "', team = '" . $_POST["team"] . "' WHERE  id=" . $project_id);
    $query = $conn->prepare('UPDATE UploadProject SET projectname=?, description=?, category_id=?, team=? WHERE id=?');
    $query->bind_param('ssisi', $projectname, $description, $category_id, $team, $project_id);
    $query->execute();
}
/*if($query){
    header("Location: timeline.php");
}*/