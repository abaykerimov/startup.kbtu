<?php
include("bd.php");
$keyword = $_POST["keyword"];
$keyword = stripslashes($keyword);
$keyword = htmlspecialchars($keyword);
$keyword = trim($keyword);

$result = $conn->query("set names utf8");
$sql = "SELECT * FROM Userslan WHERE fullname like '$keyword%' ORDER BY fullname LIMIT 0,6";
$result = $conn->query($sql);
?>
<ul id="user-list">
    <?php
    while($row = $result->fetch_assoc()) {
        if(!empty($result)) {
            ?>
            <li onclick="getUser('<?php echo $row["fullname"]; ?>');"><?php echo $row["fullname"]; ?></li>
        <?php } }?>
</ul>
