<?php
header('Content-type: text/html; charset=utf8');
session_start();

$id = $_SESSION['user_id'];
$hour = date("H:i:s", time());
$year = date("d-m-Y ");
$date = $hour . " " .$year;
$project_id = $_GET['id'];
$channel_id = $_GET['channel'];

include("bd.php");
$fname = $_FILES['userImage']['name'];
$dname = $_FILES['userDoc']['name'];
$img_ext = strrchr($fname, '.');
$file_ext = strrchr($dname, '.');
if(is_array($_FILES)) {
    if(is_uploaded_file($_FILES['userImage']['tmp_name'])) {
        $sourcePath = $_FILES['userImage']['tmp_name'];
        $targetPath = "uploads/";
        $new        = rand(0000,9999);
        $newfilename = $new.$fname;

        if (!is_dir($targetPath)) mkdir($targetPath);
        $targetPath = $targetPath . basename($newfilename);
        if(move_uploaded_file($sourcePath,$targetPath)) {
            ?>
            <img id="avatar" src="<?php echo $targetPath; ?>" width="100px" height="100px" />
            <?php
        }
    }

    if(is_uploaded_file($_FILES['userDoc']['tmp_name'])) {
        $sourcePath = $_FILES['userDoc']['tmp_name'];
        $targetPath = "uploads/";
        $new        = rand(0000,9999);
        $newfilename = $new.$fname.$file_ext;

        if (!is_dir($targetPath)) mkdir($targetPath);
        $targetPath = $targetPath . basename($newfilename);
        if(move_uploaded_file($sourcePath,$targetPath)) {
            $sth = $conn->query("set names utf8");

            $insert = "INSERT INTO Chat (message, user_id, project_id, channel_id, date, filename) VALUES ('$targetPath', '$id', '$project_id', '$channel_id', '$date', '$dname')";
            $sth = $conn->prepare($insert);
            $sth->execute();
        }

    }
}
/* $sth = $conn->query("set names utf8");

      $insert = "UPDATE Userproject  (fname, filesize, fileType, userfile) VALUES (:fname, :fileSize, :fileType, :userfile)";
      $sth = $conn->prepare($insert);
      $sth->execute(
          array (
              ":fname" => $fname,
              ":filesize" => $fileSize,
              ":fileType" => $fileType,
              ":userfile" => $content,
          )
      );*/
/*
$fname = ($_FILES['userfile']['name']);
$tmpname = $_FILES['userfile']['tmp_name'];
$fileSize = $_FILES['userfile']['size'];
$fileType = $_FILES['userfile']['type'];
$file_ext = strrchr($fname, '.');

//This is the directory where images will be saved
$target = "uploads/";
$new        = rand(0000,9999);

$newfilename = $new.$fname;
if (!is_dir($target)) mkdir($target);
$target = $target . basename($newfilename);
*/
/*$whitelist = array(".pdf", ".pptx", ".ppt");
if (!(in_array($file_ext, $whitelist))) {
    die('Загружайте только презентацию!');
}*/
//process the file
/*$fp = fopen($tmpname, 'r');
$content = fread($fp, filesize($tmpname));
$content = addslashes($content);
fclose($fp);

$fname = addslashes($fname);

$sth = $conn->query("set names utf8");

$insert = "INSERT INTO `Userproject`(fname, filesize, fileType, userfile) VALUES (:fname, :fileSize, :fileType, :userfile)";
$sth = $conn->prepare($insert);
$sth->execute(
    array (
        ":fname" => $fname,
        ":filesize" => $fileSize,
		":fileType" => $fileType,
		":userfile" => $content,
    )
);*/
?>