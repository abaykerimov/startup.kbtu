<?php
include("bd.php");
$error = "";
$msg = "";
error_reporting(0);

$type = $_POST['type'];
$type = stripslashes($type);
$type = htmlspecialchars($type);
$type = trim($type);

if (isset($_POST) && isset($type)) {

    if ($_POST['type'] == "login" && isset($_POST['username'], $_POST['password'])) {
        $e = htmlentities($_POST['username'], ENT_QUOTES);
        $p = md5(md5($_POST['password'] . md5(sha1($_POST['password']))));
        $query = $conn->query("SELECT * FROM `Userslan` WHERE (username='$e' OR email = '$e') AND `password`='$p'");

        if ($query->num_rows == 1) {
            if($row = $query->fetch_assoc()){
                session_start();
                $_SESSION['user_id'] = $row['id'];
            }

            echo '{"error":0,"redir":"okk"}';
        } else {
            echo '{"error":1,"message":"Неправильные данные."}';
        }

    } else if ($_POST['type'] == "register" && isset($_POST['email'], $_POST['fullname'], $_POST['passwd'], $_POST['confpasswd'])) {

        $_POST['fullname'] = htmlentities($_POST['fullname'], ENT_QUOTES);
        $_POST['passwd'] = htmlentities($_POST['passwd'], ENT_QUOTES);

        $f = $_POST['fullname'];
        $e = $_POST['email'];
        //$p = md5($_POST['passwd']);
        $p = md5(md5($_POST['passwd'] . md5(sha1($_POST['passwd']))));
        $s = $_POST['status'];

        if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {

            echo '{"error":1,"message":"Введите валидную почту","focus":"email"}';

        } else {
            $query = $conn->query("SELECT id FROM Userslan WHERE email = '$e'");
            if ($query->num_rows > 0) {

                echo '{"error":1,"message":"Такая почта существует.","focus":"email"}';

            } else if ($_POST['passwd'] != $_POST['confpasswd']) {

                echo '{"error":1,"message":"Пароли не совпадают","focus":"confpasswd"}';

            } else {
				$query = $conn->query("set names utf8");
                $query = $conn->query("INSERT INTO Userslan (avatar,fullname,email,password,status) VALUES('uploads/noavatar.png','$f','$e','$p','$s')") or die($conn->error);
                echo '{"error":0,"message":"Пароль выслан на почту, спасибо.<br> <a href=\"login.php\">Нажмите</a>, чтобы войти<br>Помощь: <a href=\"mailto: startup@kbtu.kz\">startup@kbtu.kz</a>","redir":"none"}';
            }
        }
    }
    
}

$username = $_POST['fullname'];
$email = $_POST['email'];
$password = $_POST['passwd'];
if ($username != ""){
    require 'phpmailer/PHPMailerAutoload.php';
    $date=date("Y-m-d H:i:s");
    $mail = new PHPMailer;
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.mail.ru';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'startup.kbtu.kz@inbox.ru';                 // SMTP username
    $mail->Password = 'Incubator2016';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to
    $mail->From = 'startup.kbtu.kz@inbox.ru';
    $mail->FromName = 'startup@kbtu.kz';
    $mail->addAddress('abaykerimov@gmail.com');
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->CharSet = "UTF-8";
    $mail->Subject = 'Регистрация на портале iKBTU Startup Incubator';
    $mail->Body = 'Здравствуйте.<br><br>
                        Спасибо, что зарегистрировались на портале.  <br>
                        Сохраните данные аккаунта.
                        <br><br>Данные:
						<br>ФИО: ' . $username . '
						<br>E-mail: ' . $email . '
						<br>Пароль: ' . $password . '

                   <br><br>Если запрос сделали не Вы, просто проигнорируйте это сообщение.';
    $mail->AltBody = 'Спасибо, что зарегистрировались на портале./n/n Данные: /n ' . '/n Логин: /n ' . $username . '/n E-mail: /n ' . $email . '/n Пароль: /n ' . $password;
	$mail->send();
    
    if (isset($email)) {
        $mail = new PHPMailer;
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'smtp.mail.ru';  // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = 'startup.kbtu.kz@inbox.ru';                 // SMTP username
        $mail->Password = 'Incubator2016';                           // SMTP password
        $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 465;                                    // TCP port to connect to
        $mail->From = 'startup.kbtu.kz@inbox.ru';
        $mail->FromName = 'startup@kbtu.kz';
        $mail->addAddress($email);
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->CharSet = "UTF-8";
        $mail->Subject = 'реги';
        $mail->Subject = 'Регистрация на портале iKBTU Startup Incubator';
        $mail->Body = 'Здравствуйте.<br><br>
                        Спасибо, что зарегистрировались на портале.  <br>
                        Сохраните данные аккаунта.
                        <br><br>Данные:
						<br>ФИО: ' . $username . '
						<br>E-mail: ' . $email . '
						<br>Пароль: ' . $password . '

                   <br><br>Если запрос сделали не Вы, просто проигнорируйте это сообщение.';
        $mail->AltBody = 'Спасибо, что зарегистрировались на портале./n/n Данные: /n ' . '/n Логин: /n ' . $username . '/n E-mail: /n ' . $email . '/n Пароль: /n ' . $password;
		$mail->send();
        
    }
}
?>