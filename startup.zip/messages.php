<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("bd.php");
$id = $_SESSION["user_id"];
$channel = $_GET['channel'];
if (!isset($id)){
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html>
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>

    <title>Личные сообщения</title>
    <link rel="canonical" href=""/>
    <meta name="robots" content="index, follow"/>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>
    <link rel="apple-touch-icon" sizes="57x57" href="/favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/favicons/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="/favicons/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="/favicons/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="css/main.less">
    <script type="text/javascript" src="js/less.min.js"></script>
    <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
    <style>
        #user-list{float:left;list-style:none;margin:0;padding:0;width:190px;}
        #user-list li{padding: 10px; background:#FAFAFA;border-bottom:#F0F0F0 1px solid;cursor:pointer}
        #user-list li:hover{background:#F0F0F0;}

        .alert-box {
            padding: 15px;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        .success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
            display: none;
        }
        #logoutbtn {
            background-color: transparent;
            font-size: 13px;
            color: white;
            padding: 12px 15px;
            margin-bottom: 10px;
            border-color: transparent;
        }
        #logoutbtn:hover {
            background: black;
        }

        .col-lg-9 {
            margin-bottom: 15px;
        }
    </style>
    <script>
        function callCrudAction(action, id) {
            $("#loaderIcon").show();
            var queryString;
            switch (action) {
                case "addchannel":
                    queryString = 'action=' + action + '&hidst=' +$("#hidst").val() + '&channelname=' +$("#channelname").val() + '&firstmsgname=' +$("#firstmsgname").val() + '&get_id=' + $("#get_id").val();
                    break;
				case "deletechannel":
                    queryString = 'action=' + action + '&hidchannelid=' + id;
                    break;
				case "deleteimportant":
                    queryString = 'action=' + action + '&hidimportid=' + id;
                    break;
				case "deletefromteam":
                    queryString = 'action=' + action + '&hidteamid=' + id;
                    break;
            }
            jQuery.ajax({
                url: "crud_action.php",
                data: queryString,
                type: "POST",
                success: function (data) {
                    switch (action) {
                        case "addchannel":
                            if($("#channelid").append(data)){

                                $("#addnot").append("<div id='channelnot' class='alert-box success'>Диалог создан!</div>");
                                $( "div#channelnot" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                            } else{
                                alert("error");
                            }/*setTimeout(function () {
								location.reload();
							 }, 2 * 1000);*/
                            break;
						case "deletechannel":
                            $('#channel_' + id).fadeOut();
                            break;
						case "deleteimportant":
                            $('#important_' + id).fadeOut();
                            break;
						case "deletefromteam":
                            $('#projteam_' + id).fadeOut();
                            break;
                    }
                    $("#channelname").val('');

                    $("#loaderIcon").hide();
                },
                error: function () {
                    alert("error");
                }
            });
            $("#channelnot").remove();
        }

    </script>
</head>

<body>

<!-- Верхний навбар, всегда одинаковый, брать с файла home.php -->
<nav class="navbar navbar-default" style="z-index: 10">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">iKBTU Incubator</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <!-- Активный элемент меню это у ли класс актив и  <span class="sr-only">(current)</span> -->
                <li class="active"><a href="timeline.php">Лента <span class="sr-only">(current)</span></a></li>
                <li><a href="allprojects.php">Проекты</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <!-- Это кнопка с уведомлениями -->
                <?php
                $result = $conn->query("set names utf8");
                $sql = "SELECT COUNT(user_id) as cnt FROM Notifications WHERE user_id = '$id'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                    ?>
                    <li><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="glyphicon glyphicon-info-sign"></span><span class="nav badge"><?php echo $row['cnt'] ?></span></a>
                        <ul class="dropdown-menu notificate" role="menu">
                        </ul>
                    </li>
                <?php } } ?>
                <?php
                $result = $conn->query("set names utf8");
                $id = $_SESSION['user_id'];
                $sql = "SELECT id, fullname FROM Userslan WHERE id=$id";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {

                while ($row = $result->fetch_assoc()) {
                ?>
                <!-- Это кнопка действиями над профилем -->
                <li><a class="dropdown-toggle" data-toggle="dropdown" role="button"
                       aria-expanded="false"><?php echo $row['fullname'] ?><span class="caret"></span></a>
                    <?php
                    }
                    }
                    ?>
                    <ul class="dropdown-menu" role="menu">

                        <li><a href="#user_profile" role="button" data-toggle="modal">Настройки</a></li>
                        <li class="divider"></li>
                        <form class="ajax" method="post" action="./logout.php">
                            <button id="logoutbtn" type="submit">Выход</button>
                        </form>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Это синий навбар, он имеет отношение только к проекту -->
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-2">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- Название -->
            
            <a class="navbar-brand" href="messages.php">Личные сообщения</a>

        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
            <ul class="nav navbar-nav">
                <!-- Новости проекта -->

            </ul>
            
        </div>
    </div>
    <div class="container-fluid">
        <!-- Описание проекта -->
        <p></p>
      
    </div>
</nav>
<!-- Этапы развития проекта active - пройденный или активный этап -->


<!-- contant - основной блок где хранится три колонки - 2-8-2. В новостях проекта и просто новостях становится 2-10. Правый сталбец не отображается -->
<div id="contant">

    <!-- левая колонка со статичной информацией о проекте -->
    <div class="col-lg-2 text-center blocks">
		
        <!-- разворачивающаяся панель, чтобы была сразу открыта, у panel-body должен быть класс dnone -->
        <div class="panel panel-default">
            <div class="panel-heading">Команда проекта <span class="glyphicon glyphicon-chevron-up"></span></div>
            <div class="panel-body">
                <div class="list-group">

                    <!-- один блок о пользователе (везде одинаковый) -->
                    <div id="teamdisp"></div>
                   
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">Менторы проекта <span class="glyphicon glyphicon-chevron-up"></span></div>
            <div class="panel-body">
                <div class="list-group">
					
                    <!-- один блок о пользователе (везде одинаковый) -->
   
                </div>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading">Дополнительная информация <span class="glyphicon glyphicon-chevron-down"></span>
            </div>
            <div class="panel-body dnone">
                <div class="text_item">

                </div>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading">Подписчики проекта <span class="glyphicon glyphicon-chevron-down"></span></div>
            <div class="panel-body dnone">
                <div class="list-group">
                    
                </div>
            </div>
        </div>
        <div id="leftnot" class="panel panel-default">

        </div>
    </div>

    <!-- центральная колонка -->
    <div class="col-lg-8 text-center blocks">
        <!-- навигация по чатам и создание нового -->
        <div id="channelid" class="text-left centr">
        <?php
        $result = $conn->query("set names utf8");
		$sql = "SELECT * FROM Channel ch
		WHERE user_id = '$id'";
		$result = $conn->query($sql);

        while($row = $result->fetch_assoc()) {
            if($row['forward_id'] != 0) { 
			$channel_id = $row['id']?>
            <a id="ch_<?php echo $channel_id ?>" data-id="<?php echo $channel_id ?>" href="messages.php?channel=<?php echo $channel_id ?>" class="btn btn-primary btn-xs topmenu"><?php echo $row['channelname'];?> <span class="badge"></span></a>
            <?php } } ?>
            <a href="#add_chat" class="btn btn-primary btn-xs" role="button" data-toggle="modal"><span class="glyphicon glyphicon-plus-sign"></span></a>
			
        </div>
        <?php if(isset($channel)){ ?>
        <div id="ChatBig">

			<div id="ChatMessages" class="list-group text-left"></div>
            <div id="sub_cont" class="list-group text-left"></div>
			
			<div class="col-lg-10 padding-none">
				<textarea id="ChatText" class="form-control" name="ChatText"></textarea>
			</div>
			<div class="col-lg-2 padding-none">
			<div class="col-md-12" id="progress-div"><div id="progress-bar"></div></div>
			<form id="uploadDoc" action="upload.php" method="post">
			<span class="filenamespan">Не выбрано</span>
				<div  class="btn btn-link btn-block attach-div" title="Нажмите на меня, для обзора файла">
					<input name="userDoc" id="userDoc" type="file" class="demoInputBox" size="1" />
				</div>
				
				<button type="submit" id="chatbtn" class="btn btn-primary btn-block" onclick="AjaxFormRequest();">Отправить</button>
			</form>	
				
			</div>
			
        </div>

            <!-- именно тут нужно грузить и обновлять сообщения ПО ИДЕЕ -->

        <?php } else { ?>
		<style>
			.topmenu {
				display:none;
			}
		</style>
        <div class="col-lg-12 text-center blocks" id="DialogBig" style="margin-top: 0">
            <div class="list-group text-left" id="DialogMessages">
            <?php
            $result = $conn->query("set names utf8");
            $sql = "SELECT t1.*, ch.channelname, ch.id AS channelid, ch.user_id, u.fullname, u.avatar FROM Channel ch
                    JOIN Messages t1 ON ch.id = t1.channel_id
                    JOIN (SELECT channel_id, MAX(id) as id FROM Messages GROUP BY channel_id) t2
                    ON t1.channel_id = t2.channel_id AND t1.id = t2.id
                    JOIN Userslan u ON u.id = t1.user_id
                    WHERE ch.forward_id = '$id' ORDER BY t1.id DESC";
            $result = $conn->query($sql);
            while($row = $result->fetch_assoc()) {
                $channel_id = $row['channelid'];
            ?>
                <a href="messages.php?channel=<?php echo $channel_id ?>" data-id="<?php echo $channel_id ?>" class="list-group-item mess" id="channel_<?php echo $channel_id ?>">
					<input id="hidchannelid" type="hidden" value="<?php echo $channel_id ?>">

                    <div class="col-lg-3">
                        <h5 class="list-group-item-heading"><?php echo $row['channelname'] ?></h5>
                    </div>
                    <div class="col-lg-9">
                        <img src="<?php echo $row['avatar'] ?>" alt="Имя Фамилия">
                        <h5 class="list-group-item-heading"><?php echo $row['fullname'] ?> <span><?php echo $row['date'] ?></span> <span class="badge"></span></h5>
						<?php
						$newstring = substr($row['message'], -4);
						if (preg_match('/uploads/', $row['message'])) {
							if ($newstring == "docx" || $newstring == "pptx" || $newstring == ".pdf" || $newstring == ".doc" || $newstring == ".txt") { ?>
							<p class="list-group-item-text short"><span style="margin-right: 5px" class="glyphicon glyphicon-file"></span>Документ</p>
							<?php
							} else if ($newstring == ".jpg" || $newstring == ".png" || $newstring == ".PNG" || $newstring == ".JPG") { ?>
							<p class="list-group-item-text short"><span style="margin-right: 5px" class="glyphicon glyphicon-camera"></span>Фото</p>						
							<?php } } else { ?>
							<p class="list-group-item-text short"><?php echo $row['message'] ?></p>
							<?php } ?>
                        
                    </div>
                </a>
				<?php if($id == $row['user_id']) { ?>
				<span class="glyphicon glyphicon-remove" title="Удалить диалог" style="float: right;margin-top: -60px;margin-right: 10px; cursor: pointer" onclick="callCrudAction('deletechannel', '<?php echo $channel_id ?>')"></span>
				
			<?php } } ?>
            </div>
        </div>

            <!-- именно тут нужно грузить и обновлять НОВЫЕ сообщения ПО ИДЕЕ -->

        <?php } ?>

        <!-- сам чат -->
    </div>
    <!-- правая колонка -->
    <div class="col-lg-2 text-center blocks">
     <div class="panel panel-default">
            <div class="panel-heading">Закладки чата <span class="glyphicon glyphicon-chevron-down"></span></div>
            <div class="panel-body dnone">
                <div class="text_item">
                    <p>Сюда можно закрепить определенный комментарий, который нужно быстро найти в обсуждении.</p>

                    <div id="import" class="list-group">

                    </div>
                </div>
            </div>
        </div>
		
        <div class="panel panel-default">
            <div class="panel-heading">Файлы чата <span class="glyphicon glyphicon-chevron-down"></span></div>
            <div class="panel-body dnone">
                <div class="list-group userfiles">

                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="textBox" style="margin-top: 25px">
                <p>Поиск по чату</p>
                <input class="form-control" style="width: 85%; margin-left: 17px;" type="text" value="" maxlength="100" name="searchBox" id="search">

                <div class="searchBtn">
                    &nbsp;
                </div>
            </div>
            <br clear="all" />
            <div id="content">
                <div class="search-background">
                    <label><img src="LoaderIconMini.gif" alt="" /></label>
                </div>

            </div>
        </div>

        <div id="head" class="panel panel-default">

        </div>
    </div>
    <!-- ниже конец contenta -->
</div>

<!-- Добавить новый диалог модалка -->
<div class="modal fade" id="add_chat">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span
                        class="glyphicon glyphicon-remove"></span></button>
                <h4 class="modal-title">Добавить новый диалог</h4>
            </div>
            <div class="modal-body">
                <fieldset>
                    <div class="form-group">
                        <input id="get_id" type="hidden" name="get_id" value="<?php echo $project_id; ?>">
                        <label for="inputName12" class="col-lg-3 control-label">Название диалога</label>

                        <div class="col-lg-9">
                            <input class="form-control name" id="channelname" placeholder="Название диалога"
                                   type="text" name="channelname">
                        </div>
                    </div>
					<div class="form-group">
                        <label for="msglbl" class="col-lg-3 control-label">Напишите первое сообщение</label>

                        <div class="col-lg-9">
                            <input class="form-control name" id="firstmsgname" placeholder="Сообщение"
                                   type="text" name="firstmsgname">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div id="addnot" class="col-lg-9 col-lg-offset-3">
                            <button class="reset dnone" type="reset"></button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                            <button type="submit" class="btn btn-primary" id="zvonok" onclick="callCrudAction('addchannel', '')">Добавить</button>
                        </div>
                        <div></div>
                    </div>
                </fieldset>
            </div>
        </div>
    </div>
</div>

<?php
$id = $_SESSION["user_id"];
$result = $conn->query("set names utf8");
$sql = "SELECT * FROM Userslan WHERE id = '$id'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    ?>
    <!-- Редактировать личный кабинет модалка -->
    <div class="modal fade" id="user_profile">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove"></span></button>
                    <h4 class="modal-title">Редактировать личный кабинет</h4>
                </div>
                <div class="modal-body">

                    <fieldset>
                        <input name="uid" type="hidden" class="uid" value="<?php echo $row['id']; ?>">

                        <div class="form-group">
                            <label for="inputFoto" class="col-lg-3 control-label">Сменить аватар</label>
                            <div class="col-lg-9">
                                <form id="uploadForm" action="upload.php" method="post">
                                    <div id="targetLayer">
                                        <img id="avatar" src="<?php echo $row['avatar']; ?>" width="100px" height="100px" />
                                    </div>
                                    <div id="uploadFormLayer">

                                    <span class="btn btn-default btn-file">
                                        Выбрать <input name="userImage" type="file" class="inputFile" />
                                    </span>

                                        <button type="submit" class="btn btn-success btnSubmit">Загрузить</button>
                                    </div>
                                </form>
                            </div>
                            <!--<form action="upload.php"><div class="col-lg-9">
                                <input class="form-control" id="selectphoto" placeholder="" type="file">
                            </div></form>-->
                        </div>
						<div class="form-group">
                            <label for="username" class="col-lg-3 control-label">Никнейм</label>
                            <div class="col-lg-9">
                                <input name="username" id="username" class="form-control" value="<?php echo $row['username']; ?>" placeholder="Ваш никнейм" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmail" class="col-lg-3 control-label">Email</label>
                            <div class="col-lg-9">
                                <input name="email" disabled="" class="form-control email" placeholder="Ваш email" type="text" value="<?php echo $row['email']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="name_com" class="col-lg-3 control-label">ФИО</label>
                            <div class="col-lg-9">
                                <input name="fullname" id="userfullname" class="form-control" value="<?php echo $row['fullname']; ?>" placeholder="Ваше ФИО" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="con_tel" class="col-lg-3 control-label">Контактный телефон</label>
                            <div class="col-lg-9">
                                <input name="phone" class="form-control" id="userphone" placeholder="Контактный телефон" pattern="+7 ([0-9]{3}) [0-9]{3}-[0-9]{2}-[0-9]{2}" type="tel" value="<?php echo $row['phone']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="bin" class="col-lg-3 control-label">Должность</label>
                            <div class="col-lg-9">
                                <select id="userposition" name="position" class="form-control">
                                    <option
                                        value="UI дизайнер"<?php if ($row['userposition'] == 'UI дизайнер') echo ' selected="selected"'; ?>>
                                        UI дизайнер
                                    </option>
                                    <option
                                        value="PHP разработчик"<?php if ($row['userposition'] == 'PHP разработчик') echo ' selected="selected"'; ?>>
                                        PHP разработчик
                                    </option>
                                    <option
                                        value="Web-маркетолог"<?php if ($row['userposition'] == 'Web-маркетолог') echo ' selected="selected"'; ?>>
                                        Web-маркетолог
                                    </option>
                                    <option
                                        value="Мобильный разработчик"<?php if ($row['userposition'] == 'Мобильный разработчик') echo ' selected="selected"'; ?>>
                                        Мобильный разработчик
                                    </option>

                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <div id="editnot" class="col-lg-9 col-lg-offset-3">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                <button type="submit" class="btn btn-primary update_info" onclick="editUser('<?php echo $row['id'] ?>')">Сохранить</button>
                            </div>
                        </div>
                    </fieldset>
                    <!--<form class="form-horizontal">
                        <div class="alert alert-dismissible alert-success dnone">
                            Пароль успешно обновлен!
                        </div>
                        <fieldset>
                            <legend>Сменить пароль</legend>
                            <div class="form-group">
                                <label for="inputPassword1" class="col-lg-3 control-label">Старый пароль</label>
                                <div class="col-lg-9">
                                    <input class="form-control oldpass" name="oldpass" id="inputPassword1" placeholder="Старый пароль" type="password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputPassword2" class="col-lg-3 control-label">Новый пароль</label>
                                <div class="col-lg-9">
                                    <input class="form-control pass" id="inputPassword2" name="pass" placeholder="Новый пароль" type="password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputPassword3" class="col-lg-3 control-label">Еще раз</label>
                                <div class="col-lg-9">
                                    <input class="form-control pass1" id="inputPassword3" placeholder="Повторите пароль" type="password">
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="col-lg-9 col-lg-offset-3">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                    <button type="submit" class="btn btn-primary update_pass">Сохранить</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>-->
                </div>
            </div>
        </div>
    </div>
    <?php
}
?>

</body>
<!-- скрипты везде одинаковые всего три-->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script src="https://bootswatch.com/bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="js/jquery.maskedinput.js" type="text/javascript"></script>
<script type="text/javascript">
    jQuery(function ($) {
        $("#userphone").mask("+7 (999) 999-9999");
    });
   
</script>

<script>
    $(document).ready(function () {
        $(".form-control.searchpart").keyup(function () {
            $.ajax({
                type: "POST",
                url: "getuserforchat.php",
                data: 'keyword=' + $(this).val(),
                beforeSend: function () {
                    $(".form-control.searchpart").css("background", "#FFF url(LoaderIcon.gif) no-repeat 165px");
                },
                success: function (data) {
                    $("#suggid").show();
                    $("#suggid").html(data);
                    $(".form-control.searchpart").css("background", "#FFF");
                }
            });
        });
    });

    function getUser(val) {
        $(".form-control.searchpart").val(val);
        $("#suggid").hide();
    }
</script>
<script>
    $(document).ready(function () {
        $(".form-control.searchteam").keyup(function () {
            $.ajax({
                type: "POST",
                url: "getUser.php",
                data: 'keyword=' + $(this).val(),
                beforeSend: function () {
                    $(".form-control.searchteam").css("background", "#FFF url(LoaderIcon.gif) no-repeat 165px");
                },
                success: function (data) {
                    $("#suggboxid").show();
                    $("#suggboxid").html(data);
                    $(".form-control.searchteam").css("background", "#FFF");
                }
            });
        });
    });

    function selectUser(val) {
        $(".form-control.searchteam").val(val);
        $("#suggboxid").hide();
    }
</script>
<script>
	$('textarea').keyup(function (event) {
       if (event.keyCode == 13 && event.shiftKey) {
           var content = this.value;
           var caret = getCaret(this);
           this.value = content.substring(0,caret)+"\n"+content.substring(carent,content.length-1);
           event.stopPropagation();
           
      }else if(event.keyCode == 13)
      {
          AjaxFormRequest();
      }
	});
	function getCaret(el) { 
	  if (el.selectionStart) { 
		return el.selectionStart; 
	  } else if (document.selection) { 
		el.focus(); 

		var r = document.selection.createRange(); 
		if (r == null) { 
		  return 0; 
		} 

		var re = el.createTextRange(), 
			rc = re.duplicate(); 
		re.moveToBookmark(r.getBookmark()); 
		rc.setEndPoint('EndToStart', re); 

		return rc.text.length; 
	  }  
	  return 0; 
	}


</script>
<script>
    function clickbtm(chatid){
        $.ajax({
            type:'POST',
            url:'importantmessage.php',
            data:{ChatId:chatid},
            success:function(){
				$("#import").load("displayimportant.php?channel="+hidval);
                $("#head").append("<div id='importmsg' class='alert-box success'>Сообщение добавлено в закладки</div>");
                $( "div#importmsg" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
            }
        });
        $( "div#importmsg").remove();
    };

    
    $(document).ready(function(){
        var hidval = $("#hidch").val();
        var projectid = $("#get_id").val();
        console.log(hidval);
        $("#ChatText").keyup(function(e){
            if(e.keyCode==13 && e.shiftKey){
					AjaxFormRequest();
            }
        });

        //первый раз грузим сообщения
        $("#ChatMessages").load("displaymessages.php?id="+projectid+"&channel="+hidval+"&type=first");

        if ($("#search").val() == ""){
            setInterval(function(){
                UpdateMessagesGetNews(projectid,hidval);
                //$("#ChatMessages").load("displaymessages.php?id="+projectid+"&channel="+hidval);
            },1500);
        }

        UpdateMessagesGetCount(projectid);
        setInterval(function(){
            UpdateMessagesGetCount(projectid);
        },5000);

        //setInterval(function(){
            $("#import").load("displayimportant.php?channel="+hidval);
        //},5500);

		$(".list-group.userfiles").load("displayfiles.php?channel="+hidval);
		
		/*$("textarea").keydown(function(e){
			if (e.keyCode == 13)
			{
				e.preventDefault();
			}
		});
		$('textarea').on('keydown', function(event) {
			if (event.keyCode == 13)
				$('#ChatText').submit();
		});*/

    });

    function AjaxFormRequest() {
        var hidval = $("#hidch").val();
        var projectid = $("#get_id").val();
        var ChatText = $("#ChatText").val();
		if ($.trim(ChatText) == '') {
			return false;
		}
        $.ajax({
            type:'POST',
            url:'insertmessage.php?id='+projectid+'&channel='+hidval,
            data:{ChatText:ChatText},
            success:function(){
                //refreshTypingStatus();
                $("#ChatText").val("");

                var my = 1;
                UpdateMessagesGetNews(projectid,hidval,my);
            }
        });
        var block = document.getElementById("ChatMessages");
		//alert(block.scrollHeight+130);
		setTimeout(function () {
                    block.scrollTop = block.scrollHeight+130;
                }, 100);
        
    }

    //подгружаем новые сообщение
    function UpdateMessagesGetNews(projectid,hidval,my) {

        $.ajax({
            type:'GET',
            url:"displaymessages.php",
            data:{id:projectid,channel:hidval,type: "news"},
            success:function(responce){
                if (responce != "") {
                    $("#ChatMessages").append(responce);

                    if (my == 1) {
                        $("#ChatMessages").find(".unread").removeClass("unread");
                        $("#unread").remove();
                    } else {
                        setTimeout(function () {
                            $("#ChatMessages").find(".unread").removeClass("unread");
                            $("#unread").remove();
                        }, 1000);
                    }


                    var block = document.getElementById("ChatMessages");
                    block.scrollTop = block.scrollHeight;
                }
            }
        });

    }

    function UpdateMessagesGetCount(projectid) {

        $( ".topmenu" ).each(function() {
            var thisitem = $(this);

            $.ajax({
                type:'GET',
                url:"displaymessagescount.php",
                data:{id:projectid,channel:thisitem.attr("data-id"),type: "news"},
                success:function(responce){
                    if (responce > 0) {
                        thisitem.find(".badge").html(responce);
                        thisitem.find(".badge").show();

                        //проходим по списку сообщений, если этот блок показывается
                        if ($("a").is(".mess")) {
                            $( ".mess" ).each(function() {
                                var item = $(this);
                                if (thisitem.attr("data-id") == item.attr("data-id")) {

                                    //и только вот здесь, нужно еще раз загрузить последнее сообщение

                                    $.getJSON("displaymessagescount.php?id="+projectid+"&channel="+item.attr("data-id")+"&type=messages", function(json){
                                        item.find("div").next().find("img").attr("src",json[0].avatar);
                                        item.find("div").next().find("h5").html(json[0].fullname+" <span>"+json[0].date+"</span> <span style='margin-top:10px;margin-right:10px' class='badge'>"+responce+"</span>");
                                        item.find("div").next().find("p").html(json[0].message);
                                        //json[0].fullname
                                    });

                                    //и обновить количество непрочитанных
                                    //$(this).find("div").next().find("h5").find(".badge").html(responce);
                                    //$(this).find("div").next().find("h5").find(".badge").show();
                                    $(this).addClass("unread");
                                }
                            });
                        }


                    } else {
                        thisitem.find(".badge").hide();
                        thisitem.find(".badge").html("");

                        //проходим по списку сообщений, если этот блок показывается
                        if ($("a").is(".mess")) {
                            $( ".mess" ).each(function() {
                                if (thisitem.attr("data-id") == $(this).attr("data-id")) {
                                    $(this).find("div").next().find("h5").find(".badge").hide();
                                    $(this).find("div").next().find("h5").find(".badge").html("");
                                    $(this).removeClass("unread");
                                }
                            });
                        }

                    }
                }
            });

        });
        setTimeout(function () {
            updateTotalUndead();
        }, 100);

    }
    function updateTotalUndead() {
        var itogo = 0;

        $( ".topmenu" ).each(function() {

            if (parseInt($(this).find(".badge").text(), 10) > 0) {
                itogo = parseInt(itogo, 10) + parseInt($(this).find(".badge").text(), 10);
            }

        });

        if (itogo > 0) {
            $( ".main_item.active" ).each(function() {
                if ($(this).find("span").is(".badge")) {
                    $(this).find("span").html(itogo);
                } else {
                    $(this).append("<span class='badge'>"+itogo+"</span>");
                }
            });
        } else {
            $( ".main_item.active" ).each(function() {
                $(this).find('.badge').remove();
            });
        }
    }


</script>
<script>
    $(document).ready(
        function(){
            var projectid = $("#get_id").val();
            var stageid = $("#hidst").val();
            var channelid = $("#hidch").val();
            $("a").each(function(){
                var a_href = $(this).attr('href');
                //console.log(a_href);
                if(a_href == "project.php?id=" + projectid + "&stage=" +stageid + "&channel=" +channelid) {
                    $("#ch_" +channelid).addClass("active");
                }
            });

            setTimeout(function () {
                //$('#ChatMessages').animate({
                    //scrollTop: $('#ChatMessages').get(0).scrollHeight+65}, 500);
					var block = document.getElementById("ChatMessages");
					block.scrollTop = block.scrollHeight;
            }, 1000);
            /*$('body').animate({
                scrollTop: $('body').get(0).scrollHeight}, 500);*/
        }
    );
</script>
<script>
    $(document).ready(
        function(){
            var projectid = $("#get_id").val();
            var stageid = $("#hidst").val();
            $("a").each(function(){
                var a_href = $(this).attr('href');
                //console.log(a_href);
                if(a_href == "project.php?id=" + projectid + "&stage=" +stageid) {
                    $("#st_" +stageid).addClass("active");
                }
            });
        }
    );
</script>
<style>
    #sub_cont h5 span {
        color: rgba(86, 105, 101, 0.44);
        font-size: 13px;
    }
    #sub_cont .list-group-item img {
        float: left;
        padding: 0 6px 6px 0;
        max-width: 50px;
        max-height: 50px;
        margin-left: -8px;
        margin-top: -4px;
    }
</style>
<script language="javascript">
    $(document).ready(function(){

        $('.search-background').fadeOut(200);
        //show loading bar
        function showLoader(){
            $('.search-background').fadeIn(200);
        }

        //hide loading bar
        function hideLoader(){
            $('#sub_cont').fadeIn(1500);
            $('.search-background').fadeOut(200);
        };

        $('#search').keyup(function(e) {
            if(e.keyCode == 13) {
                $('#sub_cont').fadeIn(1500);
                $("#ChatMessages").hide();
                $("#sub_cont").load("search.php?val=" + $("#search").val(), hideLoader());
            }
            if($('#search').val() == "" && e.keyCode == 13) {
                $('#sub_cont').hide();
                $("#ChatMessages").show();
                setInterval(function(){
                    $("#ChatMessages").load("displaymessages.php?channel="+hidval);
                },500);
            }
        });

        $(".searchBtn").click(function(){
            //show the loading bar
            showLoader();
            $('#sub_cont').fadeIn(1500);
            $('#ChatMessages').hide();
            $("#sub_cont").load("search.php?val=" + $("#search").val(), hideLoader());
            if($('#search').val() == "") {
                $('#sub_cont').hide();
                $("#ChatMessages").show();
                setInterval(function(){
                    $("#ChatMessages").load("displaymessages.php?channel="+hidval);
                },500);
            }

        });
    });

</script>


<script>
    function editUser(userid) {
        var ava = $("img#avatar").attr('src');
        //alert(ava);
		var ab = $(".modal-body").find("#username").val();
        var bc = $(".modal-body").find("#userfullname").val();
        var cd = $(".modal-body").find("#userphone").val();
        var de = $(".modal-body").find("#userposition").val();
        //alert(ab, bc, cd, de);
        //console.log(ab, bc, cd, de);
        $.ajax({
            url: "edituser.php?avatar="+ava+"&username="+ab+"&fullname="+bc+"&phone="+cd+"&position="+de,
            type: "POST",
            data:  {uid:userid},
            success: function(){
                //console.log(userid, bc, cd, de);
                $("#editnot").append("<div id='importmsg' class='alert-box success'>Ваш профиль успешно изменен</div>");
                $( "div#importmsg" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                setTimeout(function () {
                    location.reload();
                }, 2000);
            }
        });
    }
</script>
<style>
	#progress-bar {background-color: #12CC1A;height:20px;color: #FFFFFF;width:0%;
	-webkit-transition: width .3s;-moz-transition: width .3s;transition: width .3s;}
    #progress-div {float: right; margin-top: 8px;border-radius:4px;text-align:center;}


    .list-group-item-text.short {
        white-space: nowrap;
        width: 12em;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .bgColor label{
        font-weight: bold;
        color: #A0A0A0;
    }
    #targetLayer{
        float:left;
        width:100px;
        height:100px;
        text-align:center;
        line-height:100px;
        font-weight: bold;
        color: #C0C0C0;
        background-color: #F0E8E0;
        overflow:auto;
    }
    #uploadFormLayer{
        float:right;
    }
    .btnSubmit {
        background-color: #3FA849;
        padding:4px;
        border: #3FA849 1px solid;
        color: #FFFFFF;
    }
    .inputFile {
        padding: 3px;
        background-color: #FFFFFF;
    }

    .btn.btn-default.btn-file {
        position: relative;
        overflow: hidden;
        padding: 4px 8px;
    }
    .btn-file input[type=file] {
        position: absolute;
        top: 0;
        right: 0;
        min-width: 100%;
        min-height: 100%;
        font-size: 100px;
        text-align: right;
        filter: alpha(opacity=0);
        opacity: 0;
        outline: none;
        background: white;
        cursor: inherit;
        display: block;
    }
</style>
<script src="./js/jquery.form.min.js"></script>
<script type="text/javascript">
    $(document).ready(function (e) {
        $("#uploadForm").on('submit',(function(e) {
            e.preventDefault();
            $.ajax({
                url: "upload.php",
                type: "POST",
                data:  new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success: function(data)
                {
                    $("#targetLayer").html(data);
                },
                error: function()
                {
                }
            });
        }));
    });
	
	$(document).ready(function() {
		$(".filenamespan").hide();
		$("input:file").change(function (){
		$(".filenamespan").show();
		$(".attach-div").hide();
		   var fileName = $(this).val().replace(/C:\\fakepath\\/i, '');
		   $(".filenamespan").html(fileName);
		});
		$("#progress-bar").hide();
        var hidval = $("#hidch").val();
        var projectid = $("#get_id").val();
        $('#uploadDoc').submit(function(e) {
            if($('#userDoc').val()) {
                e.preventDefault();
                $(this).ajaxSubmit({
                    url: "upload.php?id="+projectid+"&channel="+hidval,
                    beforeSubmit: function() {
                        $("#progress-bar").width('0%');
                    },
                    uploadProgress: function (event, position, total, percentComplete){
						$("#progress-bar").show();
                        $("#progress-bar").width(percentComplete + '%');
                        $("#progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');

                    },
                    success:function (){
						$("#ChatMessages").load("displaymessages.php?id="+projectid+"&channel="+hidval+"&type=first");
						$(".list-group.userfiles").load("displayfiles.php?channel="+hidval);
                        setTimeout(function(){
                            $("#progress-bar").width('0%');
							$("#progress-bar").hide();
							$(".attach-div").show();
							$(".filenamespan").hide();
                        }, 1500)
						

                    },
                    resetForm: true
                });
                return false;
            } else {
				return false;
			}
        });
    });
</script>
<script>
    function href(userid){
        window.location = "profile.php?id="+userid;
    }

    function envelope(userid){

    }
</script>
<script>
    $(document).ready(function() {
        $(".dropdown-menu.notificate").load("displaynotification.php");
    })

    function callAction(action, id) {
        var queryString;
        switch (action) {
            case "remove":
                queryString = 'action=' + action + '&user_id=' + id;
                break;
        }
        jQuery.ajax({
            url: "crud_action.php",
            data: queryString,
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "remove":
                        $('.usernotification').fadeOut();
                        break;
                }
                $(".nav.badge").text('0');
            },
            error: function () {

            }
        });
    }
</script>
</html>